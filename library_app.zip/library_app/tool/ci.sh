#!/usr/bin/env bash
# Сборка APK на GitHub Actions. Запускается из папки проекта.
set -euo pipefail

flutter create --org kz.rinat --project-name ebook_reader --platforms=android .
rm -rf test
python3 tool/patch_android.py

flutter pub get
flutter analyze || true
flutter build apk --release
