#!/usr/bin/env python3
"""Дописывает в сгенерированный Android-проект всё, что нужно для озвучки в фоне.

Запускается после `flutter create`: правит AndroidManifest.xml
(права, сервис и приёмник audio_service, доступ к системному TTS)
и повышает версию Kotlin, если она старая.
"""
import pathlib
import re

root = pathlib.Path("android")
manifest = root / "app/src/main/AndroidManifest.xml"
s = manifest.read_text(encoding="utf-8")

if "xmlns:tools" not in s:
    s = s.replace("<manifest ", '<manifest xmlns:tools="http://schemas.android.com/tools" ', 1)

# название приложения под значком
s = re.sub(r'android:label="[^"]*"', 'android:label="Библиотека"', s, count=1)

# главная Activity должна уметь отдавать движок сервису озвучки
s = s.replace(
    'android:name=".MainActivity"',
    'android:name="com.ryanheise.audioservice.AudioServiceActivity"',
)

permissions = [
    "WAKE_LOCK",
    "FOREGROUND_SERVICE",
    "FOREGROUND_SERVICE_MEDIA_PLAYBACK",
    "POST_NOTIFICATIONS",
]
perm_xml = "".join(
    f'    <uses-permission android:name="android.permission.{p}"/>\n'
    for p in permissions
    if f"android.permission.{p}" not in s
)
s = s.replace("<application", perm_xml + "    <application", 1)

service_xml = """
        <service android:name="com.ryanheise.audioservice.AudioService"
            android:foregroundServiceType="mediaPlayback"
            android:exported="true" tools:ignore="Instantiatable">
            <intent-filter>
                <action android:name="android.media.browse.MediaBrowserService" />
            </intent-filter>
        </service>
        <receiver android:name="com.ryanheise.audioservice.MediaButtonReceiver"
            android:exported="true" tools:ignore="Instantiatable">
            <intent-filter>
                <action android:name="android.intent.action.MEDIA_BUTTON" />
            </intent-filter>
        </receiver>
"""
if "com.ryanheise.audioservice.AudioService\"" not in s:
    s = s.replace("</application>", service_xml + "    </application>", 1)

tts_query = '<intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>'
if "TTS_SERVICE" not in s:
    if "<queries>" in s:
        s = s.replace("<queries>", "<queries>\n        " + tts_query, 1)
    else:
        s = s.replace("</manifest>", "    <queries>\n        " + tts_query + "\n    </queries>\n</manifest>", 1)

manifest.write_text(s, encoding="utf-8")
print("AndroidManifest.xml patched")

# Kotlin: плагины озвучки лучше собираются на 1.9.x
for name in ("settings.gradle", "settings.gradle.kts"):
    p = root / name
    if p.exists():
        t = p.read_text(encoding="utf-8")
        t2 = t.replace("1.8.22", "1.9.24")
        if t2 != t:
            p.write_text(t2, encoding="utf-8")
            print(f"{name}: Kotlin 1.8.22 -> 1.9.24")
