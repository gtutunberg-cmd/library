import 'package:flutter/material.dart';

import '../data/library_store.dart';

const Color kCream = Color(0xFFF1DFB0);
const Color kGold = Color(0xFFD9B66A);

const List<Color> kCoverPalette = [
  Color(0xFF7B2D26),
  Color(0xFF2F5D3A),
  Color(0xFF22405F),
  Color(0xFF5B3A29),
  Color(0xFF4B2E5C),
  Color(0xFF1F5B5E),
  Color(0xFF3C3C44),
  Color(0xFF8A5A1C),
];

Color coverColorFor(String title) =>
    kCoverPalette[title.hashCode.abs() % kCoverPalette.length];

/// Обложка книги. Одна и та же на полке (маленькая) и первой страницей
/// в читалке ([large] — растянута на весь экран).
class BookCoverArt extends StatelessWidget {
  const BookCoverArt({
    super.key,
    required this.book,
    required this.width,
    required this.height,
    this.large = false,
    this.shadow = false,
  });

  final BookEntry book;
  final double width;
  final double height;
  final bool large;
  final bool shadow;

  @override
  Widget build(BuildContext context) {
    final base = coverColorFor(book.title);
    final hsl = HSLColor.fromColor(base);
    final dark = hsl
        .withLightness((hsl.lightness - 0.09).clamp(0.0, 1.0).toDouble())
        .toColor();
    final titleSize =
        large ? width * 0.085 : (width * 0.115).clamp(11.0, 16.0).toDouble();
    final authorSize = titleSize * (large ? 0.6 : 0.78);
    final pct = (book.progress * 100).floor();
    final inset = large ? width * 0.05 : 7.0;

    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        borderRadius: large
            ? BorderRadius.zero
            : const BorderRadius.only(
                topLeft: Radius.circular(3),
                topRight: Radius.circular(6),
                bottomLeft: Radius.circular(3),
                bottomRight: Radius.circular(6),
              ),
        gradient: LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [dark, base, base, dark],
          stops: const [0.0, 0.12, 0.65, 1.0],
        ),
        boxShadow: shadow
            ? const [
                BoxShadow(color: Colors.black54, blurRadius: 8, offset: Offset(2, 4)),
              ]
            : null,
      ),
      child: Stack(
        children: [
          // корешок
          Positioned(
            left: 0,
            top: 0,
            bottom: 0,
            width: width * 0.09,
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.black.withValues(alpha: 0.35),
                    Colors.black.withValues(alpha: 0.0),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            left: width * 0.09,
            top: 0,
            bottom: 0,
            width: 1,
            child: ColoredBox(color: kGold.withValues(alpha: 0.45)),
          ),
          // золотая рамка
          Positioned.fill(
            child: Container(
              margin: EdgeInsets.fromLTRB(width * 0.13, inset, inset, inset),
              decoration: BoxDecoration(
                border: Border.all(color: kGold.withValues(alpha: 0.28)),
              ),
            ),
          ),
          if (large)
            Positioned.fill(
              child: Container(
                margin: EdgeInsets.fromLTRB(
                  width * 0.13 + 8,
                  inset + 8,
                  inset + 8,
                  inset + 8,
                ),
                decoration: BoxDecoration(
                  border: Border.all(color: kGold.withValues(alpha: 0.16)),
                ),
              ),
            ),
          Padding(
            padding: EdgeInsets.fromLTRB(
              width * (large ? 0.22 : 0.19),
              height * (large ? 0.12 : 0.08),
              width * (large ? 0.14 : 0.10),
              height * (large ? 0.09 : 0.06),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: width * (large ? 0.3 : 0.22),
                  height: large ? 2.0 : 1.4,
                  color: kGold.withValues(alpha: 0.8),
                ),
                SizedBox(height: large ? 18 : 7),
                Expanded(
                  child: Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      book.title,
                      maxLines: large ? 9 : 5,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: 'serif',
                        fontSize: titleSize,
                        fontWeight: FontWeight.w600,
                        height: 1.2,
                        color: kCream,
                      ),
                    ),
                  ),
                ),
                if (book.author.isNotEmpty)
                  Padding(
                    padding: EdgeInsets.only(bottom: large ? 18 : 6),
                    child: Text(
                      book.author,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: 'serif',
                        fontSize: authorSize,
                        color: kGold.withValues(alpha: 0.9),
                      ),
                    ),
                  ),
                if (large)
                  Container(
                    width: width * 0.3,
                    height: 2.0,
                    color: kGold.withValues(alpha: 0.8),
                  )
                else ...[
                  Row(
                    children: [
                      Text(
                        book.format.toUpperCase(),
                        style: TextStyle(
                          fontSize: 9,
                          color: kGold.withValues(alpha: 0.6),
                          letterSpacing: 0.5,
                        ),
                      ),
                      const Spacer(),
                      if (pct > 0)
                        Text(
                          '$pct%',
                          style: TextStyle(fontSize: 9, color: kGold.withValues(alpha: 0.8)),
                        ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(2),
                    child: LinearProgressIndicator(
                      value: book.progress,
                      minHeight: 3,
                      color: kGold,
                      backgroundColor: Colors.black26,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
