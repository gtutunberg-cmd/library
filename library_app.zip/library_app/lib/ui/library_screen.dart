import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

import '../data/library_store.dart';
import '../data/reader_settings.dart';
import '../reader/reader_screen.dart';
import 'book_cover.dart';

const Color _wallDark = Color(0xFF2A1A10);
const Color _wallLight = Color(0xFF3A2416);
const Color _cream = kCream;
const Color _gold = kGold;

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key, required this.library, required this.settings});

  final LibraryStore library;
  final ReaderSettings settings;

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  bool _busy = false;
  int _filter = 0; // 0 все, 1 читаю, 2 избранное, 3 прочитано
  int _sort = 0; // 0 недавние, 1 название, 2 автор
  bool _list = false;

  static const _filterNames = ['Все', 'Читаю', 'Избранное', 'Прочитано'];

  List<BookEntry> _visible(List<BookEntry> all) {
    final res = all.where((b) {
      switch (_filter) {
        case 1:
          return b.isReading;
        case 2:
          return b.favorite;
        case 3:
          return b.isFinished;
        default:
          return true;
      }
    }).toList();
    if (_sort == 1) {
      res.sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
    } else if (_sort == 2) {
      res.sort((a, b) => a.author.toLowerCase().compareTo(b.author.toLowerCase()));
    }
    return res;
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), duration: const Duration(seconds: 5)),
    );
  }

  Future<void> _scan() async {
    final status = await Permission.manageExternalStorage.request();
    if (!status.isGranted) {
      _toast('Нужно разрешение «Доступ ко всем файлам», чтобы искать книги в папках');
      return;
    }
    final dir = await FilePicker.platform.getDirectoryPath(dialogTitle: 'Папка с книгами');
    if (dir == null || !mounted) return;
    setState(() => _busy = true);
    try {
      final (added, failed) = await widget.library.scanFolder(dir);
      _toast('Добавлено книг: $added${failed > 0 ? ', не удалось: $failed' : ''}');
    } catch (e) {
      _toast('Ошибка сканирования: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _backup() async {
    try {
      final json = widget.library.exportBackup(widget.settings.toJson());
      final path = await FilePicker.platform.saveFile(
        dialogTitle: 'Сохранить резервную копию',
        fileName: 'library_backup.json',
        bytes: Uint8List.fromList(utf8.encode(json)),
      );
      if (path != null) _toast('Копия сохранена');
    } catch (e) {
      _toast('Не удалось сохранить копию: $e');
    }
  }

  Future<void> _restore() async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['json'],
    );
    final path = res?.files.single.path;
    if (path == null) return;
    try {
      final raw = await File(path).readAsString();
      final (matched, settings) = widget.library.restoreBackup(raw);
      await widget.settings.applyJson(settings);
      _toast('Восстановлено для книг: $matched. Сами файлы книг в копию не входят — '
          'добавьте их заново, потом повторите восстановление.');
    } catch (e) {
      _toast('Не удалось прочитать копию');
    }
  }

  void _actions(BookEntry book) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: Text(book.title, maxLines: 2, overflow: TextOverflow.ellipsis),
              subtitle: book.author.isEmpty ? null : Text(book.author),
            ),
            ListTile(
              leading: Icon(book.favorite ? Icons.star : Icons.star_border),
              title: Text(book.favorite ? 'Убрать из избранного' : 'В избранное'),
              onTap: () {
                Navigator.pop(ctx);
                widget.library.toggleFavorite(book);
              },
            ),
            ListTile(
              leading: Icon(book.isFinished ? Icons.undo : Icons.done_all),
              title: Text(book.isFinished ? 'Вернуть в «Читаю»' : 'Отметить прочитанной'),
              onTap: () {
                Navigator.pop(ctx);
                widget.library.toggleFinished(book);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline),
              title: const Text('Удалить'),
              onTap: () {
                Navigator.pop(ctx);
                _confirmDelete(book);
              },
            ),
          ],
        ),
      ),
    );
  }

  String _message(Object e) {
    if (e is FormatException) return e.message;
    return e.toString();
  }

  Future<void> _import() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.any,
    );
    if (result == null || !mounted) return;

    setState(() => _busy = true);
    final errors = <String>[];
    for (final f in result.files) {
      final path = f.path;
      if (path == null) continue;
      try {
        await widget.library.importFile(path, f.name);
      } catch (e) {
        errors.add('${f.name}: ${_message(e)}');
      }
    }
    if (!mounted) return;
    setState(() => _busy = false);
    if (errors.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(errors.join('\n')),
          duration: const Duration(seconds: 6),
        ),
      );
    }
  }

  void _open(BookEntry book) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ReaderScreen(
          entry: book,
          library: widget.library,
          settings: widget.settings,
        ),
      ),
    );
  }

  Future<void> _confirmDelete(BookEntry book) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Удалить книгу?'),
        content: Text(book.title),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Отмена'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Удалить'),
          ),
        ],
      ),
    );
    if (ok == true) await widget.library.remove(book);
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: _wallDark,
        appBar: AppBar(
          backgroundColor: const Color(0xFF3B2415),
          foregroundColor: _cream,
          elevation: 0,
          centerTitle: true,
          actions: [
            IconButton(
              icon: Icon(_list ? Icons.shelves : Icons.view_list),
              tooltip: _list ? 'Полки' : 'Список',
              onPressed: () => setState(() => _list = !_list),
            ),
            PopupMenuButton<String>(
              onSelected: (v) {
                switch (v) {
                  case 'sort0':
                    setState(() => _sort = 0);
                  case 'sort1':
                    setState(() => _sort = 1);
                  case 'sort2':
                    setState(() => _sort = 2);
                  case 'scan':
                    _scan();
                  case 'backup':
                    _backup();
                  case 'restore':
                    _restore();
                }
              },
              itemBuilder: (_) => [
                CheckedPopupMenuItem(value: 'sort0', checked: _sort == 0, child: const Text('Сначала недавние')),
                CheckedPopupMenuItem(value: 'sort1', checked: _sort == 1, child: const Text('По названию')),
                CheckedPopupMenuItem(value: 'sort2', checked: _sort == 2, child: const Text('По автору')),
                const PopupMenuDivider(),
                const PopupMenuItem(value: 'scan', child: Text('Найти книги в папке…')),
                const PopupMenuItem(value: 'backup', child: Text('Сохранить резервную копию')),
                const PopupMenuItem(value: 'restore', child: Text('Восстановить из копии')),
              ],
            ),
          ],
          title: const Text(
            'Моя библиотека',
            style: TextStyle(
              fontFamily: 'serif',
              fontSize: 24,
              letterSpacing: 1,
              color: _cream,
            ),
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(5),
            child: Container(
              height: 5,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFF8B5A2B), Color(0xFF4A2B14)],
                ),
              ),
            ),
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _busy ? null : _import,
          backgroundColor: _gold,
          foregroundColor: const Color(0xFF2A1A10),
          icon: _busy
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.add),
          label: Text(_busy ? 'Добавляю…' : 'Добавить'),
        ),
        body: Column(
          children: [
            SizedBox(
              height: 46,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                children: [
                  for (var i = 0; i < _filterNames.length; i++)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(_filterNames[i]),
                        selected: _filter == i,
                        onSelected: (_) => setState(() => _filter = i),
                      ),
                    ),
                ],
              ),
            ),
            Expanded(child: _buildBody()),
          ],
        ),
      ),
    );
  }

  Widget _buildBody() {
    return ListenableBuilder(
          listenable: widget.library,
          builder: (context, _) => LayoutBuilder(builder: (context, c) {
            final books = _visible(widget.library.books);
            if (_list) return _buildList(books);
            final w = c.maxWidth;
            final perRow = math.max(2, (w / 125).floor());
            const pad = 16.0;
            const gap = 12.0;
            final bookW = (w - pad * 2 - gap * (perRow - 1)) / perRow;
            final bookH = bookW * 1.5;
            final shelfH = bookH * 1.08 + 30;
            final dataRows = (books.length / perRow).ceil();
            final minRows = (c.maxHeight / shelfH).ceil();
            final rows = math.max(dataRows + 1, minRows);

            return Stack(
              children: [
                ListView.builder(
                  padding: const EdgeInsets.only(bottom: 90),
                  itemCount: rows,
                  itemBuilder: (ctx, r) {
                    final start = r * perRow;
                    final slice = start < books.length
                        ? books.sublist(start, math.min(books.length, start + perRow))
                        : const <BookEntry>[];
                    return _ShelfRow(
                      books: slice,
                      perRow: perRow,
                      bookW: bookW,
                      bookH: bookH,
                      gap: gap,
                      pad: pad,
                      seed: r,
                      onOpen: _open,
                      onDelete: _actions,
                    );
                  },
                ),
                if (books.isEmpty)
                  Positioned.fill(
                    child: IgnorePointer(
                      child: Align(
                        alignment: const Alignment(0, -0.25),
                        child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 36),
                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                          decoration: BoxDecoration(
                            color: const Color(0xFFEBD9A8),
                            borderRadius: BorderRadius.circular(6),
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black54,
                                blurRadius: 10,
                                offset: Offset(2, 4),
                              ),
                            ],
                          ),
                          child: const Text(
                            'Полки пока пусты.\nНажми «Добавить» и выбери книги: '
                            'FB2, EPUB, MOBI, RTF, TXT, DOCX, HTML, MD.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontFamily: 'serif',
                              fontSize: 16,
                              height: 1.35,
                              color: Color(0xFF4A2B14),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            );
          }),
    );
  }

  Widget _buildList(List<BookEntry> books) {
    if (books.isEmpty) {
      return const Center(
        child: Text('Здесь пока ничего нет', style: TextStyle(color: _cream)),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 90),
      itemCount: books.length,
      itemBuilder: (ctx, i) {
        final b = books[i];
        return ListTile(
          leading: SizedBox(
            width: 44,
            height: 66,
            child: BookCoverArt(book: b, width: 44, height: 66),
          ),
          title: Text(
            b.title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: _cream),
          ),
          subtitle: Text(
            '${b.author.isEmpty ? '' : '${b.author} · '}${(b.progress * 100).round()}%',
            style: TextStyle(color: _cream.withValues(alpha: 0.7)),
          ),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (b.favorite) const Icon(Icons.star, color: _gold, size: 20),
              if (b.isFinished) const Icon(Icons.done_all, color: _gold, size: 20),
            ],
          ),
          onTap: () => _open(b),
          onLongPress: () => _actions(b),
        );
      },
    );
  }
}

// ---------- полка ----------

class _ShelfRow extends StatelessWidget {
  const _ShelfRow({
    required this.books,
    required this.perRow,
    required this.bookW,
    required this.bookH,
    required this.gap,
    required this.pad,
    required this.seed,
    required this.onOpen,
    required this.onDelete,
  });

  final List<BookEntry> books;
  final int perRow;
  final double bookW;
  final double bookH;
  final double gap;
  final double pad;
  final int seed;
  final ValueChanged<BookEntry> onOpen;
  final ValueChanged<BookEntry> onDelete;

  double _heightFactor(BookEntry b) => 0.93 + (b.title.hashCode.abs() % 7) / 100;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: bookH * 1.08 + 30,
      child: Stack(
        children: [
          Positioned.fill(
            child: RepaintBoundary(
              child: CustomPaint(painter: _ShelfPainter(seed)),
            ),
          ),
          Positioned(
            left: pad,
            right: pad,
            bottom: 20,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (var i = 0; i < perRow; i++) ...[
                  if (i > 0) SizedBox(width: gap),
                  SizedBox(
                    width: bookW,
                    child: i < books.length
                        ? Align(
                            alignment: Alignment.bottomCenter,
                            child: _BookCover(
                              book: books[i],
                              width: bookW,
                              height: bookH * _heightFactor(books[i]),
                              onTap: () => onOpen(books[i]),
                              onLongPress: () => onDelete(books[i]),
                            ),
                          )
                        : null,
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Задняя стенка, боковины и деревянная доска полки.
class _ShelfPainter extends CustomPainter {
  _ShelfPainter(this.seed);
  final int seed;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // задняя стенка
    canvas.drawRect(
      Rect.fromLTWH(0, 0, w, h),
      Paint()
        ..shader = ui.Gradient.linear(
          Offset.zero,
          Offset(0, h),
          [_wallDark, _wallLight],
        ),
    );
    // доски стенки (тонкие вертикальные линии)
    final boards = Paint()
      ..color = Colors.black.withValues(alpha: 0.12)
      ..strokeWidth = 1;
    for (var x = 38.0; x < w; x += 76) {
      canvas.drawLine(Offset(x, 0), Offset(x, h - 26), boards);
    }
    // тень от верхней полки
    canvas.drawRect(
      Rect.fromLTWH(0, 0, w, 48),
      Paint()
        ..shader = ui.Gradient.linear(
          Offset.zero,
          const Offset(0, 48),
          [Colors.black.withValues(alpha: 0.6), Colors.black.withValues(alpha: 0.0)],
        ),
    );
    // боковины шкафа
    const sideW = 9.0;
    final sidePaint = Paint()
      ..shader = ui.Gradient.linear(
        Offset.zero,
        const Offset(sideW, 0),
        [const Color(0xFF2C170A), const Color(0xFF5A3719)],
      );
    canvas.drawRect(Rect.fromLTWH(0, 0, sideW, h), sidePaint);
    canvas.drawRect(
      Rect.fromLTWH(w - sideW, 0, sideW, h),
      Paint()
        ..shader = ui.Gradient.linear(
          Offset(w - sideW, 0),
          Offset(w, 0),
          [const Color(0xFF5A3719), const Color(0xFF2C170A)],
        ),
    );

    // доска: верхняя поверхность и лицевая грань
    final topY = h - 26;
    canvas.drawRect(
      Rect.fromLTWH(0, topY, w, 9),
      Paint()
        ..shader = ui.Gradient.linear(
          Offset(0, topY),
          Offset(0, topY + 9),
          [const Color(0xFFA06E3C), const Color(0xFF7C5028)],
        ),
    );
    canvas.drawRect(
      Rect.fromLTWH(0, topY + 9, w, 17),
      Paint()
        ..shader = ui.Gradient.linear(
          Offset(0, topY + 9),
          Offset(0, h),
          [const Color(0xFF6E4322), const Color(0xFF45280F)],
        ),
    );

    // волокна дерева
    final rnd = math.Random(seed * 97 + 13);
    final grain = Paint()..style = PaintingStyle.stroke;
    for (var k = 0; k < 11; k++) {
      final y = topY + 10.5 + rnd.nextDouble() * 14;
      final path = Path()..moveTo(0, y);
      var x = 0.0;
      while (x < w) {
        path.quadraticBezierTo(
          x + 40,
          y + (rnd.nextDouble() - 0.5) * 2.4,
          x + 80,
          y + (rnd.nextDouble() - 0.5) * 1.6,
        );
        x += 80;
      }
      grain
        ..strokeWidth = 0.5 + rnd.nextDouble() * 0.9
        ..color = Colors.black.withValues(alpha: 0.08 + rnd.nextDouble() * 0.14);
      canvas.drawPath(path, grain);
    }
    for (var k = 0; k < 4; k++) {
      final y = topY + 1.5 + rnd.nextDouble() * 6;
      final path = Path()..moveTo(0, y);
      var x = 0.0;
      while (x < w) {
        path.quadraticBezierTo(
          x + 50,
          y + (rnd.nextDouble() - 0.5) * 1.5,
          x + 100,
          y + (rnd.nextDouble() - 0.5) * 1.2,
        );
        x += 100;
      }
      grain
        ..strokeWidth = 0.6
        ..color = Colors.white.withValues(alpha: 0.05 + rnd.nextDouble() * 0.06);
      canvas.drawPath(path, grain);
    }

    // блик на переднем ребре и тёмная нижняя кромка
    canvas.drawRect(
      Rect.fromLTWH(0, topY + 9, w, 1.2),
      Paint()..color = const Color(0x66FFE2B0),
    );
    canvas.drawRect(
      Rect.fromLTWH(0, h - 1.5, w, 1.5),
      Paint()..color = Colors.black.withValues(alpha: 0.5),
    );
  }

  @override
  bool shouldRepaint(_ShelfPainter old) => old.seed != seed;
}

// ---------- книга ----------

class _BookCover extends StatelessWidget {
  const _BookCover({
    required this.book,
    required this.width,
    required this.height,
    required this.onTap,
    required this.onLongPress,
  });

  final BookEntry book;
  final double width;
  final double height;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Stack(
        children: [
          BookCoverArt(book: book, width: width, height: height, shadow: true),
          if (book.favorite)
            const Positioned(
              top: 3,
              right: 3,
              child: Icon(Icons.star, color: _gold, size: 20),
            ),
          if (book.isFinished)
            const Positioned(
              bottom: 3,
              right: 3,
              child: Icon(Icons.check_circle, color: _gold, size: 18),
            ),
        ],
      ),
    );
  }
}
