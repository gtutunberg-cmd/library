import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../data/library_store.dart';
import '../data/reader_settings.dart';
import '../reader/reader_screen.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key, required this.library, required this.settings});

  final LibraryStore library;
  final ReaderSettings settings;

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  bool _busy = false;

  String _message(Object e) {
    if (e is FormatException) return e.message;
    return e.toString();
  }

  Future<void> _import() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.any,
    );
    if (result == null || !mounted) return;

    setState(() => _busy = true);
    final errors = <String>[];
    for (final f in result.files) {
      final path = f.path;
      if (path == null) continue;
      try {
        await widget.library.importFile(path, f.name);
      } catch (e) {
        errors.add('${f.name}: ${_message(e)}');
      }
    }
    if (!mounted) return;
    setState(() => _busy = false);
    if (errors.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(errors.join('\n')),
          duration: const Duration(seconds: 6),
        ),
      );
    }
  }

  void _open(BookEntry book) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ReaderScreen(
          entry: book,
          library: widget.library,
          settings: widget.settings,
        ),
      ),
    );
  }

  Future<void> _confirmDelete(BookEntry book) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Удалить книгу?'),
        content: Text(book.title),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Отмена'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Удалить'),
          ),
        ],
      ),
    );
    if (ok == true) await widget.library.remove(book);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Библиотека')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _busy ? null : _import,
        icon: _busy
            ? const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
            : const Icon(Icons.add),
        label: Text(_busy ? 'Добавляю…' : 'Добавить'),
      ),
      body: ListenableBuilder(
        listenable: widget.library,
        builder: (context, _) {
          final books = widget.library.books;
          if (books.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'Пока пусто.\nНажми «Добавить» и выбери книги:\nFB2, EPUB, TXT, DOCX, HTML, MD.',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }
          return GridView.builder(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: 190,
              childAspectRatio: 0.64,
              crossAxisSpacing: 14,
              mainAxisSpacing: 14,
            ),
            itemCount: books.length,
            itemBuilder: (context, i) {
              final b = books[i];
              return _BookCard(
                book: b,
                onTap: () => _open(b),
                onLongPress: () => _confirmDelete(b),
              );
            },
          );
        },
      ),
    );
  }
}

class _BookCard extends StatelessWidget {
  const _BookCard({
    required this.book,
    required this.onTap,
    required this.onLongPress,
  });

  final BookEntry book;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  Color _coverColor() {
    final hue = (book.title.hashCode.abs() % 360).toDouble();
    return HSLColor.fromAHSL(1, hue, 0.35, 0.32).toColor();
  }

  @override
  Widget build(BuildContext context) {
    final color = _coverColor();
    return Material(
      color: color,
      borderRadius: BorderRadius.circular(10),
      elevation: 2,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        onLongPress: onLongPress,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Text(
                  book.title,
                  maxLines: 6,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    height: 1.25,
                  ),
                ),
              ),
              if (book.author.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(
                    book.author,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                ),
              Row(
                children: [
                  Text(
                    book.format.toUpperCase(),
                    style: const TextStyle(color: Colors.white60, fontSize: 11),
                  ),
                  const Spacer(),
                  Text(
                    '${(book.progress * 100).floor()}%',
                    style: const TextStyle(color: Colors.white70, fontSize: 11),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(2),
                child: LinearProgressIndicator(
                  value: book.progress,
                  minHeight: 3,
                  color: Colors.white,
                  backgroundColor: Colors.white24,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
