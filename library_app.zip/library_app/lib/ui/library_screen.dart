import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/library_store.dart';
import '../data/reader_settings.dart';
import '../reader/reader_screen.dart';

const Color _wallDark = Color(0xFF2A1A10);
const Color _wallLight = Color(0xFF3A2416);
const Color _cream = Color(0xFFF1DFB0);
const Color _gold = Color(0xFFD9B66A);

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key, required this.library, required this.settings});

  final LibraryStore library;
  final ReaderSettings settings;

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  bool _busy = false;

  String _message(Object e) {
    if (e is FormatException) return e.message;
    return e.toString();
  }

  Future<void> _import() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.any,
    );
    if (result == null || !mounted) return;

    setState(() => _busy = true);
    final errors = <String>[];
    for (final f in result.files) {
      final path = f.path;
      if (path == null) continue;
      try {
        await widget.library.importFile(path, f.name);
      } catch (e) {
        errors.add('${f.name}: ${_message(e)}');
      }
    }
    if (!mounted) return;
    setState(() => _busy = false);
    if (errors.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(errors.join('\n')),
          duration: const Duration(seconds: 6),
        ),
      );
    }
  }

  void _open(BookEntry book) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ReaderScreen(
          entry: book,
          library: widget.library,
          settings: widget.settings,
        ),
      ),
    );
  }

  Future<void> _confirmDelete(BookEntry book) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Удалить книгу?'),
        content: Text(book.title),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Отмена'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Удалить'),
          ),
        ],
      ),
    );
    if (ok == true) await widget.library.remove(book);
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: _wallDark,
        appBar: AppBar(
          backgroundColor: const Color(0xFF3B2415),
          foregroundColor: _cream,
          elevation: 0,
          centerTitle: true,
          title: const Text(
            'Моя библиотека',
            style: TextStyle(
              fontFamily: 'serif',
              fontSize: 24,
              letterSpacing: 1,
              color: _cream,
            ),
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(5),
            child: Container(
              height: 5,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFF8B5A2B), Color(0xFF4A2B14)],
                ),
              ),
            ),
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _busy ? null : _import,
          backgroundColor: _gold,
          foregroundColor: const Color(0xFF2A1A10),
          icon: _busy
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.add),
          label: Text(_busy ? 'Добавляю…' : 'Добавить'),
        ),
        body: ListenableBuilder(
          listenable: widget.library,
          builder: (context, _) => LayoutBuilder(builder: (context, c) {
            final books = widget.library.books;
            final w = c.maxWidth;
            final perRow = math.max(2, (w / 125).floor());
            const pad = 16.0;
            const gap = 12.0;
            final bookW = (w - pad * 2 - gap * (perRow - 1)) / perRow;
            final bookH = bookW * 1.5;
            final shelfH = bookH * 1.08 + 30;
            final dataRows = (books.length / perRow).ceil();
            final minRows = (c.maxHeight / shelfH).ceil();
            final rows = math.max(dataRows + 1, minRows);

            return Stack(
              children: [
                ListView.builder(
                  padding: const EdgeInsets.only(bottom: 90),
                  itemCount: rows,
                  itemBuilder: (ctx, r) {
                    final start = r * perRow;
                    final slice = start < books.length
                        ? books.sublist(start, math.min(books.length, start + perRow))
                        : const <BookEntry>[];
                    return _ShelfRow(
                      books: slice,
                      perRow: perRow,
                      bookW: bookW,
                      bookH: bookH,
                      gap: gap,
                      pad: pad,
                      seed: r,
                      onOpen: _open,
                      onDelete: _confirmDelete,
                    );
                  },
                ),
                if (books.isEmpty)
                  Positioned.fill(
                    child: IgnorePointer(
                      child: Align(
                        alignment: const Alignment(0, -0.25),
                        child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 36),
                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                          decoration: BoxDecoration(
                            color: const Color(0xFFEBD9A8),
                            borderRadius: BorderRadius.circular(6),
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black54,
                                blurRadius: 10,
                                offset: Offset(2, 4),
                              ),
                            ],
                          ),
                          child: const Text(
                            'Полки пока пусты.\nНажми «Добавить» и выбери книги: '
                            'FB2, EPUB, TXT, DOCX, HTML, MD.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontFamily: 'serif',
                              fontSize: 16,
                              height: 1.35,
                              color: Color(0xFF4A2B14),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            );
          }),
        ),
      ),
    );
  }
}

// ---------- полка ----------

class _ShelfRow extends StatelessWidget {
  const _ShelfRow({
    required this.books,
    required this.perRow,
    required this.bookW,
    required this.bookH,
    required this.gap,
    required this.pad,
    required this.seed,
    required this.onOpen,
    required this.onDelete,
  });

  final List<BookEntry> books;
  final int perRow;
  final double bookW;
  final double bookH;
  final double gap;
  final double pad;
  final int seed;
  final ValueChanged<BookEntry> onOpen;
  final ValueChanged<BookEntry> onDelete;

  double _heightFactor(BookEntry b) => 0.93 + (b.title.hashCode.abs() % 7) / 100;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: bookH * 1.08 + 30,
      child: Stack(
        children: [
          Positioned.fill(
            child: RepaintBoundary(
              child: CustomPaint(painter: _ShelfPainter(seed)),
            ),
          ),
          Positioned(
            left: pad,
            right: pad,
            bottom: 20,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (var i = 0; i < perRow; i++) ...[
                  if (i > 0) SizedBox(width: gap),
                  SizedBox(
                    width: bookW,
                    child: i < books.length
                        ? Align(
                            alignment: Alignment.bottomCenter,
                            child: _BookCover(
                              book: books[i],
                              width: bookW,
                              height: bookH * _heightFactor(books[i]),
                              onTap: () => onOpen(books[i]),
                              onLongPress: () => onDelete(books[i]),
                            ),
                          )
                        : null,
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Задняя стенка, боковины и деревянная доска полки.
class _ShelfPainter extends CustomPainter {
  _ShelfPainter(this.seed);
  final int seed;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // задняя стенка
    canvas.drawRect(
      Rect.fromLTWH(0, 0, w, h),
      Paint()
        ..shader = ui.Gradient.linear(
          Offset.zero,
          Offset(0, h),
          [_wallDark, _wallLight],
        ),
    );
    // доски стенки (тонкие вертикальные линии)
    final boards = Paint()
      ..color = Colors.black.withValues(alpha: 0.12)
      ..strokeWidth = 1;
    for (var x = 38.0; x < w; x += 76) {
      canvas.drawLine(Offset(x, 0), Offset(x, h - 26), boards);
    }
    // тень от верхней полки
    canvas.drawRect(
      Rect.fromLTWH(0, 0, w, 48),
      Paint()
        ..shader = ui.Gradient.linear(
          Offset.zero,
          const Offset(0, 48),
          [Colors.black.withValues(alpha: 0.6), Colors.black.withValues(alpha: 0.0)],
        ),
    );
    // боковины шкафа
    const sideW = 9.0;
    final sidePaint = Paint()
      ..shader = ui.Gradient.linear(
        Offset.zero,
        const Offset(sideW, 0),
        [const Color(0xFF2C170A), const Color(0xFF5A3719)],
      );
    canvas.drawRect(Rect.fromLTWH(0, 0, sideW, h), sidePaint);
    canvas.drawRect(
      Rect.fromLTWH(w - sideW, 0, sideW, h),
      Paint()
        ..shader = ui.Gradient.linear(
          Offset(w - sideW, 0),
          Offset(w, 0),
          [const Color(0xFF5A3719), const Color(0xFF2C170A)],
        ),
    );

    // доска: верхняя поверхность и лицевая грань
    final topY = h - 26;
    canvas.drawRect(
      Rect.fromLTWH(0, topY, w, 9),
      Paint()
        ..shader = ui.Gradient.linear(
          Offset(0, topY),
          Offset(0, topY + 9),
          [const Color(0xFFA06E3C), const Color(0xFF7C5028)],
        ),
    );
    canvas.drawRect(
      Rect.fromLTWH(0, topY + 9, w, 17),
      Paint()
        ..shader = ui.Gradient.linear(
          Offset(0, topY + 9),
          Offset(0, h),
          [const Color(0xFF6E4322), const Color(0xFF45280F)],
        ),
    );

    // волокна дерева
    final rnd = math.Random(seed * 97 + 13);
    final grain = Paint()..style = PaintingStyle.stroke;
    for (var k = 0; k < 11; k++) {
      final y = topY + 10.5 + rnd.nextDouble() * 14;
      final path = Path()..moveTo(0, y);
      var x = 0.0;
      while (x < w) {
        path.quadraticBezierTo(
          x + 40,
          y + (rnd.nextDouble() - 0.5) * 2.4,
          x + 80,
          y + (rnd.nextDouble() - 0.5) * 1.6,
        );
        x += 80;
      }
      grain
        ..strokeWidth = 0.5 + rnd.nextDouble() * 0.9
        ..color = Colors.black.withValues(alpha: 0.08 + rnd.nextDouble() * 0.14);
      canvas.drawPath(path, grain);
    }
    for (var k = 0; k < 4; k++) {
      final y = topY + 1.5 + rnd.nextDouble() * 6;
      final path = Path()..moveTo(0, y);
      var x = 0.0;
      while (x < w) {
        path.quadraticBezierTo(
          x + 50,
          y + (rnd.nextDouble() - 0.5) * 1.5,
          x + 100,
          y + (rnd.nextDouble() - 0.5) * 1.2,
        );
        x += 100;
      }
      grain
        ..strokeWidth = 0.6
        ..color = Colors.white.withValues(alpha: 0.05 + rnd.nextDouble() * 0.06);
      canvas.drawPath(path, grain);
    }

    // блик на переднем ребре и тёмная нижняя кромка
    canvas.drawRect(
      Rect.fromLTWH(0, topY + 9, w, 1.2),
      Paint()..color = const Color(0x66FFE2B0),
    );
    canvas.drawRect(
      Rect.fromLTWH(0, h - 1.5, w, 1.5),
      Paint()..color = Colors.black.withValues(alpha: 0.5),
    );
  }

  @override
  bool shouldRepaint(_ShelfPainter old) => old.seed != seed;
}

// ---------- книга ----------

const List<Color> _palette = [
  Color(0xFF7B2D26),
  Color(0xFF2F5D3A),
  Color(0xFF22405F),
  Color(0xFF5B3A29),
  Color(0xFF4B2E5C),
  Color(0xFF1F5B5E),
  Color(0xFF3C3C44),
  Color(0xFF8A5A1C),
];

class _BookCover extends StatelessWidget {
  const _BookCover({
    required this.book,
    required this.width,
    required this.height,
    required this.onTap,
    required this.onLongPress,
  });

  final BookEntry book;
  final double width;
  final double height;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  @override
  Widget build(BuildContext context) {
    final base = _palette[book.title.hashCode.abs() % _palette.length];
    final hsl = HSLColor.fromColor(base);
    final dark = hsl.withLightness((hsl.lightness - 0.09).clamp(0.0, 1.0).toDouble()).toColor();
    final titleSize = (width * 0.115).clamp(11.0, 16.0).toDouble();
    final pct = (book.progress * 100).floor();

    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(3),
            topRight: Radius.circular(6),
            bottomLeft: Radius.circular(3),
            bottomRight: Radius.circular(6),
          ),
          gradient: LinearGradient(
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
            colors: [dark, base, base, dark],
            stops: const [0.0, 0.12, 0.65, 1.0],
          ),
          boxShadow: const [
            BoxShadow(color: Colors.black54, blurRadius: 8, offset: Offset(2, 4)),
          ],
        ),
        child: Stack(
          children: [
            // корешок
            Positioned(
              left: 0,
              top: 0,
              bottom: 0,
              width: width * 0.09,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.black.withValues(alpha: 0.35),
                      Colors.black.withValues(alpha: 0.0),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              left: width * 0.09,
              top: 0,
              bottom: 0,
              width: 1,
              child: ColoredBox(color: _gold.withValues(alpha: 0.45)),
            ),
            // золотая рамка
            Positioned.fill(
              child: Container(
                margin: EdgeInsets.fromLTRB(width * 0.13, 7, 7, 7),
                decoration: BoxDecoration(
                  border: Border.all(color: _gold.withValues(alpha: 0.28)),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(width * 0.19, height * 0.08, width * 0.10, height * 0.06),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(width: width * 0.22, height: 1.4, color: _gold.withValues(alpha: 0.8)),
                  const SizedBox(height: 7),
                  Expanded(
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        book.title,
                        maxLines: 5,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: 'serif',
                          fontSize: titleSize,
                          fontWeight: FontWeight.w600,
                          height: 1.2,
                          color: _cream,
                        ),
                      ),
                    ),
                  ),
                  if (book.author.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Text(
                        book.author,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: 'serif',
                          fontSize: titleSize * 0.78,
                          color: _gold.withValues(alpha: 0.9),
                        ),
                      ),
                    ),
                  Row(
                    children: [
                      Text(
                        book.format.toUpperCase(),
                        style: TextStyle(
                          fontSize: 9,
                          color: _gold.withValues(alpha: 0.6),
                          letterSpacing: 0.5,
                        ),
                      ),
                      const Spacer(),
                      if (pct > 0)
                        Text(
                          '$pct%',
                          style: TextStyle(fontSize: 9, color: _gold.withValues(alpha: 0.8)),
                        ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(2),
                    child: LinearProgressIndicator(
                      value: book.progress,
                      minHeight: 3,
                      color: _gold,
                      backgroundColor: Colors.black26,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
