import 'package:flutter/material.dart';

import 'data/library_store.dart';
import 'data/reader_settings.dart';
import 'ui/library_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final library = LibraryStore();
  final settings = ReaderSettings();
  await Future.wait([library.load(), settings.load()]);
  runApp(LibraryApp(library: library, settings: settings));
}

class LibraryApp extends StatelessWidget {
  const LibraryApp({super.key, required this.library, required this.settings});

  final LibraryStore library;
  final ReaderSettings settings;

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF3D5A80);
    return MaterialApp(
      title: 'Библиотека',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.system,
      theme: ThemeData(colorSchemeSeed: seed, useMaterial3: true),
      darkTheme: ThemeData(
        colorSchemeSeed: seed,
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: LibraryScreen(library: library, settings: settings),
    );
  }
}
