import 'package:flutter/material.dart';

import 'data/library_store.dart';
import 'data/reader_settings.dart';
import 'tts/tts_global.dart';
import 'ui/library_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final library = LibraryStore();
  final settings = ReaderSettings();
  await Future.wait([library.load(), settings.load()]);
  await initTts();
  runApp(LibraryApp(library: library, settings: settings));
}

class LibraryApp extends StatelessWidget {
  const LibraryApp({super.key, required this.library, required this.settings});

  final LibraryStore library;
  final ReaderSettings settings;

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF8B5A2B);
    return MaterialApp(
      title: 'Библиотека',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.system,
      theme: ThemeData(colorSchemeSeed: seed, useMaterial3: true),
      darkTheme: ThemeData(
        colorSchemeSeed: seed,
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: LibraryScreen(library: library, settings: settings),
    );
  }
}
