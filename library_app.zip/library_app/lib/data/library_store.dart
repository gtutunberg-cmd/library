import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import '../parsers/book_loader.dart';

/// Заметка или цитата: фрагмент текста + комментарий.
class BookNote {
  final int offset;
  final String quote;
  final String text;
  final int at;
  const BookNote({required this.offset, required this.quote, required this.text, required this.at});

  Map<String, dynamic> toJson() => {'offset': offset, 'quote': quote, 'text': text, 'at': at};

  factory BookNote.fromJson(Map<String, dynamic> j) => BookNote(
        offset: (j['offset'] as num?)?.toInt() ?? 0,
        quote: (j['quote'] as String?) ?? '',
        text: (j['text'] as String?) ?? '',
        at: (j['at'] as num?)?.toInt() ?? 0,
      );
}

class BookEntry {
  final String id;
  String title;
  String author;
  final String path;
  final String format;
  int lastOffset;
  int totalChars;
  final int addedAt;
  int lastOpenedAt;

  /// Закладки: смещения (в символах) начала страниц.
  List<int> bookmarks;

  /// Заметки и цитаты.
  List<BookNote> notes;

  bool favorite;
  bool finished;

  /// Откуда импортирована (имя|размер), чтобы не добавлять дважды при сканировании.
  String src;

  BookEntry({
    required this.id,
    required this.title,
    required this.author,
    required this.path,
    required this.format,
    this.lastOffset = 0,
    this.totalChars = 0,
    required this.addedAt,
    required this.lastOpenedAt,
    List<int>? bookmarks,
    List<BookNote>? notes,
    this.favorite = false,
    this.finished = false,
    this.src = '',
  })  : bookmarks = bookmarks ?? <int>[],
        notes = notes ?? <BookNote>[];

  bool get isFinished => finished || progress >= 0.97;

  bool get isReading => lastOffset > 0 && !isFinished;

  double get progress =>
      totalChars <= 0 ? 0.0 : (lastOffset / totalChars).clamp(0.0, 1.0).toDouble();

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'author': author,
        'path': path,
        'format': format,
        'lastOffset': lastOffset,
        'totalChars': totalChars,
        'addedAt': addedAt,
        'lastOpenedAt': lastOpenedAt,
        'bookmarks': bookmarks,
        'notes': [for (final n in notes) n.toJson()],
        'favorite': favorite,
        'finished': finished,
        'src': src,
      };

  factory BookEntry.fromJson(Map<String, dynamic> j) => BookEntry(
        id: j['id'] as String,
        title: (j['title'] as String?) ?? 'Без названия',
        author: (j['author'] as String?) ?? '',
        path: j['path'] as String,
        format: (j['format'] as String?) ?? 'txt',
        lastOffset: (j['lastOffset'] as num?)?.toInt() ?? 0,
        totalChars: (j['totalChars'] as num?)?.toInt() ?? 0,
        addedAt: (j['addedAt'] as num?)?.toInt() ?? 0,
        lastOpenedAt: (j['lastOpenedAt'] as num?)?.toInt() ?? 0,
        bookmarks: [
          for (final b in (j['bookmarks'] as List? ?? const [])) (b as num).toInt(),
        ],
        notes: [
          for (final n in (j['notes'] as List? ?? const []))
            BookNote.fromJson(Map<String, dynamic>.from(n as Map)),
        ],
        favorite: (j['favorite'] as bool?) ?? false,
        finished: (j['finished'] as bool?) ?? false,
        src: (j['src'] as String?) ?? '',
      );
}

/// Библиотека: список книг + копии файлов во внутренней папке приложения.
class LibraryStore extends ChangeNotifier {
  final List<BookEntry> _books = [];
  late Directory _booksDir;
  late File _indexFile;

  List<BookEntry> get books {
    final copy = List<BookEntry>.of(_books);
    copy.sort((a, b) => b.lastOpenedAt.compareTo(a.lastOpenedAt));
    return copy;
  }

  Future<void> load() async {
    final docs = await getApplicationDocumentsDirectory();
    _booksDir = Directory('${docs.path}/books');
    await _booksDir.create(recursive: true);
    _indexFile = File('${docs.path}/library.json');
    if (await _indexFile.exists()) {
      try {
        final list = jsonDecode(await _indexFile.readAsString()) as List<dynamic>;
        _books
          ..clear()
          ..addAll(list.map((e) => BookEntry.fromJson(e as Map<String, dynamic>)));
      } catch (_) {
        // повреждённый индекс — начинаем с пустой библиотеки
      }
    }
  }

  Future<void> _save() async {
    await _indexFile.writeAsString(jsonEncode(_books.map((b) => b.toJson()).toList()));
  }

  /// Копирует файл в библиотеку и добавляет книгу. Бросает исключение, если файл не читается.
  Future<BookEntry> importFile(String sourcePath, String originalName, {String src = ''}) async {
    final format = formatOf(originalName);
    if (format == null) {
      throw FormatException('Формат не поддерживается');
    }
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    final target = '${_booksDir.path}/$id.$format';
    await File(sourcePath).copy(target);

    final fallbackTitle = baseNameWithoutExt(originalName);
    try {
      final content = await loadBook(target, format, fallbackTitle: fallbackTitle);
      final now = DateTime.now().millisecondsSinceEpoch;
      final entry = BookEntry(
        id: id,
        title: content.title.isEmpty ? fallbackTitle : content.title,
        author: content.author,
        path: target,
        format: format,
        totalChars: content.totalChars,
        addedAt: now,
        lastOpenedAt: now,
        src: src,
      );
      _books.add(entry);
      await _save();
      notifyListeners();
      return entry;
    } catch (_) {
      try {
        await File(target).delete();
      } catch (_) {}
      rethrow;
    }
  }

  Future<void> remove(BookEntry book) async {
    _books.removeWhere((b) => b.id == book.id);
    try {
      await File(book.path).delete();
    } catch (_) {}
    await _save();
    notifyListeners();
  }

  void touch(BookEntry book) {
    book.lastOpenedAt = DateTime.now().millisecondsSinceEpoch;
    _save();
  }

  void changed() {
    _save();
    notifyListeners();
  }

  void toggleFavorite(BookEntry b) {
    b.favorite = !b.favorite;
    changed();
  }

  void toggleFinished(BookEntry b) {
    b.finished = !b.isFinished;
    if (!b.finished && b.progress >= 0.97) b.lastOffset = 0;
    changed();
  }

  void addNote(BookEntry b, BookNote n) {
    b.notes = [...b.notes, n]..sort((a, c) => a.offset.compareTo(c.offset));
    changed();
  }

  void removeNote(BookEntry b, BookNote n) {
    b.notes = [for (final x in b.notes) if (!identical(x, n)) x];
    changed();
  }

  /// Ищет книги в папке (с вложенными) и добавляет новые.
  /// Возвращает (добавлено, ошибок).
  Future<(int, int)> scanFolder(String dir) async {
    var added = 0;
    var failed = 0;
    final known = {for (final b in _books) b.src};
    final files = <File>[];
    try {
      await for (final e in Directory(dir).list(recursive: true, followLinks: false)) {
        if (e is File && formatOf(e.path) != null) files.add(e);
      }
    } catch (_) {
      // часть папок может быть недоступна — берём что нашли
    }
    for (final f in files) {
      final name = f.path.split('/').last;
      int size;
      try {
        size = await f.length();
      } catch (_) {
        continue;
      }
      final key = '$name|$size';
      if (known.contains(key)) continue;
      try {
        await importFile(f.path, name, src: key);
        known.add(key);
        added++;
      } catch (_) {
        failed++;
      }
    }
    return (added, failed);
  }

  /// Резервная копия: закладки, заметки, избранное и прогресс (без самих файлов книг).
  String exportBackup(Map<String, dynamic> settings) => jsonEncode({
        'app': 'ebook_reader',
        'version': 1,
        'settings': settings,
        'books': [
          for (final b in _books)
            {
              'title': b.title,
              'author': b.author,
              'lastOffset': b.lastOffset,
              'bookmarks': b.bookmarks,
              'notes': [for (final n in b.notes) n.toJson()],
              'favorite': b.favorite,
              'finished': b.finished,
            },
        ],
      });

  /// Восстанавливает данные для книг, которые уже есть в библиотеке.
  /// Возвращает (число совпавших книг, настройки из копии).
  (int, Map<String, dynamic>) restoreBackup(String raw) {
    final j = jsonDecode(raw) as Map<String, dynamic>;
    var matched = 0;
    for (final item in (j['books'] as List? ?? const [])) {
      final m = Map<String, dynamic>.from(item as Map);
      for (final b in _books) {
        if (b.title == m['title'] && b.author == (m['author'] ?? '')) {
          b.lastOffset = (m['lastOffset'] as num?)?.toInt() ?? b.lastOffset;
          b.bookmarks = [
            for (final x in (m['bookmarks'] as List? ?? const [])) (x as num).toInt(),
          ];
          b.notes = [
            for (final n in (m['notes'] as List? ?? const []))
              BookNote.fromJson(Map<String, dynamic>.from(n as Map)),
          ];
          b.favorite = (m['favorite'] as bool?) ?? false;
          b.finished = (m['finished'] as bool?) ?? false;
          matched++;
        }
      }
    }
    changed();
    final s = j['settings'];
    return (matched, s is Map ? Map<String, dynamic>.from(s) : <String, dynamic>{});
  }

  void setBookmarks(BookEntry book, List<int> offsets) {
    book.bookmarks = offsets;
    _save();
    notifyListeners();
  }

  void saveProgress(BookEntry book, int offset, int total) {
    book.lastOffset = offset;
    if (total > 0) book.totalChars = total;
    book.lastOpenedAt = DateTime.now().millisecondsSinceEpoch;
    _save();
    notifyListeners();
  }
}
