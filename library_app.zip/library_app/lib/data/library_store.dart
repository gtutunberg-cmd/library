import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import '../parsers/book_loader.dart';

class BookEntry {
  final String id;
  String title;
  String author;
  final String path;
  final String format;
  int lastOffset;
  int totalChars;
  final int addedAt;
  int lastOpenedAt;

  /// Закладки: смещения (в символах) начала страниц.
  List<int> bookmarks;

  BookEntry({
    required this.id,
    required this.title,
    required this.author,
    required this.path,
    required this.format,
    this.lastOffset = 0,
    this.totalChars = 0,
    required this.addedAt,
    required this.lastOpenedAt,
    List<int>? bookmarks,
  }) : bookmarks = bookmarks ?? <int>[];

  double get progress =>
      totalChars <= 0 ? 0.0 : (lastOffset / totalChars).clamp(0.0, 1.0).toDouble();

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'author': author,
        'path': path,
        'format': format,
        'lastOffset': lastOffset,
        'totalChars': totalChars,
        'addedAt': addedAt,
        'lastOpenedAt': lastOpenedAt,
        'bookmarks': bookmarks,
      };

  factory BookEntry.fromJson(Map<String, dynamic> j) => BookEntry(
        id: j['id'] as String,
        title: (j['title'] as String?) ?? 'Без названия',
        author: (j['author'] as String?) ?? '',
        path: j['path'] as String,
        format: (j['format'] as String?) ?? 'txt',
        lastOffset: (j['lastOffset'] as num?)?.toInt() ?? 0,
        totalChars: (j['totalChars'] as num?)?.toInt() ?? 0,
        addedAt: (j['addedAt'] as num?)?.toInt() ?? 0,
        lastOpenedAt: (j['lastOpenedAt'] as num?)?.toInt() ?? 0,
        bookmarks: [
          for (final b in (j['bookmarks'] as List? ?? const [])) (b as num).toInt(),
        ],
      );
}

/// Библиотека: список книг + копии файлов во внутренней папке приложения.
class LibraryStore extends ChangeNotifier {
  final List<BookEntry> _books = [];
  late Directory _booksDir;
  late File _indexFile;

  List<BookEntry> get books {
    final copy = List<BookEntry>.of(_books);
    copy.sort((a, b) => b.lastOpenedAt.compareTo(a.lastOpenedAt));
    return copy;
  }

  Future<void> load() async {
    final docs = await getApplicationDocumentsDirectory();
    _booksDir = Directory('${docs.path}/books');
    await _booksDir.create(recursive: true);
    _indexFile = File('${docs.path}/library.json');
    if (await _indexFile.exists()) {
      try {
        final list = jsonDecode(await _indexFile.readAsString()) as List<dynamic>;
        _books
          ..clear()
          ..addAll(list.map((e) => BookEntry.fromJson(e as Map<String, dynamic>)));
      } catch (_) {
        // повреждённый индекс — начинаем с пустой библиотеки
      }
    }
  }

  Future<void> _save() async {
    await _indexFile.writeAsString(jsonEncode(_books.map((b) => b.toJson()).toList()));
  }

  /// Копирует файл в библиотеку и добавляет книгу. Бросает исключение, если файл не читается.
  Future<BookEntry> importFile(String sourcePath, String originalName) async {
    final format = formatOf(originalName);
    if (format == null) {
      throw FormatException('Формат не поддерживается');
    }
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    final target = '${_booksDir.path}/$id.$format';
    await File(sourcePath).copy(target);

    final fallbackTitle = baseNameWithoutExt(originalName);
    try {
      final content = await loadBook(target, format, fallbackTitle: fallbackTitle);
      final now = DateTime.now().millisecondsSinceEpoch;
      final entry = BookEntry(
        id: id,
        title: content.title.isEmpty ? fallbackTitle : content.title,
        author: content.author,
        path: target,
        format: format,
        totalChars: content.totalChars,
        addedAt: now,
        lastOpenedAt: now,
      );
      _books.add(entry);
      await _save();
      notifyListeners();
      return entry;
    } catch (_) {
      try {
        await File(target).delete();
      } catch (_) {}
      rethrow;
    }
  }

  Future<void> remove(BookEntry book) async {
    _books.removeWhere((b) => b.id == book.id);
    try {
      await File(book.path).delete();
    } catch (_) {}
    await _save();
    notifyListeners();
  }

  void touch(BookEntry book) {
    book.lastOpenedAt = DateTime.now().millisecondsSinceEpoch;
    _save();
  }

  void setBookmarks(BookEntry book, List<int> offsets) {
    book.bookmarks = offsets;
    _save();
    notifyListeners();
  }

  void saveProgress(BookEntry book, int offset, int total) {
    book.lastOffset = offset;
    if (total > 0) book.totalChars = total;
    book.lastOpenedAt = DateTime.now().millisecondsSinceEpoch;
    _save();
    notifyListeners();
  }
}
