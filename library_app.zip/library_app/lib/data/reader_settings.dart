import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ReaderThemeData {
  final String name;
  final Color bg;
  final Color fg;
  const ReaderThemeData(this.name, this.bg, this.fg);
}

const readerThemes = <ReaderThemeData>[
  ReaderThemeData('Светлая', Color(0xFFFBFAF7), Color(0xFF1C1C1C)),
  ReaderThemeData('Сепия', Color(0xFFF3E8D0), Color(0xFF4A3B2A)),
  ReaderThemeData('Тёмная', Color(0xFF121212), Color(0xFFC9C9C9)),
];

/// Настройки читалки. Сохраняются между запусками.
class ReaderSettings extends ChangeNotifier {
  double fontSize = 19;
  double lineHeight = 1.5;
  int themeIndex = 0;
  bool serif = true;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    fontSize = p.getDouble('fontSize') ?? fontSize;
    lineHeight = p.getDouble('lineHeight') ?? lineHeight;
    themeIndex =
        (p.getInt('themeIndex') ?? themeIndex).clamp(0, readerThemes.length - 1).toInt();
    serif = p.getBool('serif') ?? serif;
  }

  Future<void> update({
    double? fontSize,
    double? lineHeight,
    int? themeIndex,
    bool? serif,
  }) async {
    this.fontSize = fontSize ?? this.fontSize;
    this.lineHeight = lineHeight ?? this.lineHeight;
    this.themeIndex = themeIndex ?? this.themeIndex;
    this.serif = serif ?? this.serif;
    notifyListeners();
    final p = await SharedPreferences.getInstance();
    await p.setDouble('fontSize', this.fontSize);
    await p.setDouble('lineHeight', this.lineHeight);
    await p.setInt('themeIndex', this.themeIndex);
    await p.setBool('serif', this.serif);
  }
}
