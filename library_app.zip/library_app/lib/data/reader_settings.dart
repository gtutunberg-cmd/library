import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ReaderThemeData {
  final String name;
  final Color bg;
  final Color fg;
  const ReaderThemeData(this.name, this.bg, this.fg);
}

const readerThemes = <ReaderThemeData>[
  ReaderThemeData('Светлая', Color(0xFFFBFAF7), Color(0xFF1C1C1C)),
  ReaderThemeData('Сепия', Color(0xFFF3E8D0), Color(0xFF4A3B2A)),
  ReaderThemeData('Тёмная', Color(0xFF121212), Color(0xFFC9C9C9)),
];

/// Настройки читалки. Сохраняются между запусками.
class ReaderSettings extends ChangeNotifier {
  double fontSize = 19;
  double lineHeight = 1.5;
  int themeIndex = 1;
  bool serif = true;

  /// Выравнивание текста: 0 — слева, 1 — по центру, 2 — справа, 3 — по ширине.
  int textAlign = 0;

  /// Скорость речи: 0.5 — обычная, 0.3 — медленно, 0.9 — быстро.
  double ttsRate = 0.5;

  /// Тембр голоса: 1.0 — обычный.
  double ttsPitch = 1.0;

  /// Выбранный голос ('' — по умолчанию) и его язык.
  String ttsVoice = '';
  String ttsVoiceLocale = 'ru-RU';

  /// Свой шрифт: путь к файлу в папке приложения и имя семейства ('' — нет).
  String fontFile = '';
  String fontFamilyName = '';

  /// Шрифт для текста книги.
  String? get fontFamily =>
      fontFamilyName.isNotEmpty ? fontFamilyName : (serif ? 'serif' : null);

  /// Регистрирует свой шрифт в движке. Возвращает false, если не вышло.
  Future<bool> loadCustomFont() async {
    if (fontFile.isEmpty) return false;
    try {
      final f = File(fontFile);
      if (!await f.exists()) return false;
      final bytes = await f.readAsBytes();
      final family = 'UF${fontFile.hashCode.abs()}';
      final loader = FontLoader(family)
        ..addFont(Future.value(ByteData.sublistView(bytes)));
      await loader.load();
      fontFamilyName = family;
      return true;
    } catch (_) {
      fontFamilyName = '';
      return false;
    }
  }

  /// Выбрать другой шрифт ('' — вернуть обычный).
  Future<bool> setCustomFont(String path) async {
    fontFile = path;
    fontFamilyName = '';
    final ok = path.isEmpty ? true : await loadCustomFont();
    if (!ok) fontFile = '';
    await update();
    return ok;
  }

  Map<String, dynamic> toJson() => {
        'fontSize': fontSize,
        'lineHeight': lineHeight,
        'themeIndex': themeIndex,
        'serif': serif,
        'textAlign': textAlign,
        'ttsRate': ttsRate,
        'ttsPitch': ttsPitch,
        'sound': sound,
      };

  Future<void> applyJson(Map<String, dynamic> j) {
    return update(
      fontSize: (j['fontSize'] as num?)?.toDouble(),
      lineHeight: (j['lineHeight'] as num?)?.toDouble(),
      themeIndex: (j['themeIndex'] as num?)?.toInt(),
      serif: j['serif'] as bool?,
      textAlign: (j['textAlign'] as num?)?.toInt(),
      ttsRate: (j['ttsRate'] as num?)?.toDouble(),
      ttsPitch: (j['ttsPitch'] as num?)?.toDouble(),
      sound: j['sound'] as bool?,
    );
  }

  /// Шелест бумаги при листании.
  bool sound = true;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    fontSize = p.getDouble('fontSize') ?? fontSize;
    lineHeight = p.getDouble('lineHeight') ?? lineHeight;
    themeIndex =
        (p.getInt('themeIndex') ?? themeIndex).clamp(0, readerThemes.length - 1).toInt();
    serif = p.getBool('serif') ?? serif;
    textAlign = (p.getInt('textAlign') ?? 0).clamp(0, 3).toInt();
    ttsRate = p.getDouble('ttsRate') ?? ttsRate;
    ttsPitch = p.getDouble('ttsPitch') ?? ttsPitch;
    ttsVoice = p.getString('ttsVoice') ?? ttsVoice;
    ttsVoiceLocale = p.getString('ttsVoiceLocale') ?? ttsVoiceLocale;
    sound = p.getBool('sound') ?? sound;
    fontFile = p.getString('fontFile') ?? '';
    await loadCustomFont();
  }

  Future<void> update({
    double? fontSize,
    double? lineHeight,
    int? themeIndex,
    bool? serif,
    int? textAlign,
    double? ttsRate,
    double? ttsPitch,
    String? ttsVoice,
    String? ttsVoiceLocale,
    bool? sound,
  }) async {
    this.fontSize = fontSize ?? this.fontSize;
    this.lineHeight = lineHeight ?? this.lineHeight;
    this.themeIndex = themeIndex ?? this.themeIndex;
    this.serif = serif ?? this.serif;
    this.textAlign = textAlign ?? this.textAlign;
    this.ttsRate = ttsRate ?? this.ttsRate;
    this.ttsPitch = ttsPitch ?? this.ttsPitch;
    this.ttsVoice = ttsVoice ?? this.ttsVoice;
    this.ttsVoiceLocale = ttsVoiceLocale ?? this.ttsVoiceLocale;
    this.sound = sound ?? this.sound;
    notifyListeners();
    final p = await SharedPreferences.getInstance();
    await p.setDouble('fontSize', this.fontSize);
    await p.setDouble('lineHeight', this.lineHeight);
    await p.setInt('themeIndex', this.themeIndex);
    await p.setBool('serif', this.serif);
    await p.setInt('textAlign', this.textAlign);
    await p.setDouble('ttsRate', this.ttsRate);
    await p.setDouble('ttsPitch', this.ttsPitch);
    await p.setString('ttsVoice', this.ttsVoice);
    await p.setString('ttsVoiceLocale', this.ttsVoiceLocale);
    await p.setBool('sound', this.sound);
    await p.setString('fontFile', fontFile);
  }
}
