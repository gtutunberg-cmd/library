import 'package:html/dom.dart' as dom;
import 'package:html/parser.dart' as html_parser;

class HtmlBlock {
  final String text;
  final bool heading;
  const HtmlBlock(this.text, this.heading);
}

const _skipTags = {
  'script', 'style', 'head', 'svg', 'img', 'nav', 'noscript', 'object', //
};

const _blockTags = {
  'p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'blockquote', 'tr',
  'section', 'article', 'pre', 'ul', 'ol', 'table', 'dd', 'dt', 'hr',
  'header', 'footer', 'figure', 'figcaption', 'aside', 'body',
};

final _headingTag = RegExp(r'^h[1-6]$');
final _spaces = RegExp(r'[\s ]+');

/// Превращает HTML/XHTML в плоский список текстовых блоков.
List<HtmlBlock> htmlToBlocks(String source) {
  final doc = html_parser.parse(source);
  final body = doc.body;
  if (body == null) return const [];

  final blocks = <HtmlBlock>[];
  final buf = StringBuffer();

  void flush({bool heading = false}) {
    final t = buf.toString().replaceAll(_spaces, ' ').trim();
    buf.clear();
    if (t.isNotEmpty) blocks.add(HtmlBlock(t, heading));
  }

  void walk(dom.Node node) {
    if (node is dom.Text) {
      buf.write(node.text);
      return;
    }
    if (node is! dom.Element) return;
    final tag = node.localName ?? '';
    if (_skipTags.contains(tag)) return;
    if (tag == 'br') {
      flush();
      return;
    }
    final isBlock = _blockTags.contains(tag);
    final isHeading = _headingTag.hasMatch(tag);
    if (isBlock) flush();
    for (final child in node.nodes) {
      walk(child);
    }
    if (isBlock) flush(heading: isHeading);
  }

  walk(body);
  flush();
  return blocks;
}

/// Содержимое тега <title>, если есть.
String htmlTitle(String source) {
  final m = RegExp(r'<title[^>]*>(.*?)</title>',
          caseSensitive: false, dotAll: true)
      .firstMatch(source);
  if (m == null) return '';
  return (m.group(1) ?? '').replaceAll(_spaces, ' ').trim();
}
