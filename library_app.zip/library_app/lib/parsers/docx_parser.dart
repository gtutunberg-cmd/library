import 'dart:convert';

import 'package:archive/archive.dart';
import 'package:xml/xml.dart';

import 'book_content.dart';
import 'text_utils.dart';

final _headingStyle = RegExp(r'^(heading|заголовок|title)', caseSensitive: false);

/// DOCX: берём абзацы из word/document.xml, стили Heading* становятся главами.
BookContent parseDocx(List<int> bytes, String fallbackTitle) {
  final archive = ZipDecoder().decodeBytes(bytes);
  ArchiveFile? file;
  for (final f in archive.files) {
    if (f.isFile && f.name == 'word/document.xml') {
      file = f;
      break;
    }
  }
  if (file == null) throw const FormatException('Это не DOCX');

  final doc = XmlDocument.parse(utf8.decode(file.content as List<int>));
  final paragraphs = <String>[];
  final chapters = <ChapterMark>[];

  for (final p in descendantsByLocal(doc, 'p')) {
    final sb = StringBuffer();
    for (final e in p.descendants.whereType<XmlElement>()) {
      switch (e.name.local) {
        case 't':
          sb.write(e.innerText);
        case 'tab' || 'br':
          sb.write(' ');
        default:
          break;
      }
    }
    final text = collapse(sb.toString());
    if (text.isEmpty) continue;

    final styleEl = descendantsByLocal(p, 'pStyle').firstOrNull;
    final style = styleEl?.attributes
        .where((a) => a.name.local == 'val')
        .firstOrNull
        ?.value;
    if (style != null && _headingStyle.hasMatch(style) && text.length <= 150) {
      chapters.add(ChapterMark(text, paragraphs.length));
    }
    paragraphs.add(text);
  }

  if (paragraphs.isEmpty) throw const FormatException('В документе нет текста');
  return BookContent(
    title: fallbackTitle,
    author: '',
    paragraphs: paragraphs,
    chapters: chapters,
  );
}
