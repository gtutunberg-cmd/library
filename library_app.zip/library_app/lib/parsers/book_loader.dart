import 'dart:io';

import 'package:archive/archive.dart';

import 'package:flutter/foundation.dart';

import 'book_content.dart';
import 'docx_parser.dart';
import 'epub_parser.dart';
import 'fb2_parser.dart';
import 'mobi_parser.dart';
import 'rtf_parser.dart';
import 'text_parser.dart';

/// Определяет формат по имени файла. null — формат не поддерживается.
String? formatOf(String fileName) {
  final n = fileName.toLowerCase();
  if (n.endsWith('.fb2.zip') || n.endsWith('.fb2')) return 'fb2';
  if (n.endsWith('.epub')) return 'epub';
  if (n.endsWith('.txt')) return 'txt';
  if (n.endsWith('.md') || n.endsWith('.markdown')) return 'md';
  if (n.endsWith('.html') || n.endsWith('.htm') || n.endsWith('.xhtml')) {
    return 'html';
  }
  if (n.endsWith('.docx')) return 'docx';
  if (n.endsWith('.rtf')) return 'rtf';
  if (n.endsWith('.mobi') || n.endsWith('.azw') || n.endsWith('.azw3') || n.endsWith('.prc')) {
    return 'mobi';
  }
  if (n.endsWith('.zip')) return 'zip';
  if (n.endsWith('.pdf')) return 'pdf';
  return null;
}

/// Имя файла без расширения (для названия по умолчанию).
String baseNameWithoutExt(String fileName) {
  var name = fileName.split('/').last;
  final lower = name.toLowerCase();
  if (lower.endsWith('.fb2.zip')) {
    return name.substring(0, name.length - 8);
  }
  final dot = name.lastIndexOf('.');
  if (dot > 0) name = name.substring(0, dot);
  return name;
}

class _LoadArgs {
  final String path;
  final String format;
  final String fallbackTitle;
  const _LoadArgs(this.path, this.format, this.fallbackTitle);
}

/// Читает и разбирает книгу в отдельном изоляте, чтобы не тормозить интерфейс.
Future<BookContent> loadBook(
  String path,
  String format, {
  String fallbackTitle = '',
}) {
  return compute(_load, _LoadArgs(path, format, fallbackTitle));
}

BookContent _load(_LoadArgs a) {
  final bytes = File(a.path).readAsBytesSync();
  return _parseBytes(bytes, a.format, a.fallbackTitle);
}

/// ZIP с книгой внутри (fb2, epub, txt, docx...): берём первую подходящую книгу.
BookContent _fromZip(List<int> bytes, String fallbackTitle) {
  final Archive archive;
  try {
    archive = ZipDecoder().decodeBytes(bytes);
  } catch (_) {
    throw const FormatException('Не удалось открыть архив');
  }
  const order = ['fb2', 'epub', 'mobi', 'docx', 'rtf', 'html', 'md', 'txt'];
  final books = <ArchiveFile>[];
  for (final f in archive.files) {
    if (!f.isFile) continue;
    final fmt = formatOf(f.name);
    if (fmt != null && fmt != 'zip' && fmt != 'pdf') books.add(f);
  }
  if (books.isEmpty) {
    throw const FormatException('В архиве нет книг поддерживаемых форматов');
  }
  books.sort((a, b) =>
      order.indexOf(formatOf(a.name)!).compareTo(order.indexOf(formatOf(b.name)!)));
  Object? lastError;
  for (final f in books) {
    try {
      return _parseBytes(
        f.content as List<int>,
        formatOf(f.name)!,
        baseNameWithoutExt(f.name.split('/').last),
      );
    } catch (e) {
      lastError = e;
    }
  }
  if (lastError is FormatException) throw lastError;
  throw FormatException('Не удалось прочитать книгу из архива: $lastError');
}

BookContent _parseBytes(List<int> bytes, String format, String fallbackTitle) {
  final a = _LoadArgs('', format, fallbackTitle);
  switch (a.format) {
    case 'zip':
      return _fromZip(bytes, a.fallbackTitle);
    case 'fb2':
      return parseFb2(bytes, a.fallbackTitle);
    case 'epub':
      return parseEpub(bytes, a.fallbackTitle);
    case 'txt':
      return parseTxt(bytes, a.fallbackTitle);
    case 'md':
      return parseMd(bytes, a.fallbackTitle);
    case 'html':
      return parseHtmlFile(bytes, a.fallbackTitle);
    case 'docx':
      return parseDocx(bytes, a.fallbackTitle);
    case 'rtf':
      return parseRtf(bytes, a.fallbackTitle);
    case 'mobi':
      return parseMobi(bytes, a.fallbackTitle);
    case 'pdf':
      throw const FormatException('PDF будет добавлен на следующем этапе');
    default:
      throw FormatException('Формат не поддерживается: ${a.format}');
  }
}
