import 'book_content.dart';
import 'html_text.dart';
import 'text_utils.dart';

final _chapterLine = RegExp(
  r'^(?:глава|часть|книга|пролог|эпилог|chapter|part|prologue|epilogue)(?:\s|\d|$|[.:!])',
  caseSensitive: false,
);

/// Обычный текстовый файл. Каждая непустая строка — абзац.
BookContent parseTxt(List<int> bytes, String fallbackTitle) {
  final text = decodeText(bytes).replaceAll('\r\n', '\n').replaceAll('\r', '\n');
  final paragraphs = <String>[];
  final chapters = <ChapterMark>[];
  for (final line in text.split('\n')) {
    final t = collapse(line);
    if (t.isEmpty) continue;
    if (t.length <= 80 && _chapterLine.hasMatch(t)) {
      chapters.add(ChapterMark(t, paragraphs.length));
    }
    paragraphs.add(t);
  }
  if (paragraphs.isEmpty) throw const FormatException('Файл пустой');
  return BookContent(
    title: fallbackTitle,
    author: '',
    paragraphs: paragraphs,
    chapters: chapters,
  );
}

/// Markdown: убираем разметку, заголовки (#) становятся главами.
BookContent parseMd(List<int> bytes, String fallbackTitle) {
  final text = decodeText(bytes).replaceAll('\r\n', '\n').replaceAll('\r', '\n');
  final paragraphs = <String>[];
  final chapters = <ChapterMark>[];
  var inCode = false;
  for (final raw in text.split('\n')) {
    var line = raw.trim();
    if (line.startsWith('```')) {
      inCode = !inCode;
      continue;
    }
    if (line.isEmpty) continue;
    var isHeading = false;
    if (!inCode) {
      final h = RegExp(r'^#{1,6}\s+').firstMatch(line);
      if (h != null) {
        isHeading = true;
        line = line.substring(h.end);
      }
      line = line
          .replaceFirst(RegExp(r'^>\s?'), '')
          .replaceFirst(RegExp(r'^[-*+]\s+'), '')
          .replaceAll('**', '')
          .replaceAll('__', '')
          .replaceAll('`', '');
      line = line.replaceAllMapped(
          RegExp(r'\[([^\]]+)\]\([^)]*\)'), (m) => m.group(1) ?? '');
    }
    final t = collapse(line);
    if (t.isEmpty) continue;
    if (isHeading) chapters.add(ChapterMark(t, paragraphs.length));
    paragraphs.add(t);
  }
  if (paragraphs.isEmpty) throw const FormatException('Файл пустой');
  return BookContent(
    title: fallbackTitle,
    author: '',
    paragraphs: paragraphs,
    chapters: chapters,
  );
}

/// Отдельный HTML-файл.
BookContent parseHtmlFile(List<int> bytes, String fallbackTitle) {
  final source = decodeText(bytes);
  final blocks = htmlToBlocks(source);
  if (blocks.isEmpty) throw const FormatException('В файле нет текста');
  final paragraphs = <String>[];
  final chapters = <ChapterMark>[];
  for (final b in blocks) {
    if (b.heading && b.text.length <= 150) {
      chapters.add(ChapterMark(b.text, paragraphs.length));
    }
    paragraphs.add(b.text);
  }
  final title = htmlTitle(source);
  return BookContent(
    title: title.isNotEmpty ? title : fallbackTitle,
    author: '',
    paragraphs: paragraphs,
    chapters: chapters,
  );
}
