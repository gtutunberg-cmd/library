/// Отметка главы: заголовок и индекс абзаца, с которого она начинается.
class ChapterMark {
  final String title;
  final int paragraphIndex;
  const ChapterMark(this.title, this.paragraphIndex);
}

/// Книга в нейтральном виде: список абзацев + оглавление.
/// Все форматы (FB2, EPUB, TXT, DOCX, HTML) приводятся к этому виду.
class BookContent {
  final String title;
  final String author;
  final List<String> paragraphs;
  final List<ChapterMark> chapters;

  const BookContent({
    required this.title,
    required this.author,
    required this.paragraphs,
    required this.chapters,
  });

  /// Общая длина текста (абзац + 1 символ на разделитель).
  int get totalChars {
    var n = 0;
    for (final p in paragraphs) {
      n += p.length + 1;
    }
    return n;
  }

  /// Смещение (в символах) начала каждого абзаца.
  List<int> get paragraphOffsets {
    final result = List<int>.filled(paragraphs.length, 0);
    var n = 0;
    for (var i = 0; i < paragraphs.length; i++) {
      result[i] = n;
      n += paragraphs[i].length + 1;
    }
    return result;
  }
}
