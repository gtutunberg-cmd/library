import 'package:archive/archive.dart';
import 'package:xml/xml.dart';

import 'book_content.dart';
import 'html_text.dart';
import 'text_utils.dart';

String _resolve(String baseDir, String href) {
  var clean = href.split('#').first;
  try {
    clean = Uri.decodeFull(clean);
  } catch (_) {}
  final parts = <String>[];
  for (final seg in (baseDir + clean).split('/')) {
    if (seg.isEmpty || seg == '.') continue;
    if (seg == '..') {
      if (parts.isNotEmpty) parts.removeLast();
    } else {
      parts.add(seg);
    }
  }
  return parts.join('/');
}

const _notText = {
  '.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.bmp', '.css', '.js', '.ttf', '.otf',
  '.woff', '.woff2', '.ncx', '.opf', '.mp3', '.mp4', '.smil', '.pls', '.json', '.txt~',
};

bool _maybeText(String name) {
  final l = name.toLowerCase();
  if (l.startsWith('meta-inf/') || l == 'mimetype') return false;
  final dot = l.lastIndexOf('.');
  if (dot < 0) return true;
  return !_notText.contains(l.substring(dot));
}

/// Сортировка имён с учётом чисел: part2 раньше part10.
int _naturalCompare(String a, String b) {
  final ra = RegExp(r'\d+|\D+').allMatches(a.toLowerCase()).map((m) => m.group(0)!).toList();
  final rb = RegExp(r'\d+|\D+').allMatches(b.toLowerCase()).map((m) => m.group(0)!).toList();
  for (var i = 0; i < ra.length && i < rb.length; i++) {
    final x = ra[i];
    final y = rb[i];
    final nx = int.tryParse(x);
    final ny = int.tryParse(y);
    final c = (nx != null && ny != null) ? nx.compareTo(ny) : x.compareTo(y);
    if (c != 0) return c;
  }
  return ra.length.compareTo(rb.length);
}

/// EPUB: читаем spine в порядке чтения, каждый HTML-файл превращаем в абзацы.
BookContent parseEpub(List<int> bytes, String fallbackTitle) {
  final archive = ZipDecoder().decodeBytes(bytes);
  final files = <String, ArchiveFile>{};
  for (final f in archive.files) {
    if (f.isFile) files[f.name] = f;
  }
  final lower = {for (final e in files.entries) e.key.toLowerCase(): e.value};

  // запасной поиск по имени файла: в архивах бывают другие пути и кодировки имён
  String baseName(String p) => p.split('/').last.toLowerCase();
  final byBase = <String, ArchiveFile>{};
  for (final e in files.entries) {
    byBase.putIfAbsent(baseName(e.key), () => e.value);
  }

  ArchiveFile? find(String path) =>
      files[path] ?? lower[path.toLowerCase()] ?? byBase[baseName(path)];
  List<int> read(ArchiveFile f) => f.content as List<int>;

  // Описание книги (OPF) читаем «мягко»: если оно повреждено или нестандартное,
  // всё равно попробуем достать текст из самих файлов.
  var baseDir = '';
  var title = '';
  var author = '';
  final manifest = <String, ({String href, String type})>{};
  var spine = <String>[];
  try {
    final container = find('META-INF/container.xml');
    String? rootPath;
    if (container != null) {
      final containerDoc = XmlDocument.parse(decodeText(read(container)));
      rootPath = descendantsByLocal(containerDoc, 'rootfile')
          .firstOrNull
          ?.getAttribute('full-path');
    }
    ArchiveFile? opfFile = rootPath == null ? null : find(rootPath);
    if (opfFile == null) {
      for (final e in files.entries) {
        if (e.key.toLowerCase().endsWith('.opf')) {
          opfFile = e.value;
          rootPath = e.key;
          break;
        }
      }
    }
    if (opfFile != null && rootPath != null) {
      final opf = XmlDocument.parse(decodeText(read(opfFile)));
      baseDir =
          rootPath.contains('/') ? rootPath.substring(0, rootPath.lastIndexOf('/') + 1) : '';
      for (final it in descendantsByLocal(opf, 'item')) {
        final id = it.getAttribute('id');
        final href = it.getAttribute('href');
        if (id == null || href == null) continue;
        manifest[id] = (href: href, type: it.getAttribute('media-type') ?? '');
      }
      spine = descendantsByLocal(opf, 'itemref')
          .map((e) => e.getAttribute('idref'))
          .whereType<String>()
          .toList();
      title = collapse(descendantsByLocal(opf, 'title').firstOrNull?.innerText ?? '');
      author = collapse(descendantsByLocal(opf, 'creator').firstOrNull?.innerText ?? '');
    }
  } catch (_) {
    // продолжаем без описания
  }

  final paragraphs = <String>[];
  final chapters = <ChapterMark>[];
  var sectionNo = 0;

  /// Разбирает один файл книги; любые ошибки превращает в пустой результат.
  List<HtmlBlock> blocksOf(ArchiveFile f) {
    try {
      return htmlToBlocks(decodeText(read(f)));
    } catch (_) {
      return const [];
    }
  }

  void addSection(List<HtmlBlock> blocks) {
    if (blocks.isEmpty) return;
    sectionNo++;
    HtmlBlock? heading;
    for (final b in blocks) {
      if (b.heading && b.text.length <= 120) {
        heading = b;
        break;
      }
    }
    final total = blocks.fold<int>(0, (s, b) => s + b.text.length);
    if (heading != null) {
      chapters.add(ChapterMark(heading.text, paragraphs.length));
    } else if (total > 1500) {
      chapters.add(ChapterMark('Раздел $sectionNo', paragraphs.length));
    }
    for (final b in blocks) {
      paragraphs.add(b.text);
    }
  }

  // 1. Основной путь: файлы из spine в порядке чтения.
  //    Тип из манифеста не проверяем (бывают x-oeb1-document и пустые типы),
  //    пропускаем только заведомо не текстовые файлы.
  final used = <String>{};
  for (final id in spine) {
    final item = manifest[id];
    if (item == null || !_maybeText(item.href)) continue;
    final f = find(_resolve(baseDir, item.href));
    if (f == null || !used.add(f.name)) continue;
    addSection(blocksOf(f));
  }

  // 2. Если не вышло, берём из манифеста все текстовые файлы подряд.
  if (paragraphs.isEmpty) {
    for (final item in manifest.values) {
      if (!_maybeText(item.href)) continue;
      final f = find(_resolve(baseDir, item.href));
      if (f == null || !used.add(f.name)) continue;
      addSection(blocksOf(f));
    }
  }

  // 3. Последний шанс: все подходящие файлы архива по имени (с «человеческой» сортировкой).
  if (paragraphs.isEmpty) {
    final names = files.keys.where(_maybeText).toList()..sort(_naturalCompare);
    for (final n in names) {
      addSection(blocksOf(files[n]!));
    }
  }

  if (paragraphs.isEmpty) {
    final exts = <String, int>{};
    for (final n in files.keys) {
      final dot = n.lastIndexOf('.');
      final e = dot < 0 ? '(без расширения)' : n.substring(dot).toLowerCase();
      exts[e] = (exts[e] ?? 0) + 1;
    }
    final top = (exts.entries.toList()..sort((a, b) => b.value.compareTo(a.value)))
        .take(5)
        .map((e) => '${e.key}×${e.value}')
        .join(', ');
    final images = exts.entries
        .where((e) => const ['.jpg', '.jpeg', '.png', '.gif', '.webp'].contains(e.key))
        .fold<int>(0, (s, e) => s + e.value);
    throw FormatException(
      images > files.length / 2
          ? 'В EPUB только картинки (скан без текста) — прочитать его нельзя. [$top]'
          : 'В EPUB нет текста. Файлы: $top; в spine: ${spine.length}',
    );
  }
  return BookContent(
    title: title.isNotEmpty ? title : fallbackTitle,
    author: author,
    paragraphs: paragraphs,
    chapters: chapters,
  );
}
