import 'package:archive/archive.dart';
import 'package:xml/xml.dart';

import 'book_content.dart';
import 'html_text.dart';
import 'text_utils.dart';

String _resolve(String baseDir, String href) {
  var clean = href.split('#').first;
  try {
    clean = Uri.decodeFull(clean);
  } catch (_) {}
  final parts = <String>[];
  for (final seg in (baseDir + clean).split('/')) {
    if (seg.isEmpty || seg == '.') continue;
    if (seg == '..') {
      if (parts.isNotEmpty) parts.removeLast();
    } else {
      parts.add(seg);
    }
  }
  return parts.join('/');
}

/// EPUB: читаем spine в порядке чтения, каждый HTML-файл превращаем в абзацы.
BookContent parseEpub(List<int> bytes, String fallbackTitle) {
  final archive = ZipDecoder().decodeBytes(bytes);
  final files = <String, ArchiveFile>{};
  for (final f in archive.files) {
    if (f.isFile) files[f.name] = f;
  }
  final lower = {for (final e in files.entries) e.key.toLowerCase(): e.value};

  ArchiveFile? find(String path) => files[path] ?? lower[path.toLowerCase()];
  List<int> read(ArchiveFile f) => f.content as List<int>;

  final container = find('META-INF/container.xml');
  if (container == null) {
    throw const FormatException('Это не EPUB (нет container.xml)');
  }
  final containerDoc = XmlDocument.parse(decodeText(read(container)));
  final rootPath =
      descendantsByLocal(containerDoc, 'rootfile').firstOrNull?.getAttribute('full-path');
  if (rootPath == null) throw const FormatException('В EPUB не найден OPF');
  final opfFile = find(rootPath);
  if (opfFile == null) throw const FormatException('В EPUB не найден OPF');

  final opf = XmlDocument.parse(decodeText(read(opfFile)));
  final baseDir =
      rootPath.contains('/') ? rootPath.substring(0, rootPath.lastIndexOf('/') + 1) : '';

  final manifest = <String, ({String href, String type})>{};
  for (final it in descendantsByLocal(opf, 'item')) {
    final id = it.getAttribute('id');
    final href = it.getAttribute('href');
    if (id == null || href == null) continue;
    manifest[id] = (href: href, type: it.getAttribute('media-type') ?? '');
  }
  final spine = descendantsByLocal(opf, 'itemref')
      .map((e) => e.getAttribute('idref'))
      .whereType<String>()
      .toList();

  final title = collapse(descendantsByLocal(opf, 'title').firstOrNull?.innerText ?? '');
  final author = collapse(descendantsByLocal(opf, 'creator').firstOrNull?.innerText ?? '');

  final paragraphs = <String>[];
  final chapters = <ChapterMark>[];
  var sectionNo = 0;

  for (final id in spine) {
    final item = manifest[id];
    if (item == null) continue;
    if (item.type.isNotEmpty && !item.type.contains('html')) continue;
    final f = find(_resolve(baseDir, item.href));
    if (f == null) continue;

    final blocks = htmlToBlocks(decodeText(read(f)));
    if (blocks.isEmpty) continue;
    sectionNo++;

    HtmlBlock? heading;
    for (final b in blocks) {
      if (b.heading && b.text.length <= 120) {
        heading = b;
        break;
      }
    }
    final total = blocks.fold<int>(0, (s, b) => s + b.text.length);
    if (heading != null) {
      chapters.add(ChapterMark(heading.text, paragraphs.length));
    } else if (total > 1500) {
      chapters.add(ChapterMark('Раздел $sectionNo', paragraphs.length));
    }
    for (final b in blocks) {
      paragraphs.add(b.text);
    }
  }

  if (paragraphs.isEmpty) throw const FormatException('В EPUB нет текста');
  return BookContent(
    title: title.isNotEmpty ? title : fallbackTitle,
    author: author,
    paragraphs: paragraphs,
    chapters: chapters,
  );
}
