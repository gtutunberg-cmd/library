import 'dart:convert';
import 'dart:typed_data';

import 'package:xml/xml.dart';

/// Декодирует байты в строку: UTF-8 / UTF-16 (по BOM), при ошибке — windows-1251.
String decodeText(List<int> bytes, {String? declared}) {
  if (bytes.length >= 2) {
    if (bytes[0] == 0xFF && bytes[1] == 0xFE) {
      return _utf16(bytes.sublist(2), Endian.little);
    }
    if (bytes[0] == 0xFE && bytes[1] == 0xFF) {
      return _utf16(bytes.sublist(2), Endian.big);
    }
  }
  var data = bytes;
  if (bytes.length >= 3 &&
      bytes[0] == 0xEF &&
      bytes[1] == 0xBB &&
      bytes[2] == 0xBF) {
    data = bytes.sublist(3);
  }
  final d = declared?.toLowerCase() ?? '';
  if (d.contains('1251')) return decodeCp1251(data);
  try {
    return utf8.decode(data);
  } on FormatException {
    return decodeCp1251(data);
  }
}

String _utf16(List<int> b, Endian endian) {
  final units = <int>[];
  for (var i = 0; i + 1 < b.length; i += 2) {
    units.add(endian == Endian.little
        ? (b[i] | (b[i + 1] << 8))
        : ((b[i] << 8) | b[i + 1]));
  }
  return String.fromCharCodes(units);
}

/// Символы windows-1251 для байтов 0x80..0xBF.
const List<int> _cp1251High = [
  0x0402, 0x0403, 0x201A, 0x0453, 0x201E, 0x2026, 0x2020, 0x2021, //
  0x20AC, 0x2030, 0x0409, 0x2039, 0x040A, 0x040C, 0x040B, 0x040F,
  0x0452, 0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2013, 0x2014,
  0xFFFD, 0x2122, 0x0459, 0x203A, 0x045A, 0x045C, 0x045B, 0x045F,
  0x00A0, 0x040E, 0x045E, 0x0408, 0x00A4, 0x0490, 0x00A6, 0x00A7,
  0x0401, 0x00A9, 0x0404, 0x00AB, 0x00AC, 0x00AD, 0x00AE, 0x0407,
  0x00B0, 0x00B1, 0x0406, 0x0456, 0x0491, 0x00B5, 0x00B6, 0x00B7,
  0x0451, 0x2116, 0x0454, 0x00BB, 0x0458, 0x0405, 0x0455, 0x0457,
];

String decodeCp1251(List<int> bytes) {
  final sb = StringBuffer();
  for (final b in bytes) {
    if (b < 0x80) {
      sb.writeCharCode(b);
    } else if (b >= 0xC0) {
      sb.writeCharCode(0x0410 + (b - 0xC0));
    } else {
      sb.writeCharCode(_cp1251High[b - 0x80]);
    }
  }
  return sb.toString();
}

/// Схлопывает пробельные символы и обрезает края.
String collapse(String s) =>
    s.replaceAll(RegExp(r'[\s ]+'), ' ').trim();

/// Потомки узла с заданным локальным именем (без учёта префикса пространства имён).
Iterable<XmlElement> descendantsByLocal(XmlNode node, String local) =>
    node.descendants.whereType<XmlElement>().where((e) => e.name.local == local);
