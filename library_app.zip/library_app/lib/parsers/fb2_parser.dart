import 'dart:convert';

import 'package:archive/archive.dart';
import 'package:xml/xml.dart';

import 'book_content.dart';
import 'text_utils.dart';

/// FB2 и FB2 в zip-архиве (.fb2.zip).
BookContent parseFb2(List<int> rawBytes, String fallbackTitle) {
  var bytes = rawBytes;

  // .fb2.zip: архив начинается с "PK"
  if (bytes.length > 4 && bytes[0] == 0x50 && bytes[1] == 0x4B) {
    final archive = ZipDecoder().decodeBytes(bytes);
    ArchiveFile? inner;
    for (final f in archive.files) {
      if (f.isFile && f.name.toLowerCase().endsWith('.fb2')) {
        inner = f;
        break;
      }
    }
    if (inner == null) throw const FormatException('В архиве нет файла .fb2');
    bytes = inner.content as List<int>;
  }

  // Кодировка из заголовка <?xml ... encoding="windows-1251"?>
  final headLen = bytes.length < 300 ? bytes.length : 300;
  final head = latin1.decode(bytes.sublist(0, headLen), allowInvalid: true);
  final enc = RegExp(r'''encoding\s*=\s*["']([^"']+)["']''', caseSensitive: false)
      .firstMatch(head)
      ?.group(1);
  final text = decodeText(bytes, declared: enc).trimLeft();

  XmlDocument doc;
  try {
    doc = XmlDocument.parse(text);
  } on XmlException catch (e) {
    throw FormatException('Повреждённый FB2: ${e.message}');
  }

  var title = '';
  var author = '';
  final titleInfo = descendantsByLocal(doc, 'title-info').firstOrNull;
  if (titleInfo != null) {
    title = collapse(
        descendantsByLocal(titleInfo, 'book-title').firstOrNull?.innerText ?? '');
    final a = descendantsByLocal(titleInfo, 'author').firstOrNull;
    if (a != null) {
      author = ['first-name', 'middle-name', 'last-name']
          .map((n) => collapse(descendantsByLocal(a, n).firstOrNull?.innerText ?? ''))
          .where((s) => s.isNotEmpty)
          .join(' ');
    }
  }

  final paragraphs = <String>[];
  final chapters = <ChapterMark>[];

  void add(String t) {
    final s = collapse(t);
    if (s.isNotEmpty) paragraphs.add(s);
  }

  void walk(XmlElement el, int depth) {
    for (final c in el.children.whereType<XmlElement>()) {
      switch (c.name.local) {
        case 'section':
          walk(c, depth + 1);
        case 'title':
          final parts = descendantsByLocal(c, 'p')
              .map((p) => collapse(p.innerText))
              .where((s) => s.isNotEmpty)
              .toList();
          final t = parts.isNotEmpty ? parts.join(' ') : collapse(c.innerText);
          if (t.isNotEmpty) {
            if (depth <= 2) chapters.add(ChapterMark(t, paragraphs.length));
            paragraphs.add(t);
          }
        case 'p' || 'subtitle' || 'v' || 'text-author':
          add(c.innerText);
        case 'epigraph' || 'cite' || 'poem' || 'stanza':
          walk(c, depth);
        default:
          break;
      }
    }
  }

  for (final body in descendantsByLocal(doc, 'body')) {
    final name = body.getAttribute('name');
    if (name == 'notes' || name == 'comments') continue;
    walk(body, 0);
  }

  if (paragraphs.isEmpty) throw const FormatException('В книге нет текста');
  return BookContent(
    title: title.isNotEmpty ? title : fallbackTitle,
    author: author,
    paragraphs: paragraphs,
    chapters: chapters,
  );
}
