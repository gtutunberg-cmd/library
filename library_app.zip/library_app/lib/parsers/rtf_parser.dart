import 'book_content.dart';
import 'text_utils.dart';

/// Группы RTF, содержимое которых не является текстом книги.
const _skipDest = {
  'fonttbl', 'colortbl', 'stylesheet', 'info', 'pict', 'header', 'footer',
  'headerl', 'headerr', 'footerl', 'footerr', 'listtable', 'listoverridetable',
  'rsidtbl', 'generator', 'fldinst', 'datastore', 'themedata', 'colorschememapping',
  'latentstyles', 'xmlnstbl', 'object', 'private', 'revtbl', 'filetbl', //
};

final _chapterLine = RegExp(
  r'^(?:глава|часть|книга|пролог|эпилог|chapter|part|prologue|epilogue)(?:\s|\d|$|[.:!])',
  caseSensitive: false,
);

class _G {
  _G(this.skip, this.uc);
  bool skip;
  int uc;
}

bool _isLetter(int c) => (c >= 0x41 && c <= 0x5A) || (c >= 0x61 && c <= 0x7A);
bool _isDigit(int c) => c >= 0x30 && c <= 0x39;

int _hex(int c) {
  if (c >= 0x30 && c <= 0x39) return c - 0x30;
  if (c >= 0x41 && c <= 0x46) return c - 0x41 + 10;
  if (c >= 0x61 && c <= 0x66) return c - 0x61 + 10;
  return -1;
}

/// RTF: вытаскиваем текст, \par — граница абзаца, кириллица из \'hh (cp1251) и \uN.
BookContent parseRtf(List<int> bytes, String fallbackTitle) {
  final n = bytes.length;
  if (n < 6 || bytes[0] != 0x7B || bytes[1] != 0x5C) {
    throw const FormatException('Это не RTF-файл');
  }

  // кодовая страница из заголовка (по умолчанию для кириллицы — 1251)
  var cp = 1251;
  final head = String.fromCharCodes(bytes.sublist(0, n < 400 ? n : 400));
  final m = RegExp(r'\\ansicpg(\d+)').firstMatch(head);
  if (m != null) cp = int.tryParse(m.group(1) ?? '') ?? 1251;

  final stack = <_G>[];
  var g = _G(false, 1);
  final paragraphs = <String>[];
  final chapters = <ChapterMark>[];
  final buf = StringBuffer();
  var skipChars = 0; // сколько символов пропустить после \uN

  void flush() {
    final t = collapse(buf.toString());
    buf.clear();
    if (t.isEmpty) return;
    if (t.length <= 80 && _chapterLine.hasMatch(t)) {
      chapters.add(ChapterMark(t, paragraphs.length));
    }
    paragraphs.add(t);
  }

  void put(String s) {
    if (g.skip) return;
    if (skipChars > 0) {
      skipChars--;
      return;
    }
    buf.write(s);
  }

  var i = 0;
  while (i < n) {
    final c = bytes[i];
    if (c == 0x7B) {
      stack.add(_G(g.skip, g.uc));
      i++;
    } else if (c == 0x7D) {
      if (stack.isNotEmpty) g = stack.removeLast();
      i++;
    } else if (c == 0x5C) {
      i++;
      if (i >= n) break;
      final d = bytes[i];
      if (d == 0x5C || d == 0x7B || d == 0x7D) {
        put(String.fromCharCode(d));
        i++;
      } else if (d == 0x27) {
        // \'hh
        var b = 0;
        if (i + 2 < n && _hex(bytes[i + 1]) >= 0 && _hex(bytes[i + 2]) >= 0) {
          b = _hex(bytes[i + 1]) * 16 + _hex(bytes[i + 2]);
          i += 3;
        } else {
          i++;
          continue;
        }
        final ch = cp == 1251 ? decodeCp1251([b]) : String.fromCharCode(b);
        put(ch);
      } else if (d == 0x2A) {
        g.skip = true; // \* — необязательное назначение
        i++;
      } else if (d == 0x7E) {
        put(' ');
        i++;
      } else if (d == 0x5F) {
        put('-');
        i++;
      } else if (_isLetter(d)) {
        final st = i;
        while (i < n && _isLetter(bytes[i])) {
          i++;
        }
        final word = String.fromCharCodes(bytes.sublist(st, i));
        var neg = false;
        if (i < n && bytes[i] == 0x2D) {
          neg = true;
          i++;
        }
        var numStart = i;
        while (i < n && _isDigit(bytes[i])) {
          i++;
        }
        int? param = numStart == i
            ? null
            : int.tryParse(String.fromCharCodes(bytes.sublist(numStart, i)));
        if (param != null && neg) param = -param;
        if (i < n && bytes[i] == 0x20) i++; // пробел-разделитель

        if (_skipDest.contains(word)) {
          g.skip = true;
        } else if (!g.skip) {
          switch (word) {
            case 'par':
            case 'sect':
            case 'page':
            case 'line':
              if (skipChars > 0) {
                skipChars = 0;
              }
              flush();
              break;
            case 'tab':
              put(' ');
              break;
            case 'emdash':
              put('—');
              break;
            case 'endash':
              put('–');
              break;
            case 'lquote':
              put('‘');
              break;
            case 'rquote':
              put('’');
              break;
            case 'ldblquote':
              put('«');
              break;
            case 'rdblquote':
              put('»');
              break;
            case 'bullet':
              put('•');
              break;
            case 'uc':
              g.uc = param ?? 1;
              break;
            case 'u':
              if (param != null) {
                var code = param;
                if (code < 0) code += 65536;
                put(String.fromCharCode(code));
                skipChars = g.uc;
              }
              break;
            default:
              break;
          }
        }
      } else {
        i++; // неизвестный управляющий символ
      }
    } else if (c == 0x0A || c == 0x0D) {
      i++;
    } else {
      // обычный байт текста
      if (c < 0x80) {
        put(String.fromCharCode(c));
      } else {
        put(cp == 1251 ? decodeCp1251([c]) : String.fromCharCode(c));
      }
      i++;
    }
  }
  flush();

  if (paragraphs.isEmpty) throw const FormatException('В RTF нет текста');
  return BookContent(
    title: fallbackTitle,
    author: '',
    paragraphs: paragraphs,
    chapters: chapters,
  );
}
