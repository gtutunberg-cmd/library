import 'dart:convert';
import 'dart:typed_data';

import 'book_content.dart';
import 'html_text.dart';
import 'text_utils.dart';

int _u16(Uint8List b, int o) => (b[o] << 8) | b[o + 1];
int _u32(Uint8List b, int o) =>
    (b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3];

/// Распаковка PalmDOC (LZ77).
Uint8List _palmDecompress(Uint8List src) {
  final out = <int>[];
  var i = 0;
  while (i < src.length) {
    final c = src[i++];
    if (c == 0 || (c >= 9 && c <= 0x7F)) {
      out.add(c);
    } else if (c >= 1 && c <= 8) {
      for (var k = 0; k < c && i < src.length; k++) {
        out.add(src[i++]);
      }
    } else if (c >= 0xC0) {
      out.add(0x20);
      out.add(c ^ 0x80);
    } else {
      // 0x80..0xBF: пара (расстояние, длина)
      if (i >= src.length) break;
      final pair = (c << 8) | src[i++];
      final dist = (pair >> 3) & 0x7FF;
      final len = (pair & 7) + 3;
      if (dist == 0 || dist > out.length) continue;
      for (var k = 0; k < len; k++) {
        out.add(out[out.length - dist]);
      }
    }
  }
  return Uint8List.fromList(out);
}

/// Отрезает от записи служебные «хвосты» (флаги из заголовка MOBI).
int _trimmedEnd(Uint8List rec, int flags) {
  var end = rec.length;
  for (var bit = 1; bit <= 15; bit++) {
    if ((flags & (1 << bit)) == 0) continue;
    var val = 0;
    var shift = 0;
    var pos = end - 1;
    while (pos >= 0) {
      final b = rec[pos];
      val |= (b & 0x7F) << shift;
      shift += 7;
      pos--;
      if ((b & 0x80) != 0 || shift >= 28) break;
    }
    end -= val;
    if (end <= 0) return 0;
  }
  if ((flags & 1) != 0 && end > 0) {
    end -= (rec[end - 1] & 3) + 1;
  }
  return end < 0 ? 0 : end;
}

/// MOBI / AZW / AZW3 / PRC без DRM, со сжатием PalmDOC или без сжатия.
BookContent parseMobi(List<int> bytes, String fallbackTitle) {
  final data = Uint8List.fromList(bytes);
  if (data.length < 100) throw const FormatException('Файл слишком мал для MOBI');
  final numRecords = _u16(data, 76);
  if (numRecords < 2 || 78 + numRecords * 8 > data.length) {
    throw const FormatException('Это не MOBI-файл');
  }
  final offsets = [for (var i = 0; i < numRecords; i++) _u32(data, 78 + i * 8)];
  Uint8List record(int i) {
    final start = offsets[i];
    final end = i + 1 < numRecords ? offsets[i + 1] : data.length;
    if (start < 0 || end > data.length || start >= end) return Uint8List(0);
    return Uint8List.sublistView(data, start, end);
  }

  final r0 = record(0);
  if (r0.length < 32) throw const FormatException('Повреждён заголовок MOBI');
  final compression = _u16(r0, 0);
  final textRecords = _u16(r0, 8);
  final encryption = _u16(r0, 12);
  if (encryption != 0) {
    throw const FormatException('Книга защищена DRM, открыть нельзя');
  }
  if (compression != 1 && compression != 2) {
    throw const FormatException('Этот вариант сжатия MOBI (HUFF/CDIC) не поддерживается');
  }

  var encoding = 65001;
  var title = '';
  var flags = 0;
  if (r0.length > 100 && String.fromCharCodes(r0.sublist(16, 20)) == 'MOBI') {
    final headerLen = _u32(r0, 20);
    encoding = _u32(r0, 28);
    final nameOff = _u32(r0, 84);
    final nameLen = _u32(r0, 88);
    if (nameOff > 0 && nameOff + nameLen <= r0.length && nameLen > 0) {
      title = utf8.decode(r0.sublist(nameOff, nameOff + nameLen), allowMalformed: true);
    }
    if (headerLen >= 0xE4 && r0.length >= 0xF4) flags = _u16(r0, 0xF2);
  }

  final text = BytesBuilder();
  final last = textRecords < numRecords - 1 ? textRecords : numRecords - 1;
  for (var i = 1; i <= last; i++) {
    var rec = record(i);
    if (rec.isEmpty) continue;
    if (flags != 0) rec = Uint8List.sublistView(rec, 0, _trimmedEnd(rec, flags));
    text.add(compression == 2 ? _palmDecompress(rec) : rec);
  }

  final raw = text.toBytes();
  final html = encoding == 65001
      ? utf8.decode(raw, allowMalformed: true)
      : decodeCp1251Fallback(raw);

  final blocks = htmlToBlocks(html);
  final paragraphs = <String>[];
  final chapters = <ChapterMark>[];
  for (final b in blocks) {
    if (b.heading && b.text.length <= 120) {
      chapters.add(ChapterMark(b.text, paragraphs.length));
    }
    paragraphs.add(b.text);
  }
  if (paragraphs.isEmpty) throw const FormatException('В MOBI не найден текст');
  return BookContent(
    title: title.trim().isEmpty ? fallbackTitle : title.trim(),
    author: '',
    paragraphs: paragraphs,
    chapters: chapters,
  );
}

/// Для кодировки 1252 в русских книгах обычно лежит cp1251; если там чистый ASCII — без разницы.
String decodeCp1251Fallback(List<int> bytes) => decodeText(bytes);
