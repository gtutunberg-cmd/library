/// Контракт озвучки. Реализация появится на этапе 2 (flutter_tts + audio_service).
///
/// Идея: читалка отдаёт текст страниц (BookPage.text) по порядку, озвучка
/// читает их фоновым сервисом с уведомлением и кнопками на экране блокировки,
/// а при смене озвучиваемой страницы читалка сама листает вперёд
/// через PageTurnController.next().
abstract class TtsController {
  /// Начать чтение с блока [startIndex].
  Future<void> speak(List<String> chunks, {int startIndex = 0});

  Future<void> pause();
  Future<void> resume();
  Future<void> stop();

  /// Индекс блока, который читается сейчас.
  Stream<int> get currentChunk;
}
