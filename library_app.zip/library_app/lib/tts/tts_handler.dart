import 'dart:async';
import 'dart:math' as math;

import 'package:audio_service/audio_service.dart';
import 'package:audio_session/audio_session.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';

/// Слово, которое сейчас читается: страница и диапазон в тексте страницы.
class TtsHighlight {
  const TtsHighlight(this.page, this.start, this.end);
  final int page;
  final int start;
  final int end;
}

class _Piece {
  const _Piece(this.page, this.text);
  final int page;
  final String text;
}

/// Ряды служебных символов (_____, ----, ====, ****): движок читает их по знаку.
final RegExp _symbolRuns = RegExp(r'[_\-=*~#\u2022\u00B7\u25AA\u25A0\u25A1\u25C6\u25C7\u2500\u2501\u2550+|/\\]{2,}');
final RegExp _hasLetterOrDigit = RegExp(r'[\p{L}\p{N}]', unicode: true);

final RegExp _endMark = RegExp(r'[.!?…:;,»”")\]]$');

/// Озвучка книги системным голосом (Google TTS) в фоновом сервисе.
///
/// Читает страницы по порядку: каждая страница — один кусок речи.
/// Когда начинается новый кусок, вызывается [onPage], и читалка листает.
/// Кнопки на уведомлении и на экране блокировки: назад / пауза / вперёд / стоп.
class TtsHandler extends BaseAudioHandler {
  TtsHandler() {
    _initFuture = _init();
  }

  final FlutterTts _tts = FlutterTts();
  late final Future<void> _initFuture;

  List<_Piece> _pieces = const [];
  int _i = 0;
  int _gen = 0;
  int _fastFails = 0;
  double _rate = 0.5;
  bool _hasRussian = true;

  /// true, пока идёт озвучка.
  final ValueNotifier<bool> speaking = ValueNotifier<bool>(false);

  /// Читаемое сейчас слово (null — нет).
  final ValueNotifier<TtsHighlight?> highlight = ValueNotifier<TtsHighlight?>(null);

  List<String> _rawPages = const [];
  int _ptr = 0;
  int _ptrPage = -1;
  int _pieceStartPtr = 0;
  int _startedPiece = -1;

  /// Сообщение об ошибке для показа пользователю.
  final ValueNotifier<String?> notice = ValueNotifier<String?>(null);

  /// Когда сработает таймер сна (null — таймер выключен).
  final ValueNotifier<DateTime?> sleepAt = ValueNotifier<DateTime?>(null);
  Timer? _sleepTimer;

  /// Остановить озвучку через [minutes] минут; null — выключить таймер.
  void setSleepTimer(int? minutes) {
    _sleepTimer?.cancel();
    _sleepTimer = null;
    if (minutes == null) {
      sleepAt.value = null;
      return;
    }
    sleepAt.value = DateTime.now().add(Duration(minutes: minutes));
    _sleepTimer = Timer(Duration(minutes: minutes), () {
      sleepAt.value = null;
      _sleepTimer = null;
      pause();
    });
  }

  /// Вызывается, когда начинается чтение новой страницы.
  void Function(int page)? onPage;

  int get currentPage => _pieces.isEmpty
      ? -1
      : _pieces[_i.clamp(0, _pieces.length - 1).toInt()].page;

  Future<void> _init() async {
    try {
      await _tts.setLanguage('ru-RU');
      await _tts.awaitSpeakCompletion(true);
      await _tts.setVolume(1.0);
      await _tts.setPitch(1.0);
      await _tts.setSpeechRate(_rate);
      try {
        _tts.setProgressHandler(_onProgress);
      } catch (_) {}
      try {
        final ok = await _tts.isLanguageAvailable('ru-RU');
        _hasRussian = (ok == true || ok == 1);
      } catch (_) {}
    } catch (_) {}
    try {
      final session = await AudioSession.instance;
      await session.configure(AudioSessionConfiguration.speech());
      session.interruptionEventStream.listen((e) {
        if (e.begin) pause();
      });
      session.becomingNoisyEventStream.listen((_) => pause());
    } catch (_) {}
  }

  /// Движок сообщает, какое слово сейчас произносится.
  void _onProgress(String text, int start, int end, String word) {
    final page = _ptrPage;
    if (page < 0 || page >= _rawPages.length) return;
    var w = word.trim();
    if (w.isEmpty && start >= 0 && end <= text.length && start < end) {
      w = text.substring(start, end).trim();
    }
    if (w.isEmpty) return;
    final idx = _rawPages[page].indexOf(w, _ptr);
    if (idx >= 0 && idx - _ptr < 400) {
      _ptr = idx + w.length;
      highlight.value = TtsHighlight(page, idx, idx + w.length);
    }
  }

  /// Установленные движки озвучки (пакеты Android).
  Future<List<String>> engines() async {
    try {
      final dynamic raw = await _tts.getEngines;
      if (raw is List) return [for (final e in raw) e.toString()];
    } catch (_) {}
    return const [];
  }

  Future<void> setEngine(String? pkg) async {
    try {
      if (pkg != null && pkg.isNotEmpty) await _tts.setEngine(pkg);
      await _tts.setLanguage('ru-RU');
    } catch (_) {}
    if (speaking.value) await jumpToPage(currentPage);
  }

  // ---------- подготовка текста ----------

  static String _clean(String pageText) {
    final out = <String>[];
    for (final line in pageText.split('\n')) {
      var t = line
          .replaceAll('\u2003', ' ')
          .replaceAll(_symbolRuns, ' ')
          .replaceAll('_', ' ')
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim();
      // строки без единой буквы или цифры (разделители, рамки) не озвучиваем
      if (t.isEmpty || !_hasLetterOrDigit.hasMatch(t)) continue;
      if (!_endMark.hasMatch(t)) t = '$t.';
      out.add(t);
    }
    return out.join(' ');
  }

  static List<_Piece> _buildPieces(List<String> pageTexts) {
    final result = <_Piece>[];
    for (var p = 0; p < pageTexts.length; p++) {
      var text = _clean(pageTexts[p]);
      while (text.length > 3000) {
        var cut = text.lastIndexOf(RegExp(r'[.!?…] '), 3000);
        if (cut < 500) cut = text.lastIndexOf(' ', 3000);
        if (cut <= 0) cut = 2999;
        result.add(_Piece(p, text.substring(0, cut + 1).trim()));
        text = text.substring(cut + 1).trim();
      }
      if (text.isNotEmpty) result.add(_Piece(p, text));
    }
    return result;
  }

  // ---------- управление ----------

  /// Начинает чтение со страницы [startPage]. Возвращает текст ошибки или null.
  Future<String?> startReading({
    required String title,
    required String author,
    required List<String> pageTexts,
    required int startPage,
    required double rate,
    double pitch = 1.0,
    String? voice,
    String? voiceLocale,
    String? engine,
  }) async {
    await _initFuture;
    if (engine != null && engine.isNotEmpty) {
      try {
        await _tts.setEngine(engine);
        await _tts.setLanguage('ru-RU');
      } catch (_) {}
    }
    if (!_hasRussian) {
      return 'Нет русского голоса. Откройте настройки Android: Язык и ввод → '
          'Синтез речи → Google → Русский.';
    }
    final gen = ++_gen;
    try {
      await _tts.stop();
    } catch (_) {}
    _rate = rate;
    try {
      await _tts.setSpeechRate(rate);
      await _tts.setPitch(pitch);
      if (voice != null && voice.isNotEmpty) {
        await _tts.setVoice({'name': voice, 'locale': voiceLocale ?? 'ru-RU'});
      }
    } catch (_) {}

    _pieces = _buildPieces(pageTexts);
    _rawPages = pageTexts;
    _ptr = 0;
    _ptrPage = -1;
    _startedPiece = -1;
    highlight.value = null;
    if (_pieces.isEmpty) return 'На этих страницах нет текста для озвучки.';
    var idx = _pieces.indexWhere((p) => p.page >= startPage);
    if (idx < 0) idx = 0;
    _i = idx;
    _fastFails = 0;

    mediaItem.add(MediaItem(
      id: 'book',
      title: title.isEmpty ? 'Книга' : title,
      artist: author.isEmpty ? null : author,
    ));
    try {
      final session = await AudioSession.instance;
      await session.setActive(true);
    } catch (_) {}
    if (gen != _gen) return null;

    _emit(true);
    unawaited(_run(gen));
    return null;
  }

  Future<void> _run(int gen) async {
    while (gen == _gen && _i < _pieces.length) {
      final piece = _pieces[_i];
      onPage?.call(piece.page);
      if (_startedPiece != _i) {
        if (piece.page != _ptrPage) {
          _ptr = 0;
          _ptrPage = piece.page;
        }
        _pieceStartPtr = _ptr;
        _startedPiece = _i;
      } else {
        _ptr = _pieceStartPtr;
      }
      final sw = Stopwatch()..start();
      try {
        await _tts.speak(piece.text);
      } catch (_) {}
      if (gen != _gen) return;
      if (sw.elapsedMilliseconds < 250 && piece.text.length > 80) {
        _fastFails++;
        if (_fastFails >= 3) {
          notice.value = 'Не удалось озвучить текст. Проверьте голосовой движок: '
              'Настройки Android → Язык и ввод → Синтез речи.';
          await stop();
          return;
        }
      } else {
        _fastFails = 0;
      }
      _i++;
    }
    if (gen == _gen) await stop();
  }

  Future<void> jumpToPage(int page) async {
    if (_pieces.isEmpty) return;
    var idx = _pieces.indexWhere((p) => p.page >= page);
    if (idx < 0) idx = _pieces.length - 1;
    final wasPlaying = speaking.value;
    _gen++;
    try {
      await _tts.stop();
    } catch (_) {}
    _i = idx;
    if (wasPlaying) {
      final gen = ++_gen;
      unawaited(_run(gen));
    } else {
      onPage?.call(_pieces[_i].page);
    }
  }

  Future<void> setRate(double v) async {
    _rate = v;
    try {
      await _tts.setSpeechRate(v);
    } catch (_) {}
    if (speaking.value) await jumpToPage(currentPage);
  }

  /// Русские голоса, установленные на телефоне.
  Future<List<Map<String, String>>> russianVoices() async {
    await _initFuture;
    final result = <Map<String, String>>[];
    try {
      final dynamic raw = await _tts.getVoices;
      if (raw is List) {
        for (final v in raw) {
          if (v is! Map) continue;
          final m = <String, String>{
            for (final e in v.entries) e.key.toString(): e.value.toString(),
          };
          final locale = (m['locale'] ?? '').toLowerCase().replaceAll('_', '-');
          if (locale.startsWith('ru') && (m['name'] ?? '').isNotEmpty) result.add(m);
        }
      }
    } catch (_) {}
    result.sort((a, b) => (a['name'] ?? '').compareTo(b['name'] ?? ''));
    return result;
  }

  Future<void> setVoice(String? name, String? locale) async {
    try {
      if (name == null || name.isEmpty) {
        await _tts.setLanguage('ru-RU');
      } else {
        await _tts.setVoice({'name': name, 'locale': locale ?? 'ru-RU'});
      }
    } catch (_) {}
    if (speaking.value) await jumpToPage(currentPage);
  }

  Future<void> setPitch(double v) async {
    try {
      await _tts.setPitch(v);
    } catch (_) {}
    if (speaking.value) await jumpToPage(currentPage);
  }

  /// Короткая фраза для проверки голоса (если чтение сейчас не идёт).
  Future<void> preview() async {
    await _initFuture;
    if (speaking.value) return;
    try {
      await _tts.stop();
      await _tts.speak('Здравствуйте! Так звучит выбранный голос.');
    } catch (_) {}
  }

  void _emit(bool playing, {AudioProcessingState state = AudioProcessingState.ready}) {
    speaking.value = playing;
    playbackState.add(PlaybackState(
      controls: [
        MediaControl.skipToPrevious,
        playing ? MediaControl.pause : MediaControl.play,
        MediaControl.skipToNext,
        MediaControl.stop,
      ],
      androidCompactActionIndices: const [0, 1, 2],
      processingState: state,
      playing: playing,
    ));
  }

  @override
  Future<void> play() async {
    if (_pieces.isEmpty || speaking.value) return;
    try {
      final session = await AudioSession.instance;
      await session.setActive(true);
    } catch (_) {}
    final gen = ++_gen;
    _emit(true);
    unawaited(_run(gen));
  }

  @override
  Future<void> pause() async {
    if (!speaking.value) return;
    _gen++;
    try {
      await _tts.stop();
    } catch (_) {}
    _emit(false);
  }

  @override
  Future<void> stop() async {
    _sleepTimer?.cancel();
    _sleepTimer = null;
    sleepAt.value = null;
    _gen++;
    try {
      await _tts.stop();
    } catch (_) {}
    _pieces = const [];
    _i = 0;
    _startedPiece = -1;
    highlight.value = null;
    _emit(false, state: AudioProcessingState.idle);
  }

  @override
  Future<void> skipToNext() => jumpToPage(currentPage + 1);

  @override
  Future<void> skipToPrevious() => jumpToPage(math.max(0, currentPage - 1));
}
