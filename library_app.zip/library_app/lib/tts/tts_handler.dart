import 'dart:async';
import 'dart:math' as math;

import 'package:audio_service/audio_service.dart';
import 'package:audio_session/audio_session.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';

class _Piece {
  const _Piece(this.page, this.text);
  final int page;
  final String text;
}

final RegExp _endMark = RegExp(r'[.!?…:;,»”")\]]$');

/// Озвучка книги системным голосом (Google TTS) в фоновом сервисе.
///
/// Читает страницы по порядку: каждая страница — один кусок речи.
/// Когда начинается новый кусок, вызывается [onPage], и читалка листает.
/// Кнопки на уведомлении и на экране блокировки: назад / пауза / вперёд / стоп.
class TtsHandler extends BaseAudioHandler {
  TtsHandler() {
    _initFuture = _init();
  }

  final FlutterTts _tts = FlutterTts();
  late final Future<void> _initFuture;

  List<_Piece> _pieces = const [];
  int _i = 0;
  int _gen = 0;
  int _fastFails = 0;
  double _rate = 0.5;
  bool _hasRussian = true;

  /// true, пока идёт озвучка.
  final ValueNotifier<bool> speaking = ValueNotifier<bool>(false);

  /// Сообщение об ошибке для показа пользователю.
  final ValueNotifier<String?> notice = ValueNotifier<String?>(null);

  /// Когда сработает таймер сна (null — таймер выключен).
  final ValueNotifier<DateTime?> sleepAt = ValueNotifier<DateTime?>(null);
  Timer? _sleepTimer;

  /// Остановить озвучку через [minutes] минут; null — выключить таймер.
  void setSleepTimer(int? minutes) {
    _sleepTimer?.cancel();
    _sleepTimer = null;
    if (minutes == null) {
      sleepAt.value = null;
      return;
    }
    sleepAt.value = DateTime.now().add(Duration(minutes: minutes));
    _sleepTimer = Timer(Duration(minutes: minutes), () {
      sleepAt.value = null;
      _sleepTimer = null;
      pause();
    });
  }

  /// Вызывается, когда начинается чтение новой страницы.
  void Function(int page)? onPage;

  int get currentPage => _pieces.isEmpty
      ? -1
      : _pieces[_i.clamp(0, _pieces.length - 1).toInt()].page;

  Future<void> _init() async {
    try {
      await _tts.setLanguage('ru-RU');
      await _tts.awaitSpeakCompletion(true);
      await _tts.setVolume(1.0);
      await _tts.setPitch(1.0);
      await _tts.setSpeechRate(_rate);
      try {
        final ok = await _tts.isLanguageAvailable('ru-RU');
        _hasRussian = (ok == true || ok == 1);
      } catch (_) {}
    } catch (_) {}
    try {
      final session = await AudioSession.instance;
      await session.configure(AudioSessionConfiguration.speech());
      session.interruptionEventStream.listen((e) {
        if (e.begin) pause();
      });
      session.becomingNoisyEventStream.listen((_) => pause());
    } catch (_) {}
  }

  // ---------- подготовка текста ----------

  static String _clean(String pageText) {
    final out = <String>[];
    for (final line in pageText.split('\n')) {
      var t = line.replaceAll(' ', ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
      if (t.isEmpty) continue;
      if (!_endMark.hasMatch(t)) t = '$t.';
      out.add(t);
    }
    return out.join(' ');
  }

  static List<_Piece> _buildPieces(List<String> pageTexts) {
    final result = <_Piece>[];
    for (var p = 0; p < pageTexts.length; p++) {
      var text = _clean(pageTexts[p]);
      while (text.length > 3000) {
        var cut = text.lastIndexOf(RegExp(r'[.!?…] '), 3000);
        if (cut < 500) cut = text.lastIndexOf(' ', 3000);
        if (cut <= 0) cut = 2999;
        result.add(_Piece(p, text.substring(0, cut + 1).trim()));
        text = text.substring(cut + 1).trim();
      }
      if (text.isNotEmpty) result.add(_Piece(p, text));
    }
    return result;
  }

  // ---------- управление ----------

  /// Начинает чтение со страницы [startPage]. Возвращает текст ошибки или null.
  Future<String?> startReading({
    required String title,
    required String author,
    required List<String> pageTexts,
    required int startPage,
    required double rate,
    double pitch = 1.0,
    String? voice,
    String? voiceLocale,
  }) async {
    await _initFuture;
    if (!_hasRussian) {
      return 'Нет русского голоса. Откройте настройки Android: Язык и ввод → '
          'Синтез речи → Google → Русский.';
    }
    final gen = ++_gen;
    try {
      await _tts.stop();
    } catch (_) {}
    _rate = rate;
    try {
      await _tts.setSpeechRate(rate);
      await _tts.setPitch(pitch);
      if (voice != null && voice.isNotEmpty) {
        await _tts.setVoice({'name': voice, 'locale': voiceLocale ?? 'ru-RU'});
      }
    } catch (_) {}

    _pieces = _buildPieces(pageTexts);
    if (_pieces.isEmpty) return 'На этих страницах нет текста для озвучки.';
    var idx = _pieces.indexWhere((p) => p.page >= startPage);
    if (idx < 0) idx = 0;
    _i = idx;
    _fastFails = 0;

    mediaItem.add(MediaItem(
      id: 'book',
      title: title.isEmpty ? 'Книга' : title,
      artist: author.isEmpty ? null : author,
    ));
    try {
      final session = await AudioSession.instance;
      await session.setActive(true);
    } catch (_) {}
    if (gen != _gen) return null;

    _emit(true);
    unawaited(_run(gen));
    return null;
  }

  Future<void> _run(int gen) async {
    while (gen == _gen && _i < _pieces.length) {
      final piece = _pieces[_i];
      onPage?.call(piece.page);
      final sw = Stopwatch()..start();
      try {
        await _tts.speak(piece.text);
      } catch (_) {}
      if (gen != _gen) return;
      if (sw.elapsedMilliseconds < 250 && piece.text.length > 80) {
        _fastFails++;
        if (_fastFails >= 3) {
          notice.value = 'Не удалось озвучить текст. Проверьте голосовой движок: '
              'Настройки Android → Язык и ввод → Синтез речи.';
          await stop();
          return;
        }
      } else {
        _fastFails = 0;
      }
      _i++;
    }
    if (gen == _gen) await stop();
  }

  Future<void> jumpToPage(int page) async {
    if (_pieces.isEmpty) return;
    var idx = _pieces.indexWhere((p) => p.page >= page);
    if (idx < 0) idx = _pieces.length - 1;
    final wasPlaying = speaking.value;
    _gen++;
    try {
      await _tts.stop();
    } catch (_) {}
    _i = idx;
    if (wasPlaying) {
      final gen = ++_gen;
      unawaited(_run(gen));
    } else {
      onPage?.call(_pieces[_i].page);
    }
  }

  Future<void> setRate(double v) async {
    _rate = v;
    try {
      await _tts.setSpeechRate(v);
    } catch (_) {}
    if (speaking.value) await jumpToPage(currentPage);
  }

  /// Русские голоса, установленные на телефоне.
  Future<List<Map<String, String>>> russianVoices() async {
    await _initFuture;
    final result = <Map<String, String>>[];
    try {
      final dynamic raw = await _tts.getVoices;
      if (raw is List) {
        for (final v in raw) {
          if (v is! Map) continue;
          final m = <String, String>{
            for (final e in v.entries) e.key.toString(): e.value.toString(),
          };
          final locale = (m['locale'] ?? '').toLowerCase().replaceAll('_', '-');
          if (locale.startsWith('ru') && (m['name'] ?? '').isNotEmpty) result.add(m);
        }
      }
    } catch (_) {}
    result.sort((a, b) => (a['name'] ?? '').compareTo(b['name'] ?? ''));
    return result;
  }

  Future<void> setVoice(String? name, String? locale) async {
    try {
      if (name == null || name.isEmpty) {
        await _tts.setLanguage('ru-RU');
      } else {
        await _tts.setVoice({'name': name, 'locale': locale ?? 'ru-RU'});
      }
    } catch (_) {}
    if (speaking.value) await jumpToPage(currentPage);
  }

  Future<void> setPitch(double v) async {
    try {
      await _tts.setPitch(v);
    } catch (_) {}
    if (speaking.value) await jumpToPage(currentPage);
  }

  /// Короткая фраза для проверки голоса (если чтение сейчас не идёт).
  Future<void> preview() async {
    await _initFuture;
    if (speaking.value) return;
    try {
      await _tts.stop();
      await _tts.speak('Здравствуйте! Так звучит выбранный голос.');
    } catch (_) {}
  }

  void _emit(bool playing, {AudioProcessingState state = AudioProcessingState.ready}) {
    speaking.value = playing;
    playbackState.add(PlaybackState(
      controls: [
        MediaControl.skipToPrevious,
        playing ? MediaControl.pause : MediaControl.play,
        MediaControl.skipToNext,
        MediaControl.stop,
      ],
      androidCompactActionIndices: const [0, 1, 2],
      processingState: state,
      playing: playing,
    ));
  }

  @override
  Future<void> play() async {
    if (_pieces.isEmpty || speaking.value) return;
    try {
      final session = await AudioSession.instance;
      await session.setActive(true);
    } catch (_) {}
    final gen = ++_gen;
    _emit(true);
    unawaited(_run(gen));
  }

  @override
  Future<void> pause() async {
    if (!speaking.value) return;
    _gen++;
    try {
      await _tts.stop();
    } catch (_) {}
    _emit(false);
  }

  @override
  Future<void> stop() async {
    _sleepTimer?.cancel();
    _sleepTimer = null;
    sleepAt.value = null;
    _gen++;
    try {
      await _tts.stop();
    } catch (_) {}
    _pieces = const [];
    _i = 0;
    _emit(false, state: AudioProcessingState.idle);
  }

  @override
  Future<void> skipToNext() => jumpToPage(currentPage + 1);

  @override
  Future<void> skipToPrevious() => jumpToPage(math.max(0, currentPage - 1));
}
