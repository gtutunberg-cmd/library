import 'package:audio_service/audio_service.dart';
import 'package:flutter/foundation.dart';

import 'tts_handler.dart';

/// Единственный обработчик озвучки. null — если сервис не удалось запустить.
TtsHandler? ttsHandler;

Future<void> initTts() async {
  try {
    ttsHandler = await AudioService.init(
      builder: () => TtsHandler(),
      config: AudioServiceConfig(
        androidNotificationChannelId: 'kz.rinat.ebook_reader.tts',
        androidNotificationChannelName: 'Озвучка книги',
        androidNotificationOngoing: false,
        androidStopForegroundOnPause: false,
      ),
    ).timeout(const Duration(seconds: 8));
  } catch (e) {
    debugPrint('TTS init failed: $e');
    ttsHandler = null;
  }
}
