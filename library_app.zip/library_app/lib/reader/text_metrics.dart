import 'package:flutter/widgets.dart';

import '../data/reader_settings.dart';

/// Стиль текста страницы. Тот же стиль используется и для расчёта страниц,
/// и для показа, иначе переносы строк разойдутся.
TextStyle readerTextStyle(ReaderSettings s, Color color) => TextStyle(
      fontSize: s.fontSize,
      height: s.lineHeight,
      color: color,
      fontFamily: s.serif ? 'serif' : null,
    );

/// Жёсткая высота строки: все строки строго одной высоты.
StrutStyle readerStrut(ReaderSettings s) => StrutStyle(
      fontSize: s.fontSize,
      height: s.lineHeight,
      forceStrutHeight: true,
      fontFamily: s.serif ? 'serif' : null,
    );
