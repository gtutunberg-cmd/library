import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Управление листанием снаружи (кнопки, ползунок, оглавление, позже озвучка).
class PageTurnController {
  _PageTurnViewState? _state;

  void _attach(_PageTurnViewState s) => _state = s;
  void _detach(_PageTurnViewState s) {
    if (_state == s) _state = null;
  }

  void next() => _state?._go(1);
  void prev() => _state?._go(-1);
  void jumpTo(int page) => _state?._jump(page);
}

/// Листание страниц как в книге: страница отгибается от левого края
/// с перспективой и тенью, под ней видна следующая.
///
/// Жесты: свайп влево/вправо (с учётом скорости), тап по краям экрана,
/// тап по центру вызывает [onCenterTap].
class PageTurnView extends StatefulWidget {
  const PageTurnView({
    super.key,
    required this.pageCount,
    required this.itemBuilder,
    required this.background,
    this.initialPage = 0,
    this.controller,
    this.onPageChanged,
    this.onCenterTap,
  });

  final int pageCount;
  final IndexedWidgetBuilder itemBuilder;
  final Color background;
  final int initialPage;
  final PageTurnController? controller;
  final ValueChanged<int>? onPageChanged;
  final VoidCallback? onCenterTap;

  @override
  State<PageTurnView> createState() => _PageTurnViewState();
}

class _PageTurnViewState extends State<PageTurnView>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  int _reported = -1;
  double _target = 0;

  int get _count => widget.pageCount;
  double get _maxPos => math.max(0, _count - 1).toDouble();
  int get _current => _c.value.round().clamp(0, math.max(0, _count - 1)).toInt();

  @override
  void initState() {
    super.initState();
    final start = widget.initialPage.clamp(0, math.max(0, _count - 1)).toInt();
    _c = AnimationController(
      vsync: this,
      lowerBound: 0,
      upperBound: math.max(1, _count - 1).toDouble(),
      value: start.toDouble(),
    );
    _target = start.toDouble();
    _reported = start;
    _c.addStatusListener((s) {
      if (s == AnimationStatus.completed || s == AnimationStatus.dismissed) {
        _report();
      }
    });
    widget.controller?._attach(this);
  }

  @override
  void didUpdateWidget(PageTurnView old) {
    super.didUpdateWidget(old);
    if (old.controller != widget.controller) {
      old.controller?._detach(this);
      widget.controller?._attach(this);
    }
  }

  @override
  void dispose() {
    widget.controller?._detach(this);
    _c.dispose();
    super.dispose();
  }

  void _report() {
    final p = _current;
    if (p != _reported) {
      _reported = p;
      widget.onPageChanged?.call(p);
    }
  }

  void _settle(double target) {
    final t = target.clamp(0.0, _maxPos).toDouble();
    _target = t;
    final dist = (t - _c.value).abs();
    if (dist < 0.001) {
      _c.value = t;
      _report();
      return;
    }
    final ms = (300 * dist.clamp(0.3, 1.0)).round();
    _c.animateTo(t, duration: Duration(milliseconds: ms), curve: Curves.easeOutCubic);
  }

  void _go(int delta) {
    final base = _c.isAnimating ? _target : _current.toDouble();
    _settle(base + delta);
  }

  void _jump(int page) {
    _c.stop();
    final p = page.clamp(0, math.max(0, _count - 1)).toDouble();
    _target = p;
    _c.value = p;
    _report();
  }

  @override
  Widget build(BuildContext context) {
    if (_count == 0) return const SizedBox.shrink();
    return LayoutBuilder(builder: (context, constraints) {
      final w = constraints.maxWidth;
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (d) {
          final x = d.localPosition.dx;
          if (x < w * 0.3) {
            _go(-1);
          } else if (x > w * 0.7) {
            _go(1);
          } else {
            widget.onCenterTap?.call();
          }
        },
        onHorizontalDragStart: (_) => _c.stop(),
        onHorizontalDragUpdate: (d) {
          _c.value = (_c.value - d.delta.dx / w).clamp(0.0, _maxPos).toDouble();
        },
        onHorizontalDragEnd: (d) {
          final v = d.primaryVelocity ?? 0;
          final pos = _c.value;
          double target;
          if (v < -350) {
            target = pos.ceilToDouble();
          } else if (v > 350) {
            target = pos.floorToDouble();
          } else {
            target = pos.roundToDouble();
          }
          _settle(target);
        },
        onHorizontalDragCancel: () => _settle(_c.value.roundToDouble()),
        child: AnimatedBuilder(
          animation: _c,
          builder: (context, _) => _buildPages(context),
        ),
      );
    });
  }

  Widget _buildPages(BuildContext context) {
    var base = _c.value.floor();
    var frac = _c.value - base;
    if (base >= _count - 1) {
      base = _count - 1;
      frac = 0;
    }
    if (frac < 0.002) frac = 0;

    final top = widget.itemBuilder(context, base);
    if (frac == 0) {
      return ColoredBox(color: widget.background, child: SizedBox.expand(child: top));
    }

    final under = widget.itemBuilder(context, base + 1);
    final angle = frac * math.pi / 2;

    return ColoredBox(
      color: widget.background,
      child: Stack(
        fit: StackFit.expand,
        children: [
          under,
          // тень от отгибающейся страницы на странице под ней
          IgnorePointer(
            child: ColoredBox(
              color: Colors.black.withValues(alpha: 0.22 * (1 - frac)),
            ),
          ),
          Transform(
            alignment: Alignment.centerLeft,
            transform: Matrix4.identity()
              ..setEntry(3, 2, 0.0009)
              ..rotateY(angle),
            child: Stack(
              fit: StackFit.expand,
              children: [
                DecoratedBox(
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.35 * frac),
                        blurRadius: 18,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: top,
                ),
                // страница темнеет по мере поворота
                IgnorePointer(
                  child: ColoredBox(
                    color: Colors.black.withValues(alpha: 0.45 * frac),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
