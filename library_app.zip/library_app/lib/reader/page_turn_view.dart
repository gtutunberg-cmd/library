import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

/// Управление листанием снаружи (кнопки, ползунок, оглавление, озвучка).
class PageTurnController {
  _PageTurnViewState? _state;

  void _attach(_PageTurnViewState s) => _state = s;
  void _detach(_PageTurnViewState s) {
    if (_state == s) _state = null;
  }

  void next() => _state?._go(1);
  void prev() => _state?._go(-1);
  void jumpTo(int page) => _state?._jump(page);
}

/// Листание как в бумажной книге: правый край страницы приподнимается
/// и сворачивается мягким валиком, под ним видна следующая страница.
/// Оборот листа просвечивает бледным текстом, на валике есть блик и тени.
///
/// Жесты: свайп влево/вправо (с учётом скорости), тап по краям экрана;
/// тап по центру вызывает [onCenterTap].
class PageTurnView extends StatefulWidget {
  const PageTurnView({
    super.key,
    required this.pageCount,
    required this.itemBuilder,
    required this.background,
    this.initialPage = 0,
    this.controller,
    this.onPageChanged,
    this.onCenterTap,
    this.onTurn,
    this.version = 0,
  });

  final int pageCount;
  final IndexedWidgetBuilder itemBuilder;
  final Color background;
  final int initialPage;
  final PageTurnController? controller;
  final ValueChanged<int>? onPageChanged;
  final VoidCallback? onCenterTap;

  /// Вызывается, когда страница пошла переворачиваться (для звука).
  final VoidCallback? onTurn;

  /// Меняется, когда страницы выглядят иначе (тема): снимки перерисовываются.
  final int version;

  @override
  State<PageTurnView> createState() => _PageTurnViewState();
}

class _PageTurnViewState extends State<PageTurnView>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  int _reported = -1;
  double _target = 0;
  bool _dragging = false;

  final Map<int, ui.Image> _snaps = {};
  final Map<int, GlobalKey> _keys = {};
  bool _captureScheduled = false;

  int get _count => widget.pageCount;
  double get _maxPos => math.max(0, _count - 1).toDouble();
  int get _current => _c.value.round().clamp(0, math.max(0, _count - 1)).toInt();

  GlobalKey _keyFor(int i) => _keys.putIfAbsent(i, () => GlobalKey());

  @override
  void initState() {
    super.initState();
    final start = widget.initialPage.clamp(0, math.max(0, _count - 1)).toInt();
    _c = AnimationController(
      vsync: this,
      lowerBound: 0,
      upperBound: math.max(1, _count - 1).toDouble(),
      value: start.toDouble(),
    );
    _target = start.toDouble();
    _reported = start;
    _c.addStatusListener((s) {
      if (s == AnimationStatus.completed || s == AnimationStatus.dismissed) {
        _report();
      }
    });
    widget.controller?._attach(this);
    _scheduleCapture();
  }

  @override
  void didUpdateWidget(PageTurnView old) {
    super.didUpdateWidget(old);
    if (old.controller != widget.controller) {
      old.controller?._detach(this);
      widget.controller?._attach(this);
    }
    if (old.version != widget.version) {
      _clearSnaps();
      _scheduleCapture();
    }
  }

  @override
  void dispose() {
    widget.controller?._detach(this);
    _clearSnaps();
    _c.dispose();
    super.dispose();
  }

  // ---------- снимки страниц (для загиба) ----------

  void _clearSnaps() {
    for (final img in _snaps.values) {
      img.dispose();
    }
    _snaps.clear();
  }

  void _scheduleCapture() {
    if (_captureScheduled) return;
    _captureScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _captureScheduled = false;
      if (!mounted) return;
      _captureAround();
    });
  }

  bool _captureOne(int i) {
    if (i < 0 || i >= _count) return false;
    if (_snaps.containsKey(i)) return true;
    final ro = _keys[i]?.currentContext?.findRenderObject();
    if (ro is RenderRepaintBoundary) {
      try {
        final dpr = math.min(MediaQuery.of(context).devicePixelRatio, 2.0);
        _snaps[i] = ro.toImageSync(pixelRatio: dpr);
        return true;
      } catch (_) {
        return false;
      }
    }
    return false;
  }

  void _captureAround() {
    if (_c.isAnimating || _dragging) return;
    final p = _current;
    _captureOne(p - 1);
    _captureOne(p);
    _captureOne(p + 1);
    final far = _snaps.keys.where((k) => (k - p).abs() > 2).toList();
    for (final k in far) {
      _snaps.remove(k)?.dispose();
    }
  }

  /// Нужен снимок именно этой страницы (началась анимация, а снимка нет).
  void _ensureSnap(int i) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (_captureOne(i)) setState(() {});
    });
  }

  // ---------- логика листания ----------

  void _report() {
    final p = _current;
    if (p != _reported) {
      _reported = p;
      widget.onPageChanged?.call(p);
    }
    _scheduleCapture();
  }

  void _settle(double target) {
    final t = target.clamp(0.0, _maxPos).toDouble();
    _target = t;
    if (t.round() != _reported) widget.onTurn?.call();
    final dist = (t - _c.value).abs();
    if (dist < 0.001) {
      _c.value = t;
      _report();
      return;
    }
    final ms = (380 * dist.clamp(0.3, 1.0)).round();
    _c.animateTo(t, duration: Duration(milliseconds: ms), curve: Curves.easeInOutCubic);
  }

  void _go(int delta) {
    final base = _c.isAnimating ? _target : _current.toDouble();
    _settle(base + delta);
  }

  void _jump(int page) {
    _c.stop();
    final p = page.clamp(0, math.max(0, _count - 1)).toDouble();
    _target = p;
    _c.value = p;
    _report();
  }

  @override
  Widget build(BuildContext context) {
    if (_count == 0) return const SizedBox.shrink();
    return LayoutBuilder(builder: (context, constraints) {
      final w = constraints.maxWidth;
      final h = constraints.maxHeight;
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (d) {
          final x = d.localPosition.dx;
          if (x < w * 0.3) {
            _go(-1);
          } else if (x > w * 0.7) {
            _go(1);
          } else {
            widget.onCenterTap?.call();
          }
        },
        onHorizontalDragStart: (_) {
          _dragging = true;
          _c.stop();
        },
        onHorizontalDragUpdate: (d) {
          _c.value = (_c.value - d.delta.dx / (w * 1.05)).clamp(0.0, _maxPos).toDouble();
        },
        onHorizontalDragEnd: (d) {
          _dragging = false;
          final v = d.primaryVelocity ?? 0;
          final pos = _c.value;
          double target;
          if (v < -350) {
            target = pos.ceilToDouble();
          } else if (v > 350) {
            target = pos.floorToDouble();
          } else {
            target = pos.roundToDouble();
          }
          _settle(target);
        },
        onHorizontalDragCancel: () {
          _dragging = false;
          _settle(_c.value.roundToDouble());
        },
        child: AnimatedBuilder(
          animation: _c,
          builder: (context, _) => _buildPages(context, w, h),
        ),
      );
    });
  }

  Widget _page(BuildContext context, int i) {
    return RepaintBoundary(
      key: _keyFor(i),
      child: ColoredBox(
        color: widget.background,
        child: SizedBox.expand(child: widget.itemBuilder(context, i)),
      ),
    );
  }

  Widget _buildPages(BuildContext context, double w, double h) {
    var base = _c.value.floor();
    var t = _c.value - base;
    if (base >= _count - 1) {
      base = _count - 1;
      t = 0;
    }
    if (t < 0.002) t = 0;

    if (t == 0) {
      // Покой: соседние страницы лежат под текущей, чтобы сделать их снимки.
      return Stack(
        fit: StackFit.expand,
        children: [
          if (base - 1 >= 0) _page(context, base - 1),
          if (base + 1 < _count) _page(context, base + 1),
          _page(context, base),
        ],
      );
    }

    final snap = _snaps[base];
    if (snap == null) {
      _ensureSnap(base);
      return Stack(
        fit: StackFit.expand,
        children: [
          _page(context, base + 1),
          _page(context, base),
        ],
      );
    }

    return Stack(
      fit: StackFit.expand,
      children: [
        _page(context, base + 1),
        CustomPaint(
          size: Size(w, h),
          painter: _CurlPainter(image: snap, t: t, paper: widget.background),
        ),
      ],
    );
  }
}

/// Рисует страницу, свёрнутую валиком (как лист бумаги, который отгибают).
///
/// Модель: сгиб на линии [f] двигается справа налево. Часть листа правее сгиба
/// наматывается на цилиндр радиуса r, а за ним лежит оборотом вверх.
class _CurlPainter extends CustomPainter {
  _CurlPainter({required this.image, required this.t, required this.paper});

  final ui.Image image;
  final double t;
  final Color paper;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    if (w <= 0 || h <= 0) return;

    final kx = image.width / w;
    final srcH = image.height.toDouble();
    final cy = h / 2;

    final rEnd = w * 0.05;
    // Радиус валика: начинает с маленького, к середине мягко растёт.
    final r = math.max(1.0, w * (0.05 + 0.075 * math.sin(math.pi * t)));
    final f = w - t * (w + rEnd + 2);

    final imgPaint = Paint()
      ..filterQuality = FilterQuality.low
      ..isAntiAlias = false;
    final fill = Paint()..isAntiAlias = false;

    // 1. Плоская часть слева от сгиба.
    if (f > 0) {
      final fw = math.min(f, w);
      canvas.drawImageRect(
        image,
        Rect.fromLTWH(0, 0, fw * kx, srcH),
        Rect.fromLTWH(0, 0, fw, h),
        imgPaint,
      );
    }

    // 2. Тень от валика на нижней странице (справа от него).
    final shadowL = f + r - 4;
    if (shadowL < w) {
      final shadowR = shadowL + 42;
      canvas.drawRect(
        Rect.fromLTRB(shadowL, 0, math.min(w, shadowR), h),
        Paint()
          ..shader = ui.Gradient.linear(
            Offset(shadowL, 0),
            Offset(shadowR, 0),
            [
              Colors.black.withValues(alpha: 0.32 * (1 - 0.5 * t)),
              Colors.black.withValues(alpha: 0.0),
            ],
          ),
      );
    }

    // 3. Тень от лежащего оборота на самой странице (слева от оборота).
    final flatBackLen = math.max(0.0, (w - f) - math.pi * r);
    final xl = f - flatBackLen;
    if (flatBackLen > 0 && xl > 0) {
      final sl = math.max(0.0, xl - 26);
      canvas.drawRect(
        Rect.fromLTRB(sl, 0, xl, h),
        Paint()
          ..shader = ui.Gradient.linear(
            Offset(sl, 0),
            Offset(xl, 0),
            [
              Colors.black.withValues(alpha: 0.0),
              Colors.black.withValues(alpha: 0.26),
            ],
          ),
      );
    }

    // 4. Валик и оборот: тонкие полоски исходного снимка.
    final backColor = Color.lerp(paper, Colors.black, 0.05)!;
    final ghost = Paint()
      ..filterQuality = FilterQuality.low
      ..isAntiAlias = false
      ..color = const Color.fromRGBO(255, 255, 255, 0.07);
    const step = 2.0;
    final lim = math.pi * r;

    double posX(double d) {
      if (d <= 0) return f + d;
      if (d <= lim) return f + r * math.sin(d / r);
      return f - (d - lim);
    }

    double angleOf(double d) {
      if (d <= 0) return 0;
      return d <= lim ? d / r : math.pi;
    }

    for (var x0 = math.max(0.0, f); x0 < w; x0 += step) {
      final x1 = math.min(w, x0 + step);
      final d0 = x0 - f;
      final d1 = x1 - f;
      final xa = posX(d0);
      final xb = posX(d1);
      final left = math.min(xa, xb);
      final right = math.max(xa, xb);
      if (right < -2 || left > w) continue;

      final th = angleOf((d0 + d1) / 2);
      final z = r * (1 - math.cos(th));
      final s = 1 / (1 - z / (w * 3.4));
      final dst = Rect.fromLTRB(left - 0.4, cy - cy * s, right + 0.4, cy + cy * s);
      final src = Rect.fromLTWH(x0 * kx, 0, (x1 - x0) * kx, srcH);

      if (th <= math.pi / 2) {
        canvas.drawImageRect(image, src, dst, imgPaint);
        final shade = 0.38 * (1 - math.cos(th));
        if (shade > 0.004) {
          fill.color = Colors.black.withValues(alpha: shade);
          canvas.drawRect(dst, fill);
        }
      } else {
        fill.color = backColor;
        canvas.drawRect(dst, fill);
        canvas.drawImageRect(image, src, dst, ghost);
        final shade = 0.30 * math.cos(th - math.pi / 2);
        if (shade > 0.004) {
          fill.color = Colors.black.withValues(alpha: shade);
          canvas.drawRect(dst, fill);
        }
      }

      // Блик на гребне валика.
      final dist = (th - math.pi / 2).abs();
      if (dist < 0.32) {
        fill.color = Colors.white.withValues(alpha: 0.20 * (1 - dist / 0.32));
        canvas.drawRect(dst, fill);
      }
    }
  }

  @override
  bool shouldRepaint(_CurlPainter old) =>
      old.t != t || old.image != image || old.paper != paper;
}
