import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

/// Управление листанием снаружи (кнопки, ползунок, оглавление, озвучка).
class PageTurnController {
  _PageTurnViewState? _state;

  void _attach(_PageTurnViewState s) => _state = s;
  void _detach(_PageTurnViewState s) {
    if (_state == s) _state = null;
  }

  void next() => _state?._go(1, tilt: _defaultTilt);
  void prev() => _state?._go(-1, tilt: _defaultTilt);
  void jumpTo(int page) => _state?._jump(page);
}

/// Наклон сгиба по умолчанию (как будто берёмся за нижний правый угол).
const double _defaultTilt = 0.3;

/// Листание как в бумажной книге. Страница отгибается от того угла,
/// за который берёшься: за нижний правый сгиб идёт по диагонали снизу,
/// за верхний правый сверху, за середину края сгиб ровный.
/// Страница сворачивается мягким валиком, под ним видна следующая;
/// оборот листа просвечивает бледным текстом, на валике есть тени.
///
/// Жесты: свайп (с учётом скорости и угла), тап по краям экрана;
/// тап по центру вызывает [onCenterTap].
class PageTurnView extends StatefulWidget {
  const PageTurnView({
    super.key,
    required this.pageCount,
    required this.itemBuilder,
    required this.background,
    this.initialPage = 0,
    this.controller,
    this.onPageChanged,
    this.onCenterTap,
    this.onTurn,
    this.version = 0,
  });

  final int pageCount;
  final IndexedWidgetBuilder itemBuilder;
  final Color background;
  final int initialPage;
  final PageTurnController? controller;
  final ValueChanged<int>? onPageChanged;
  final VoidCallback? onCenterTap;

  /// Вызывается, когда страница пошла переворачиваться (для звука).
  final VoidCallback? onTurn;

  /// Меняется, когда страницы выглядят иначе (тема): снимки перерисовываются.
  final int version;

  @override
  State<PageTurnView> createState() => _PageTurnViewState();
}

class _PageTurnViewState extends State<PageTurnView>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  int _reported = -1;
  double _target = 0;
  bool _dragging = false;
  double _tilt = _defaultTilt;

  final Map<int, ui.Image> _snaps = {};
  final Map<int, GlobalKey> _keys = {};
  bool _captureScheduled = false;

  int get _count => widget.pageCount;
  double get _maxPos => math.max(0, _count - 1).toDouble();
  int get _current => _c.value.round().clamp(0, math.max(0, _count - 1)).toInt();

  GlobalKey _keyFor(int i) => _keys.putIfAbsent(i, () => GlobalKey());

  /// Угол сгиба по высоте касания: у верхнего края сгиб наклонён вверх,
  /// у нижнего вниз, посередине ровный.
  double _tiltFor(double gy) =>
      ((gy - 0.5) * 2).clamp(-1.0, 1.0).toDouble() * 0.7;

  @override
  void initState() {
    super.initState();
    final start = widget.initialPage.clamp(0, math.max(0, _count - 1)).toInt();
    _c = AnimationController(
      vsync: this,
      lowerBound: 0,
      upperBound: math.max(1, _count - 1).toDouble(),
      value: start.toDouble(),
    );
    _target = start.toDouble();
    _reported = start;
    _c.addStatusListener((s) {
      if (s == AnimationStatus.completed || s == AnimationStatus.dismissed) {
        _report();
      }
    });
    widget.controller?._attach(this);
    _scheduleCapture();
  }

  @override
  void didUpdateWidget(PageTurnView old) {
    super.didUpdateWidget(old);
    if (old.controller != widget.controller) {
      old.controller?._detach(this);
      widget.controller?._attach(this);
    }
    if (old.version != widget.version) {
      _clearSnaps();
      _scheduleCapture();
    }
  }

  @override
  void dispose() {
    widget.controller?._detach(this);
    _clearSnaps();
    _c.dispose();
    super.dispose();
  }

  // ---------- снимки страниц (для загиба) ----------

  void _clearSnaps() {
    for (final img in _snaps.values) {
      img.dispose();
    }
    _snaps.clear();
  }

  void _scheduleCapture() {
    if (_captureScheduled) return;
    _captureScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _captureScheduled = false;
      if (!mounted) return;
      _captureAround();
    });
  }

  bool _captureOne(int i) {
    if (i < 0 || i >= _count) return false;
    if (_snaps.containsKey(i)) return true;
    final ro = _keys[i]?.currentContext?.findRenderObject();
    if (ro is RenderRepaintBoundary) {
      try {
        final dpr = math.min(MediaQuery.of(context).devicePixelRatio, 2.0);
        _snaps[i] = ro.toImageSync(pixelRatio: dpr);
        return true;
      } catch (_) {
        return false;
      }
    }
    return false;
  }

  void _captureAround() {
    if (_c.isAnimating || _dragging) return;
    final p = _current;
    _captureOne(p - 1);
    _captureOne(p);
    _captureOne(p + 1);
    final far = _snaps.keys.where((k) => (k - p).abs() > 2).toList();
    for (final k in far) {
      _snaps.remove(k)?.dispose();
    }
  }

  /// Нужен снимок именно этой страницы (началась анимация, а снимка нет).
  void _ensureSnap(int i) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (_captureOne(i)) setState(() {});
    });
  }

  // ---------- логика листания ----------

  void _report() {
    final p = _current;
    if (p != _reported) {
      _reported = p;
      widget.onPageChanged?.call(p);
    }
    _scheduleCapture();
  }

  void _settle(double target) {
    final t = target.clamp(0.0, _maxPos).toDouble();
    _target = t;
    if (t.round() != _reported) widget.onTurn?.call();
    final dist = (t - _c.value).abs();
    if (dist < 0.001) {
      _c.value = t;
      _report();
      return;
    }
    final ms = (380 * dist.clamp(0.3, 1.0)).round();
    _c.animateTo(t, duration: Duration(milliseconds: ms), curve: Curves.easeInOutCubic);
  }

  void _go(int delta, {double? tilt}) {
    if (tilt != null) _tilt = tilt;
    final base = _c.isAnimating ? _target : _current.toDouble();
    _settle(base + delta);
  }

  void _jump(int page) {
    _c.stop();
    final p = page.clamp(0, math.max(0, _count - 1)).toDouble();
    _target = p;
    _c.value = p;
    _report();
  }

  @override
  Widget build(BuildContext context) {
    if (_count == 0) return const SizedBox.shrink();
    return LayoutBuilder(builder: (context, constraints) {
      final w = constraints.maxWidth;
      final h = constraints.maxHeight;
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (d) {
          final x = d.localPosition.dx;
          final tilt = _tiltFor(d.localPosition.dy / h);
          if (x < w * 0.3) {
            _go(-1, tilt: tilt);
          } else if (x > w * 0.7) {
            _go(1, tilt: tilt);
          } else {
            widget.onCenterTap?.call();
          }
        },
        onPanStart: (d) {
          _dragging = true;
          _tilt = _tiltFor(d.localPosition.dy / h);
          _c.stop();
        },
        onPanUpdate: (d) {
          final dn = d.delta.dx * math.cos(_tilt) + d.delta.dy * math.sin(_tilt);
          final travel = _CurlPainter.travelFor(w, h, _tilt);
          _c.value = (_c.value - dn / travel).clamp(0.0, _maxPos).toDouble();
        },
        onPanEnd: (d) {
          _dragging = false;
          final vel = d.velocity.pixelsPerSecond;
          final v = vel.dx * math.cos(_tilt) + vel.dy * math.sin(_tilt);
          final pos = _c.value;
          double target;
          if (v < -350) {
            target = pos.ceilToDouble();
          } else if (v > 350) {
            target = pos.floorToDouble();
          } else {
            target = pos.roundToDouble();
          }
          _settle(target);
        },
        onPanCancel: () {
          _dragging = false;
          _settle(_c.value.roundToDouble());
        },
        child: AnimatedBuilder(
          animation: _c,
          builder: (context, _) => _buildPages(context, w, h),
        ),
      );
    });
  }

  Widget _page(BuildContext context, int i) {
    return RepaintBoundary(
      key: _keyFor(i),
      child: ColoredBox(
        color: widget.background,
        child: SizedBox.expand(child: widget.itemBuilder(context, i)),
      ),
    );
  }

  Widget _buildPages(BuildContext context, double w, double h) {
    var base = _c.value.floor();
    var t = _c.value - base;
    if (base >= _count - 1) {
      base = _count - 1;
      t = 0;
    }
    if (t < 0.002) t = 0;

    if (t == 0) {
      // Покой: соседние страницы лежат под текущей, чтобы сделать их снимки.
      return Stack(
        fit: StackFit.expand,
        children: [
          if (base - 1 >= 0) _page(context, base - 1),
          if (base + 1 < _count) _page(context, base + 1),
          _page(context, base),
        ],
      );
    }

    final snap = _snaps[base];
    if (snap == null) {
      _ensureSnap(base);
      return Stack(
        fit: StackFit.expand,
        children: [
          _page(context, base + 1),
          _page(context, base),
        ],
      );
    }

    return Stack(
      fit: StackFit.expand,
      children: [
        _page(context, base + 1),
        CustomPaint(
          size: Size(w, h),
          painter: _CurlPainter(
            image: snap,
            t: t,
            paper: widget.background,
            tilt: _tilt,
          ),
        ),
      ],
    );
  }
}

/// Рисует страницу, свёрнутую валиком (как лист бумаги, который отгибают).
///
/// Работает в повёрнутой системе координат: ось u направлена поперёк линии
/// сгиба (угол [tilt] к оси X), ось v вдоль неё. Сгиб на линии u = uf
/// двигается от угла страницы к противоположному краю. Часть листа за сгибом
/// наматывается на цилиндр радиуса r, а за ним лежит оборотом вверх.
class _CurlPainter extends CustomPainter {
  _CurlPainter({
    required this.image,
    required this.t,
    required this.paper,
    required this.tilt,
  });

  final ui.Image image;
  final double t;
  final Color paper;
  final double tilt;

  /// Диапазон координаты u по углам страницы.
  static (double, double) uRange(double w, double h, double tilt) {
    final c = math.cos(tilt);
    final s = math.sin(tilt);
    final us = [0.0, w * c, h * s, w * c + h * s];
    return (us.reduce(math.min), us.reduce(math.max));
  }

  /// Длина пути сгиба: от дальнего угла до полного исчезновения листа.
  static double travelFor(double w, double h, double tilt) {
    final (lo, hi) = uRange(w, h, tilt);
    return (hi - lo) + w * 0.05 + 2;
  }

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    if (w <= 0 || h <= 0) return;
    canvas.clipRect(Offset.zero & size);

    final c = math.cos(tilt);
    final s0 = math.sin(tilt);
    final (uMin, uMax) = uRange(w, h, tilt);
    final vc = (-w * s0 + h * c) / 2;
    final big = (w + h) * 2;
    final srcRect = Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble());
    final dstRect = Rect.fromLTWH(0, 0, w, h);

    // Радиус валика: начинает с маленького, к середине мягко растёт.
    final r = math.max(1.0, w * (0.05 + 0.075 * math.sin(math.pi * t)));
    final uf = uMax - t * travelFor(w, h, tilt);
    final lim = math.pi * r;

    final plain = Paint()
      ..filterQuality = FilterQuality.low
      ..isAntiAlias = false;
    final ghost = Paint()
      ..filterQuality = FilterQuality.low
      ..isAntiAlias = false
      ..color = const Color.fromRGBO(255, 255, 255, 0.07);
    final backColor = Color.lerp(paper, Colors.black, 0.05)!;
    final tint = Paint()
      ..isAntiAlias = false
      ..colorFilter = ColorFilter.mode(backColor, BlendMode.srcIn);

    Paint shadePaint(double a) => Paint()
      ..isAntiAlias = false
      ..colorFilter = ColorFilter.mode(Color.fromRGBO(0, 0, 0, a), BlendMode.srcIn);

    // Рисует снимок страницы в повёрнутой системе: исходная полоса [u0, u1]
    // попадает в полосу экрана [clipL, clipR] с растяжением kx по u и sy по v.
    void strip(
      Paint paint,
      double clipL,
      double clipR,
      double kx,
      double sy,
      double shiftU,
      double shiftV,
    ) {
      canvas.save();
      canvas.rotate(tilt);
      canvas.clipRect(Rect.fromLTRB(clipL, -big, clipR, big), doAntiAlias: false);
      canvas.translate(shiftU, shiftV);
      canvas.scale(kx, sy);
      canvas.rotate(-tilt);
      canvas.drawImageRect(image, srcRect, dstRect, paint);
      canvas.restore();
    }

    // 1. Плоская часть до сгиба.
    if (uf > uMin) strip(plain, -big, uf, 1, 1, 0, 0);

    // 2. Тени: от валика на нижнюю страницу, от оборота на саму страницу.
    final flatBackLen = math.max(0.0, (uMax - uf) - lim);
    final xl = uf - flatBackLen;
    canvas.save();
    canvas.rotate(tilt);
    final shadowL = uf + r - 4;
    final shadowR = shadowL + 42;
    canvas.drawRect(
      Rect.fromLTRB(shadowL, -big, shadowR, big),
      Paint()
        ..shader = ui.Gradient.linear(
          Offset(shadowL, 0),
          Offset(shadowR, 0),
          [
            Colors.black.withValues(alpha: 0.32 * (1 - 0.5 * t)),
            Colors.black.withValues(alpha: 0.0),
          ],
        ),
    );
    if (flatBackLen > 0 && xl > uMin) {
      final sl = xl - 26;
      canvas.drawRect(
        Rect.fromLTRB(sl, -big, xl, big),
        Paint()
          ..shader = ui.Gradient.linear(
            Offset(sl, 0),
            Offset(xl, 0),
            [
              Colors.black.withValues(alpha: 0.0),
              Colors.black.withValues(alpha: 0.26),
            ],
          ),
      );
    }
    canvas.restore();

    // 3. Валик и оборот: тонкие полосы исходного снимка.
    double posX(double d) {
      if (d <= 0) return uf + d;
      if (d <= lim) return uf + r * math.sin(d / r);
      return uf - (d - lim);
    }

    double angleOf(double d) {
      if (d <= 0) return 0;
      return d <= lim ? d / r : math.pi;
    }

    const step = 3.0;
    for (var u0 = math.max(uf, uMin); u0 < uMax; u0 += step) {
      final u1 = u0 + step;
      final xa = posX(u0 - uf);
      final xb = posX(u1 - uf);
      final width = xb - xa;
      if (width.abs() < 0.02) continue;

      final kx = width / step;
      final th = angleOf((u0 + u1) / 2 - uf);
      final z = r * (1 - math.cos(th));
      final sy = 1 / (1 - z / (w * 3.4));
      final shiftU = xa - kx * u0;
      final shiftV = vc * (1 - sy);
      final cl = math.min(xa, xb) - 0.4;
      final cr = math.max(xa, xb) + 0.4;

      if (th <= math.pi / 2) {
        strip(plain, cl, cr, kx, sy, shiftU, shiftV);
        final shade = 0.38 * (1 - math.cos(th));
        if (shade > 0.004) strip(shadePaint(shade), cl, cr, kx, sy, shiftU, shiftV);
      } else {
        strip(tint, cl, cr, kx, sy, shiftU, shiftV);
        strip(ghost, cl, cr, kx, sy, shiftU, shiftV);
        final shade = 0.30 * math.cos(th - math.pi / 2);
        if (shade > 0.004) strip(shadePaint(shade), cl, cr, kx, sy, shiftU, shiftV);
      }
    }
  }

  @override
  bool shouldRepaint(_CurlPainter old) =>
      old.t != t || old.image != image || old.paper != paper || old.tilt != tilt;
}
