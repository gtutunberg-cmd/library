import 'package:audioplayers/audioplayers.dart';

/// Шелест бумаги при перелистывании. Не забирает аудиофокус,
/// поэтому не прерывает озвучку и чужую музыку.
class FlipSound {
  FlipSound._();
  static final FlipSound instance = FlipSound._();

  final AudioPlayer _player = AudioPlayer();
  final AudioContext _ctx = AudioContext(
    android: const AudioContextAndroid(audioFocus: AndroidAudioFocus.none),
  );

  Future<void> play() async {
    try {
      await _player.play(
        AssetSource('sounds/flip.wav'),
        volume: 0.7,
        ctx: _ctx,
        mode: PlayerMode.lowLatency,
      );
    } catch (_) {}
  }
}
