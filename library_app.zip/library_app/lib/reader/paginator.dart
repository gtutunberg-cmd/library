import 'dart:math' as math;

import 'package:flutter/widgets.dart';

/// Одна страница: готовый текст и смещение (в символах) её начала в книге.
class BookPage {
  final String text;
  final int start;
  const BookPage(this.text, this.start);
}

/// Красная строка (два круглых пробела).
const String paragraphIndent = '  ';

/// Индекс страницы, на которой находится символ с данным смещением.
int pageForOffset(List<BookPage> pages, int offset) {
  if (pages.isEmpty) return 0;
  var lo = 0;
  var hi = pages.length - 1;
  while (lo < hi) {
    final mid = (lo + hi + 1) >> 1;
    if (pages[mid].start <= offset) {
      lo = mid;
    } else {
      hi = mid - 1;
    }
  }
  return lo;
}

/// Разбивает абзацы на страницы по реальной раскладке текста (TextPainter).
///
/// Строки страницы потом отображаются тем же стилем и той же шириной,
/// поэтому переносы на странице совпадают с расчётными.
/// Возвращает null, если [isStale] стал true (параметры уже изменились).
Future<List<BookPage>?> paginate({
  required List<String> paragraphs,
  required TextStyle style,
  required StrutStyle strut,
  required double width,
  required double height,
  required bool Function() isStale,
}) async {
  final nominal = (style.fontSize ?? 16) * (style.height ?? 1.0);

  final pages = <BookPage>[];
  final buf = StringBuffer();
  var linesOnPage = 0;
  var pageStart = 0;
  var pageOpen = false;

  void flush() {
    if (!pageOpen) return;
    pages.add(BookPage(buf.toString(), pageStart));
    buf.clear();
    linesOnPage = 0;
    pageOpen = false;
  }

  final painter = TextPainter(
    textDirection: TextDirection.ltr,
    strutStyle: strut,
    textScaler: TextScaler.noScaling,
  );

  // Реальная высота строки (может быть чуть больше расчётной).
  painter.text = TextSpan(text: 'Ауфg\nАуфg', style: style);
  painter.layout(maxWidth: width);
  var measured = nominal;
  final lm = painter.computeLineMetrics();
  if (lm.length >= 2) {
    measured = math.max(nominal, (lm[1].baseline - lm[0].baseline));
  }
  final linesPerPage = math.max(1, ((height - 2) / measured).floor());

  var globalOffset = 0;
  for (var i = 0; i < paragraphs.length; i++) {
    final raw = paragraphs[i];
    final para = '$paragraphIndent$raw';
    painter.text = TextSpan(text: para, style: style);
    painter.layout(maxWidth: width);

    var pos = 0;
    var first = true;
    while (pos < para.length) {
      var end = painter.getLineBoundary(TextPosition(offset: pos)).end;
      if (end <= pos) end = pos + 1; // страховка от зацикливания
      if (end > para.length) end = para.length;

      if (linesOnPage >= linesPerPage) flush();
      if (!pageOpen) {
        pageOpen = true;
        pageStart = globalOffset + math.max(0, pos - paragraphIndent.length);
      } else if (first) {
        buf.write('\n'); // граница абзацев внутри страницы
      }
      buf.write(para.substring(pos, end));
      linesOnPage++;
      first = false;
      pos = end;
    }

    globalOffset += raw.length + 1;

    if ((i & 31) == 31) {
      await Future<void>.delayed(Duration.zero); // отдаём кадр интерфейсу
      if (isStale()) {
        painter.dispose();
        return null;
      }
    }
  }

  flush();
  painter.dispose();
  if (pages.isEmpty) pages.add(const BookPage('', 0));
  return pages;
}
