import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

import '../data/library_store.dart';
import '../data/reader_settings.dart';
import '../parsers/book_content.dart';
import '../parsers/book_loader.dart';
import '../tts/tts_global.dart';
import '../tts/tts_handler.dart';
import '../ui/book_cover.dart';
import 'flip_sound.dart';
import 'page_turn_view.dart';
import 'paginator.dart';
import 'text_metrics.dart';

class ReaderScreen extends StatefulWidget {
  const ReaderScreen({
    super.key,
    required this.entry,
    required this.library,
    required this.settings,
  });

  final BookEntry entry;
  final LibraryStore library;
  final ReaderSettings settings;

  @override
  State<ReaderScreen> createState() => _ReaderScreenState();
}

/// Нумерация страниц: 0 — обложка, 1... — страницы текста.
/// Номер текстовой страницы в списке [_pages] на единицу меньше.
class _ReaderScreenState extends State<ReaderScreen> with WidgetsBindingObserver {
  BookContent? _content;
  Object? _error;

  List<BookPage>? _pages;
  List<int> _paraOffsets = const [];

  String? _paginationKey;
  int _gen = 0;
  bool _paginating = false;

  int _page = 0;
  int _anchorOffset = 0;
  Key _turnKey = UniqueKey();
  final PageTurnController _turn = PageTurnController();

  bool _bars = false;
  int _bmVersion = 0;
  Timer? _saveTimer;

  final TtsHandler? _tts = ttsHandler;
  bool _foreground = true;
  bool _askedNotifications = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _anchorOffset = widget.entry.lastOffset;
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    widget.library.touch(widget.entry);
    _tts?.onPage = _onTtsPage;
    _tts?.notice.addListener(_onTtsNotice);
    _open();
  }

  Future<void> _open() async {
    try {
      final content = await loadBook(
        widget.entry.path,
        widget.entry.format,
        fallbackTitle: widget.entry.title,
      );
      if (!mounted) return;
      setState(() {
        _content = content;
        _paraOffsets = content.paragraphOffsets;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _saveTimer?.cancel();
    _flushProgress();
    _gen++; // останавливаем фоновую разбивку на страницы
    final tts = _tts;
    if (tts != null) {
      tts.notice.removeListener(_onTtsNotice);
      tts.onPage = null;
      tts.stop();
    }
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _foreground = state == AppLifecycleState.resumed;
  }

  // ---------- прогресс ----------

  void _scheduleSave() {
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 700), _flushProgress);
  }

  void _flushProgress() {
    final pages = _pages;
    final content = _content;
    if (pages == null || content == null || pages.isEmpty) return;
    if (_page == 0) return; // на обложке место чтения не меняем
    final i = (_page - 1).clamp(0, pages.length - 1).toInt();
    widget.library.saveProgress(widget.entry, pages[i].start, content.totalChars);
  }

  void _onPageChanged(int i) {
    setState(() => _page = i);
    _scheduleSave();
    final tts = _tts;
    // Если читатель сам перелистнул во время озвучки, читаем уже с этой страницы.
    if (tts != null && tts.speaking.value && i > 0 && (i - 1) != tts.currentPage) {
      tts.jumpToPage(i - 1);
    }
  }

  void _playFlip() {
    if (widget.settings.sound && _foreground) FlipSound.instance.play();
  }

  // ---------- озвучка ----------

  void _onTtsPage(int textPage) {
    final shown = textPage + 1;
    if (!mounted || _pages == null || shown == _page) return;
    if (_foreground && shown == _page + 1) {
      _turn.next();
    } else {
      // В фоне и при заблокированном экране анимации нет, листаем сразу.
      _turn.jumpTo(shown);
    }
  }

  void _onTtsNotice() {
    final msg = _tts?.notice.value;
    if (msg == null || !mounted) return;
    _tts?.notice.value = null;
    _snack(msg);
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), duration: const Duration(seconds: 6)),
    );
  }

  Future<void> _toggleSpeak() async {
    final tts = _tts;
    if (tts == null) {
      _snack('Озвучка недоступна на этом устройстве');
      return;
    }
    if (tts.speaking.value) {
      await tts.pause();
      return;
    }
    final pages = _pages;
    if (pages == null) return;
    if (!_askedNotifications) {
      _askedNotifications = true;
      try {
        await Permission.notification.request();
      } catch (_) {}
    }
    final s = widget.settings;
    final err = await tts.startReading(
      title: widget.entry.title,
      author: widget.entry.author,
      pageTexts: [for (final p in pages) p.text],
      startPage: math.max(0, _page - 1),
      rate: s.ttsRate,
      pitch: s.ttsPitch,
      voice: s.ttsVoice.isEmpty ? null : s.ttsVoice,
      voiceLocale: s.ttsVoiceLocale,
      engine: s.ttsEngine.isEmpty ? null : s.ttsEngine,
    );
    if (err != null && mounted) _snack(err);
  }

  // ---------- разбивка на страницы ----------

  void _ensurePagination(Size size, EdgeInsets inset, ReaderSettings s) {
    if (_content == null) return;
    final key = '${size.width.toStringAsFixed(1)}x${size.height.toStringAsFixed(1)}'
        '|${inset.left},${inset.top},${inset.right},${inset.bottom}'
        '|${s.fontSize}|${s.lineHeight}|${s.serif}|${s.fontFamilyName}';
    if (key == _paginationKey) return;
    _paginationKey = key;
    final gen = ++_gen;

    final width = size.width - inset.horizontal;
    final height = size.height - inset.vertical;
    final style = readerTextStyle(s, Colors.black);
    final strut = readerStrut(s);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _runPagination(gen, style, strut, width, height);
    });
  }

  Future<void> _runPagination(
    int gen,
    TextStyle style,
    StrutStyle strut,
    double width,
    double height,
  ) async {
    if (!mounted || gen != _gen) return;
    final content = _content;
    if (content == null) return;

    final existing = _pages;
    var anchor = _anchorOffset;
    if (existing != null && existing.isNotEmpty) {
      anchor = _page > 0
          ? existing[(_page - 1).clamp(0, existing.length - 1).toInt()].start
          : 0;
    }

    setState(() => _paginating = true);
    final result = await paginate(
      paragraphs: content.paragraphs,
      style: style,
      strut: strut,
      width: width,
      height: height,
      isStale: () => !mounted || gen != _gen,
    );
    if (!mounted || gen != _gen || result == null) return;

    // Страницы изменились, номера в очереди озвучки устарели.
    if (existing != null) _tts?.stop();

    int newPage;
    if (existing == null) {
      // Новая книга открывается на обложке, начатая на месте, где остановились.
      newPage = widget.entry.lastOffset > 0 ? pageForOffset(result, anchor) + 1 : 0;
    } else if (_page == 0) {
      newPage = 0;
    } else {
      newPage = pageForOffset(result, anchor) + 1;
    }

    setState(() {
      _pages = result;
      _page = newPage;
      _turnKey = UniqueKey();
      _paginating = false;
    });
  }

  // ---------- интерфейс ----------

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.settings,
      builder: (context, _) {
        final s = widget.settings;
        final theme = readerThemes[s.themeIndex];
        return Scaffold(
          backgroundColor: theme.bg,
          body: _buildBody(context, s, theme),
        );
      },
    );
  }

  Widget _buildBody(BuildContext context, ReaderSettings s, ReaderThemeData theme) {
    if (_error != null) {
      return SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.error_outline, size: 48, color: theme.fg),
                const SizedBox(height: 12),
                Text(
                  'Не удалось открыть книгу\n$_error',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: theme.fg),
                ),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: () => Navigator.of(context).maybePop(),
                  child: const Text('Назад'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return LayoutBuilder(builder: (context, constraints) {
      final mq = MediaQuery.of(context);
      final size = constraints.biggest;
      final inset = EdgeInsets.fromLTRB(
        26 + mq.padding.left,
        mq.padding.top + 18,
        22 + mq.padding.right,
        mq.padding.bottom + 34,
      );
      _ensurePagination(size, inset, s);

      final pages = _pages;
      return Stack(
        fit: StackFit.expand,
        children: [
          if (pages == null)
            Center(child: CircularProgressIndicator(color: theme.fg))
          else
            PageTurnView(
              key: _turnKey,
              pageCount: pages.length + 1,
              initialPage: _page,
              controller: _turn,
              background: theme.bg,
              version: s.themeIndex + s.textAlign * 10 + _bmVersion * 100,
              onPageChanged: _onPageChanged,
              onCenterTap: () => setState(() => _bars = !_bars),
              onLongPress: _showNoteEditor,
              onTurn: _playFlip,
              itemBuilder: (ctx, i) => i == 0
                  ? _buildCover(size)
                  : _buildPage(i - 1, s, theme, size, inset, mq),
            ),
          if (pages != null && _paginating)
            Positioned(
              top: mq.padding.top,
              left: 0,
              right: 0,
              child: LinearProgressIndicator(
                minHeight: 2,
                color: theme.fg.withValues(alpha: 0.6),
                backgroundColor: Colors.transparent,
              ),
            ),
          if (pages != null) _buildTopBar(context, mq),
          if (pages != null) _buildBottomBar(context, mq, pages),
        ],
      );
    });
  }

  /// Обложка: та же, что на полке, растянутая на весь экран.
  Widget _buildCover(Size size) {
    return BookCoverArt(
      book: widget.entry,
      width: size.width,
      height: size.height,
      large: true,
    );
  }

  Widget _buildPage(
    int i,
    ReaderSettings s,
    ReaderThemeData theme,
    Size size,
    EdgeInsets inset,
    MediaQueryData mq,
  ) {
    final pages = _pages!;
    final p = pages[i];
    final footerStyle = TextStyle(
      fontSize: 11,
      color: theme.fg.withValues(alpha: 0.5),
    );
    return ColoredBox(
      color: theme.bg,
      child: Stack(
        children: [
          Positioned(
            left: inset.left,
            top: inset.top,
            width: size.width - inset.horizontal,
            height: size.height - inset.vertical,
            child: _tts == null
                ? _pageText(p.text, null, s, theme)
                : ValueListenableBuilder<TtsHighlight?>(
                    valueListenable: _tts!.highlight,
                    builder: (ctx, h, _) => _pageText(
                      p.text,
                      (h != null && h.page == i && h.end <= p.text.length) ? h : null,
                      s,
                      theme,
                    ),
                  ),
          ),
          if (_isBookmarked(i))
            Positioned(
              right: 18,
              top: 0,
              child: IgnorePointer(
                child: Icon(Icons.bookmark, size: 38, color: Colors.red.shade700),
              ),
            ),
          // мягкая тень у корешка, как на развороте книги
          Positioned(
            left: 0,
            top: 0,
            bottom: 0,
            width: 20,
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors: [
                      Colors.black.withValues(alpha: 0.10),
                      Colors.black.withValues(alpha: 0.0),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            left: inset.left,
            right: inset.right,
            bottom: mq.padding.bottom + 8,
            height: 18,
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    widget.entry.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: footerStyle,
                  ),
                ),
                const SizedBox(width: 12),
                Text('${i + 1} / ${pages.length}', style: footerStyle),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Текст страницы; читаемое сейчас слово подсвечивается.
  Widget _pageText(String text, TtsHighlight? h, ReaderSettings s, ReaderThemeData theme) {
    final style = readerTextStyle(s, theme.fg);
    final align = const [
      TextAlign.left,
      TextAlign.center,
      TextAlign.right,
      TextAlign.justify,
    ][s.textAlign];
    if (h == null) {
      return Text(
        text,
        textAlign: align,
        overflow: TextOverflow.visible,
        textScaler: TextScaler.noScaling,
        style: style,
        strutStyle: readerStrut(s),
      );
    }
    return Text.rich(
      TextSpan(
        children: [
          TextSpan(text: text.substring(0, h.start)),
          TextSpan(
            text: text.substring(h.start, h.end),
            style: TextStyle(
              backgroundColor: const Color(0xFFE0A030).withValues(alpha: 0.55),
            ),
          ),
          TextSpan(text: text.substring(h.end)),
        ],
      ),
      textAlign: align,
      overflow: TextOverflow.visible,
      textScaler: TextScaler.noScaling,
      style: style,
      strutStyle: readerStrut(s),
    );
  }

  Widget _buildTopBar(BuildContext context, MediaQueryData mq) {
    final scheme = Theme.of(context).colorScheme;
    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      child: IgnorePointer(
        ignoring: !_bars,
        child: AnimatedSlide(
          offset: _bars ? Offset.zero : const Offset(0, -1),
          duration: const Duration(milliseconds: 200),
          child: AnimatedOpacity(
            opacity: _bars ? 1 : 0,
            duration: const Duration(milliseconds: 200),
            child: Material(
              color: scheme.surface,
              elevation: 3,
              child: Padding(
                padding: EdgeInsets.only(top: mq.padding.top),
                child: SizedBox(
                  height: kToolbarHeight,
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back),
                        onPressed: () => Navigator.of(context).maybePop(),
                      ),
                      Expanded(
                        child: Text(
                          widget.entry.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                      ),
                      IconButton(
                        icon: Icon(
                          _isBookmarked(_page - 1) ? Icons.bookmark : Icons.bookmark_border,
                        ),
                        tooltip: 'Закладка',
                        onPressed: _toggleBookmark,
                      ),
                      IconButton(
                        icon: const Icon(Icons.headphones),
                        tooltip: 'Слушать',
                        onPressed: _toggleSpeak,
                      ),
                      PopupMenuButton<int>(
                        icon: const Icon(Icons.more_vert),
                        tooltip: 'Ещё',
                        onSelected: (v) {
                          if (v == 0) _showSearch();
                          if (v == 1) _showBookmarks();
                          if (v == 2) _showNotes();
                          if (v == 3) _showNoteEditor();
                        },
                        itemBuilder: (_) => const [
                          PopupMenuItem(value: 0, child: Text('Поиск по книге')),
                          PopupMenuItem(value: 1, child: Text('Закладки')),
                          PopupMenuItem(value: 2, child: Text('Заметки и цитаты')),
                          PopupMenuItem(value: 3, child: Text('Добавить заметку')),
                        ],
                      ),
                      IconButton(
                        icon: const Icon(Icons.list),
                        tooltip: 'Оглавление',
                        onPressed: _showToc,
                      ),
                      IconButton(
                        icon: const Icon(Icons.text_fields),
                        tooltip: 'Настройки',
                        onPressed: _showSettings,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTtsRow() {
    final tts = _tts;
    if (tts == null) return const SizedBox.shrink();
    return ValueListenableBuilder<bool>(
      valueListenable: tts.speaking,
      builder: (context, speaking, _) => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton(
            icon: const Icon(Icons.skip_previous),
            tooltip: 'Назад',
            onPressed: speaking ? () => tts.skipToPrevious() : null,
          ),
          const SizedBox(width: 4),
          FilledButton.icon(
            onPressed: _toggleSpeak,
            icon: Icon(speaking ? Icons.pause : Icons.play_arrow),
            label: Text(speaking ? 'Пауза' : 'Слушать'),
          ),
          const SizedBox(width: 4),
          IconButton(
            icon: const Icon(Icons.skip_next),
            tooltip: 'Вперёд',
            onPressed: speaking ? () => tts.skipToNext() : null,
          ),
          IconButton(
            icon: const Icon(Icons.tune),
            tooltip: 'Голос: выбор, тембр, скорость',
            onPressed: _showVoiceSheet,
          ),
        ],
      ),
    );
  }

  Widget _buildBottomBar(BuildContext context, MediaQueryData mq, List<BookPage> pages) {
    final scheme = Theme.of(context).colorScheme;
    final maxPage = math.max(1, pages.length).toDouble();
    final label = _page == 0
        ? 'Обложка'
        : 'Страница $_page из ${pages.length}'
            '  ·  ${(_page * 100 / math.max(1, pages.length)).floor()}%';
    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: IgnorePointer(
        ignoring: !_bars,
        child: AnimatedSlide(
          offset: _bars ? Offset.zero : const Offset(0, 1),
          duration: const Duration(milliseconds: 200),
          child: AnimatedOpacity(
            opacity: _bars ? 1 : 0,
            duration: const Duration(milliseconds: 200),
            child: Material(
              color: scheme.surface,
              elevation: 3,
              child: Padding(
                padding: EdgeInsets.fromLTRB(16, 8, 16, 8 + mq.padding.bottom),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Slider(
                      value: _page.clamp(0, pages.length).toDouble(),
                      min: 0,
                      max: maxPage,
                      divisions: pages.isEmpty ? null : math.min(pages.length, 1000),
                      label: _sliderLabel(pages),
                      onChanged: pages.isEmpty ? null : (v) => _turn.jumpTo(v.round()),
                    ),
                    Text(label, style: Theme.of(context).textTheme.bodySmall),
                    const SizedBox(height: 4),
                    _buildTtsRow(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ---------- поиск, заметки ----------

  String _sliderLabel(List<BookPage> pages) {
    if (_page == 0) return 'Обложка';
    final t = pages[(_page - 1).clamp(0, pages.length - 1).toInt()]
        .text
        .replaceAll('\n', ' ')
        .trim();
    final head = t.length > 36 ? '${t.substring(0, 36)}…' : t;
    return '$_page: $head';
  }

  void _showSearch() {
    final content = _content;
    final pages = _pages;
    if (content == null || pages == null) return;
    final controller = TextEditingController();
    var results = <({int page, String snippet})>[];
    var searched = false;

    void run(String q, void Function(void Function()) setSheet) {
      final query = q.trim().toLowerCase();
      final found = <({int page, String snippet})>[];
      if (query.length >= 2) {
        for (var i = 0; i < content.paragraphs.length && found.length < 300; i++) {
          final para = content.paragraphs[i];
          final low = para.toLowerCase();
          var from = 0;
          while (found.length < 300) {
            final at = low.indexOf(query, from);
            if (at < 0) break;
            final offset = _paraOffsets[i] + at;
            final s0 = math.max(0, at - 30);
            final e0 = math.min(para.length, at + query.length + 50);
            found.add((
              page: pageForOffset(pages, offset),
              snippet: '${s0 > 0 ? '…' : ''}${para.substring(s0, e0)}${e0 < para.length ? '…' : ''}',
            ));
            from = at + query.length;
          }
        }
      }
      setSheet(() {
        results = found;
        searched = query.length >= 2;
      });
    }

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setSheet) {
          return Padding(
            padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
            child: SizedBox(
              height: MediaQuery.of(ctx).size.height * 0.7,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                    child: TextField(
                      controller: controller,
                      autofocus: true,
                      textInputAction: TextInputAction.search,
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search),
                        hintText: 'Поиск по книге',
                        border: OutlineInputBorder(),
                      ),
                      onChanged: (q) => run(q, setSheet),
                      onSubmitted: (q) => run(q, setSheet),
                    ),
                  ),
                  if (searched)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Text(results.isEmpty
                          ? 'Ничего не найдено'
                          : 'Найдено: ${results.length}${results.length >= 300 ? '+' : ''}'),
                    ),
                  Expanded(
                    child: ListView.builder(
                      itemCount: results.length,
                      itemBuilder: (ctx, i) {
                        final r = results[i];
                        return ListTile(
                          dense: true,
                          title: Text(r.snippet, maxLines: 2, overflow: TextOverflow.ellipsis),
                          trailing: Text('${r.page + 1}'),
                          onTap: () {
                            Navigator.of(ctx).pop();
                            _turn.jumpTo(r.page + 1);
                            setState(() => _bars = false);
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          );
        });
      },
    );
  }

  /// Заметка к текущей странице: можно выделить фрагмент (цитата) и написать комментарий.
  void _showNoteEditor() {
    final pages = _pages;
    if (pages == null || _page == 0) {
      _snack('Заметку можно добавить на странице с текстом');
      return;
    }
    final pageIndex = _page - 1;
    final page = pages[pageIndex];
    final pageText = page.text.replaceAll('\n', '\n\n');
    var quote = '';
    final comment = TextEditingController();

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: SizedBox(
            height: MediaQuery.of(ctx).size.height * 0.8,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    'Страница ${pageIndex + 1}: выделите фрагмент для цитаты',
                    style: Theme.of(ctx).textTheme.titleSmall,
                  ),
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: SelectableText(
                      pageText,
                      style: const TextStyle(fontSize: 16, height: 1.4),
                      onSelectionChanged: (sel, _) {
                        if (sel.isValid && !sel.isCollapsed) {
                          quote = pageText.substring(sel.start, sel.end).trim();
                        } else {
                          quote = '';
                        }
                      },
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                  child: TextField(
                    controller: comment,
                    minLines: 1,
                    maxLines: 3,
                    decoration: const InputDecoration(
                      hintText: 'Комментарий (необязательно)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: FilledButton.icon(
                    icon: const Icon(Icons.edit_note),
                    label: const Text('Сохранить'),
                    onPressed: () {
                      final text = comment.text.trim();
                      widget.library.addNote(
                        widget.entry,
                        BookNote(
                          offset: page.start,
                          quote: quote.isEmpty && text.isEmpty
                              ? pageText.replaceAll('\n', ' ').trim().substring(
                                    0,
                                    math.min(120, pageText.trim().length),
                                  )
                              : quote,
                          text: text,
                          at: DateTime.now().millisecondsSinceEpoch,
                        ),
                      );
                      Navigator.of(ctx).pop();
                      _snack('Заметка сохранена');
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showNotes() {
    final pages = _pages;
    if (pages == null) return;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setSheet) {
          final notes = widget.entry.notes;
          if (notes.isEmpty) {
            return const Padding(
              padding: EdgeInsets.fromLTRB(24, 8, 24, 40),
              child: Text(
                'Заметок пока нет. Задержите палец на странице, '
                'чтобы добавить заметку или цитату.',
              ),
            );
          }
          return SizedBox(
            height: MediaQuery.of(ctx).size.height * 0.7,
            child: ListView(
              children: [
                for (final n in List<BookNote>.of(notes))
                  ListTile(
                    leading: const Icon(Icons.format_quote),
                    title: Text(
                      n.quote.isEmpty ? n.text : n.quote,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                    subtitle: n.quote.isNotEmpty && n.text.isNotEmpty
                        ? Text(n.text, maxLines: 3, overflow: TextOverflow.ellipsis)
                        : Text('Страница ${pageForOffset(pages, n.offset) + 1}'),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () {
                        widget.library.removeNote(widget.entry, n);
                        setSheet(() {});
                      },
                    ),
                    onTap: () {
                      Navigator.of(ctx).pop();
                      _turn.jumpTo(pageForOffset(pages, n.offset) + 1);
                      setState(() => _bars = false);
                    },
                  ),
              ],
            ),
          );
        });
      },
    );
  }

  // ---------- закладки ----------

  /// Границы страницы [i] в символах книги: [начало, конец).
  (int, int) _range(int i) {
    final pages = _pages!;
    final start = pages[i].start;
    final end = i + 1 < pages.length ? pages[i + 1].start : 1 << 40;
    return (start, end);
  }

  bool _isBookmarked(int i) {
    final pages = _pages;
    if (pages == null || i < 0 || i >= pages.length) return false;
    final (a, b) = _range(i);
    return widget.entry.bookmarks.any((o) => o >= a && o < b);
  }

  void _toggleBookmark() {
    final pages = _pages;
    if (pages == null || _page == 0) {
      _snack('Закладку можно поставить на странице с текстом');
      return;
    }
    final i = _page - 1;
    final (a, b) = _range(i);
    final list = List<int>.of(widget.entry.bookmarks);
    if (_isBookmarked(i)) {
      list.removeWhere((o) => o >= a && o < b);
    } else {
      list.add(a);
    }
    list.sort();
    widget.library.setBookmarks(widget.entry, list);
    setState(() => _bmVersion++);
  }

  void _showBookmarks() {
    final pages = _pages;
    if (pages == null) return;
    final marks = widget.entry.bookmarks;
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) {
        if (marks.isEmpty) {
          return const Padding(
            padding: EdgeInsets.fromLTRB(24, 8, 24, 40),
            child: Text('Закладок пока нет. Нажмите значок закладки вверху.'),
          );
        }
        return ListView(
          shrinkWrap: true,
          children: [
            for (final o in marks)
              Builder(builder: (_) {
                final pi = pageForOffset(pages, o);
                final text = pages[pi].text.replaceAll('\n', ' ').trim();
                return ListTile(
                  leading: const Icon(Icons.bookmark, color: Colors.red),
                  title: Text('Страница ${pi + 1}'),
                  subtitle: Text(text, maxLines: 2, overflow: TextOverflow.ellipsis),
                  onTap: () {
                    Navigator.of(ctx).pop();
                    _turn.jumpTo(pi + 1);
                    setState(() => _bars = false);
                  },
                );
              }),
          ],
        );
      },
    );
  }

  // ---------- оглавление ----------

  void _showToc() {
    final content = _content;
    final pages = _pages;
    if (content == null || pages == null) return;

    final items = <({String title, int page})>[];
    for (final ch in content.chapters) {
      if (ch.paragraphIndex >= _paraOffsets.length) continue;
      items.add((
        title: ch.title,
        page: pageForOffset(pages, _paraOffsets[ch.paragraphIndex]),
      ));
    }
    var currentIdx = -1;
    for (var i = 0; i < items.length; i++) {
      if (items[i].page <= _page - 1) currentIdx = i;
    }

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) {
        if (items.isEmpty) {
          return const Padding(
            padding: EdgeInsets.fromLTRB(24, 8, 24, 40),
            child: Text('В этой книге нет оглавления'),
          );
        }
        return SizedBox(
          height: MediaQuery.of(ctx).size.height * 0.7,
          child: ListView.builder(
            itemCount: items.length,
            itemBuilder: (ctx, i) {
              final it = items[i];
              return ListTile(
                selected: i == currentIdx,
                title: Text(it.title, maxLines: 2, overflow: TextOverflow.ellipsis),
                trailing: Text('${it.page + 1}'),
                onTap: () {
                  Navigator.of(ctx).pop();
                  _turn.jumpTo(it.page + 1);
                  setState(() => _bars = false);
                },
              );
            },
          ),
        );
      },
    );
  }

  // ---------- настройки текста ----------

  void _showSettings() {
    final settings = widget.settings;
    var font = settings.fontSize;
    var lh = settings.lineHeight;

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setSheet) {
          return SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(20, 0, 20, 24 + MediaQuery.of(ctx).padding.bottom),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Размер шрифта: ${font.round()}'),
                Slider(
                  value: font,
                  min: 14,
                  max: 30,
                  divisions: 16,
                  onChanged: (v) => setSheet(() => font = v),
                  onChangeEnd: (v) => settings.update(fontSize: v),
                ),
                Text('Межстрочный интервал: ${lh.toStringAsFixed(2)}'),
                Slider(
                  value: lh,
                  min: 1.2,
                  max: 1.9,
                  divisions: 14,
                  onChanged: (v) => setSheet(() => lh = v),
                  onChangeEnd: (v) => settings.update(lineHeight: v),
                ),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.font_download_outlined),
                        label: Text(
                          settings.fontFile.isEmpty ? 'Свой шрифт…' : 'Другой шрифт…',
                        ),
                        onPressed: () async {
                          final ok = await _pickFont();
                          if (ok) setSheet(() {});
                        },
                      ),
                    ),
                    if (settings.fontFile.isNotEmpty) ...[
                      const SizedBox(width: 8),
                      TextButton(
                        onPressed: () async {
                          await settings.setCustomFont('');
                          setSheet(() {});
                        },
                        child: const Text('Обычный'),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 8),
                const Text('Выравнивание текста'),
                const SizedBox(height: 6),
                SegmentedButton<int>(
                  showSelectedIcon: false,
                  segments: const [
                    ButtonSegment(value: 0, icon: Icon(Icons.format_align_left)),
                    ButtonSegment(value: 1, icon: Icon(Icons.format_align_center)),
                    ButtonSegment(value: 2, icon: Icon(Icons.format_align_right)),
                    ButtonSegment(value: 3, icon: Icon(Icons.format_align_justify)),
                  ],
                  selected: {settings.textAlign},
                  onSelectionChanged: (v) {
                    settings.update(textAlign: v.first);
                    setSheet(() {});
                  },
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Шрифт с засечками'),
                  value: settings.serif,
                  onChanged: (v) {
                    settings.update(serif: v);
                    setSheet(() {});
                  },
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Шелест страниц'),
                  value: settings.sound,
                  onChanged: (v) {
                    settings.update(sound: v);
                    setSheet(() {});
                  },
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    for (var i = 0; i < readerThemes.length; i++)
                      ChoiceChip(
                        label: Text(readerThemes[i].name),
                        selected: settings.themeIndex == i,
                        onSelected: (_) {
                          settings.update(themeIndex: i);
                          setSheet(() {});
                        },
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () {
                    Navigator.of(ctx).pop();
                    _showVoiceSheet();
                  },
                  icon: const Icon(Icons.record_voice_over),
                  label: const Text('Настройки голоса'),
                ),
              ],
            ),
          );
        });
      },
    );
  }

  Future<bool> _pickFont() async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['ttf', 'otf'],
    );
    final path = res?.files.single.path;
    if (path == null) return false;
    try {
      final docs = await getApplicationDocumentsDirectory();
      final dir = Directory('${docs.path}/fonts');
      await dir.create(recursive: true);
      final name = path.split('/').last;
      final target = '${dir.path}/${DateTime.now().millisecondsSinceEpoch}_$name';
      await File(path).copy(target);
      final ok = await widget.settings.setCustomFont(target);
      if (!ok) _snack('Не удалось загрузить шрифт');
      return ok;
    } catch (e) {
      _snack('Не удалось загрузить шрифт');
      return false;
    }
  }

  // ---------- настройки голоса ----------

  String _engineLabel(String pkg) {
    if (pkg.contains('google')) return 'Google (Речевой синтез)';
    if (pkg.contains('samsung') || pkg.contains('SMT')) return 'Samsung';
    if (pkg.contains('rhvoice')) return 'RHVoice';
    if (pkg.contains('yandex')) return 'Яндекс';
    return pkg;
  }

  String _voiceLabel(int index, Map<String, String> v) {
    final name = v['name'] ?? '';
    final kind = name.contains('network') ? 'онлайн' : 'офлайн';
    return '${index + 1}. $kind · $name';
  }

  void _showVoiceSheet() {
    final tts = _tts;
    if (tts == null) {
      _snack('Озвучка недоступна на этом устройстве');
      return;
    }
    final settings = widget.settings;
    var rate = settings.ttsRate;
    var pitch = settings.ttsPitch;
    var voice = settings.ttsVoice;
    int? sleepChoice;
    var voicesFuture = tts.russianVoices();
    final enginesFuture = tts.engines();
    var engine = settings.ttsEngine;

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setSheet) {
          return SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(20, 0, 20, 24 + MediaQuery.of(ctx).padding.bottom),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Голос озвучки', style: Theme.of(ctx).textTheme.titleLarge),
                const SizedBox(height: 12),
                FutureBuilder<List<String>>(
                  future: enginesFuture,
                  builder: (ctx, snap) {
                    final list = snap.data ?? const <String>[];
                    if (list.length < 2) return const SizedBox.shrink();
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: DropdownButtonFormField<String>(
                        value: list.contains(engine) ? engine : null,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'Движок озвучки',
                          border: OutlineInputBorder(),
                        ),
                        hint: const Text('По умолчанию'),
                        items: [
                          for (final e in list)
                            DropdownMenuItem<String>(
                              value: e,
                              child: Text(_engineLabel(e), overflow: TextOverflow.ellipsis),
                            ),
                        ],
                        onChanged: (v) async {
                          if (v == null) return;
                          engine = v;
                          settings.update(ttsEngine: v, ttsVoice: '');
                          await tts.setEngine(v);
                          setSheet(() {
                            voice = '';
                            voicesFuture = tts.russianVoices();
                          });
                        },
                      ),
                    );
                  },
                ),
                FutureBuilder<List<Map<String, String>>>(
                  future: voicesFuture,
                  builder: (ctx, snap) {
                    if (snap.connectionState != ConnectionState.done) {
                      return const LinearProgressIndicator();
                    }
                    final voices = snap.data ?? const <Map<String, String>>[];
                    if (voices.isEmpty) {
                      return const Text(
                        'Русские голоса не найдены. Скачай голос: Настройки Android → '
                        'Язык и ввод → Синтез речи → Google → Русский.',
                      );
                    }
                    final names = [for (final v in voices) v['name'] ?? ''];
                    return DropdownButtonFormField<String>(
                      value: names.contains(voice) ? voice : null,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Голос',
                        border: OutlineInputBorder(),
                      ),
                      hint: const Text('По умолчанию'),
                      items: [
                        for (var i = 0; i < voices.length; i++)
                          DropdownMenuItem<String>(
                            value: voices[i]['name'],
                            child: Text(
                              _voiceLabel(i, voices[i]),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                      ],
                      onChanged: (v) {
                        final chosen = v ?? '';
                        final loc = voices.firstWhere(
                              (m) => m['name'] == chosen,
                              orElse: () => const <String, String>{},
                            )['locale'] ??
                            'ru-RU';
                        setSheet(() => voice = chosen);
                        settings.update(ttsVoice: chosen, ttsVoiceLocale: loc);
                        tts.setVoice(chosen, loc);
                      },
                    );
                  },
                ),
                const SizedBox(height: 16),
                Text('Скорость: ${(rate / 0.5).toStringAsFixed(1)}×'),
                Slider(
                  value: rate,
                  min: 0.2,
                  max: 1.0,
                  divisions: 16,
                  onChanged: (v) => setSheet(() => rate = v),
                  onChangeEnd: (v) {
                    settings.update(ttsRate: v);
                    tts.setRate(v);
                  },
                ),
                Text('Тембр: ${pitch.toStringAsFixed(2)}'),
                Slider(
                  value: pitch,
                  min: 0.6,
                  max: 1.6,
                  divisions: 20,
                  onChanged: (v) => setSheet(() => pitch = v),
                  onChangeEnd: (v) {
                    settings.update(ttsPitch: v);
                    tts.setPitch(v);
                  },
                ),
                Text('Таймер сна', style: Theme.of(ctx).textTheme.titleMedium),
                const SizedBox(height: 4),
                ValueListenableBuilder<DateTime?>(
                  valueListenable: tts.sleepAt,
                  builder: (ctx, at, _) {
                    final left = at == null ? null : at.difference(DateTime.now());
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Wrap(
                          spacing: 8,
                          children: [
                            for (final m in const <int?>[null, 15, 30, 45, 60, 90])
                              ChoiceChip(
                                label: Text(m == null ? 'Выкл' : '$m мин'),
                                selected: m == null
                                    ? at == null
                                    : (left != null &&
                                        (left.inMinutes - m).abs() <= 1 &&
                                        sleepChoice == m),
                                onSelected: (_) {
                                  sleepChoice = m;
                                  tts.setSleepTimer(m);
                                  if (m != null && !tts.speaking.value) {
                                    _snack('Таймер запустится вместе с озвучкой: '
                                        'нажмите «Слушать»');
                                  }
                                },
                              ),
                          ],
                        ),
                        if (left != null)
                          Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Text('Остановится через ${left.inMinutes + 1} мин'),
                          ),
                      ],
                    );
                  },
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 8,
                  children: [
                    ActionChip(
                      label: const Text('Низкий (мужской)'),
                      onPressed: () {
                        setSheet(() => pitch = 0.7);
                        settings.update(ttsPitch: 0.7);
                        tts.setPitch(0.7);
                      },
                    ),
                    ActionChip(
                      label: const Text('Обычный'),
                      onPressed: () {
                        setSheet(() => pitch = 1.0);
                        settings.update(ttsPitch: 1.0);
                        tts.setPitch(1.0);
                      },
                    ),
                    ActionChip(
                      label: const Text('Высокий'),
                      onPressed: () {
                        setSheet(() => pitch = 1.3);
                        settings.update(ttsPitch: 1.3);
                        tts.setPitch(1.3);
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.tonalIcon(
                        onPressed: () => tts.preview(),
                        icon: const Icon(Icons.volume_up),
                        label: const Text('Проверить голос'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    TextButton(
                      onPressed: () {
                        setSheet(() {
                          rate = 0.5;
                          pitch = 1.0;
                          voice = '';
                        });
                        settings.update(
                          ttsRate: 0.5,
                          ttsPitch: 1.0,
                          ttsVoice: '',
                          ttsVoiceLocale: 'ru-RU',
                        );
                        tts.setRate(0.5);
                        tts.setPitch(1.0);
                        tts.setVoice('', 'ru-RU');
                      },
                      child: const Text('Сбросить'),
                    ),
                  ],
                ),
              ],
            ),
          );
        });
      },
    );
  }
}
