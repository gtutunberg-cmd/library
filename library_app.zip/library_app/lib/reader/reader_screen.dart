import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/library_store.dart';
import '../data/reader_settings.dart';
import '../parsers/book_content.dart';
import '../parsers/book_loader.dart';
import 'page_turn_view.dart';
import 'paginator.dart';
import 'text_metrics.dart';

class ReaderScreen extends StatefulWidget {
  const ReaderScreen({
    super.key,
    required this.entry,
    required this.library,
    required this.settings,
  });

  final BookEntry entry;
  final LibraryStore library;
  final ReaderSettings settings;

  @override
  State<ReaderScreen> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends State<ReaderScreen> {
  BookContent? _content;
  Object? _error;

  List<BookPage>? _pages;
  List<int> _paraOffsets = const [];

  String? _paginationKey;
  int _gen = 0;
  bool _paginating = false;

  int _page = 0;
  int _anchorOffset = 0;
  Key _turnKey = UniqueKey();
  final PageTurnController _turn = PageTurnController();

  bool _bars = false;
  Timer? _saveTimer;

  @override
  void initState() {
    super.initState();
    _anchorOffset = widget.entry.lastOffset;
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    widget.library.touch(widget.entry);
    _open();
  }

  Future<void> _open() async {
    try {
      final content = await loadBook(
        widget.entry.path,
        widget.entry.format,
        fallbackTitle: widget.entry.title,
      );
      if (!mounted) return;
      setState(() {
        _content = content;
        _paraOffsets = content.paragraphOffsets;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e);
    }
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _flushProgress();
    _gen++; // останавливаем фоновую разбивку на страницы
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  // ---------- прогресс ----------

  void _scheduleSave() {
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 700), _flushProgress);
  }

  void _flushProgress() {
    final pages = _pages;
    final content = _content;
    if (pages == null || content == null || pages.isEmpty) return;
    final i = _page.clamp(0, pages.length - 1).toInt();
    widget.library.saveProgress(widget.entry, pages[i].start, content.totalChars);
  }

  void _onPageChanged(int i) {
    setState(() => _page = i);
    _scheduleSave();
  }

  // ---------- разбивка на страницы ----------

  void _ensurePagination(Size size, EdgeInsets inset, ReaderSettings s) {
    if (_content == null) return;
    final key = '${size.width.toStringAsFixed(1)}x${size.height.toStringAsFixed(1)}'
        '|${inset.left},${inset.top},${inset.right},${inset.bottom}'
        '|${s.fontSize}|${s.lineHeight}|${s.serif}';
    if (key == _paginationKey) return;
    _paginationKey = key;
    final gen = ++_gen;

    final width = size.width - inset.horizontal;
    final height = size.height - inset.vertical;
    final style = readerTextStyle(s, Colors.black);
    final strut = readerStrut(s);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _runPagination(gen, style, strut, width, height);
    });
  }

  Future<void> _runPagination(
    int gen,
    TextStyle style,
    StrutStyle strut,
    double width,
    double height,
  ) async {
    if (!mounted || gen != _gen) return;
    final content = _content;
    if (content == null) return;

    final existing = _pages;
    final anchor = (existing != null && existing.isNotEmpty)
        ? existing[_page.clamp(0, existing.length - 1).toInt()].start
        : _anchorOffset;

    setState(() => _paginating = true);
    final result = await paginate(
      paragraphs: content.paragraphs,
      style: style,
      strut: strut,
      width: width,
      height: height,
      isStale: () => !mounted || gen != _gen,
    );
    if (!mounted || gen != _gen || result == null) return;

    setState(() {
      _pages = result;
      _page = pageForOffset(result, anchor);
      _turnKey = UniqueKey();
      _paginating = false;
    });
  }

  // ---------- интерфейс ----------

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.settings,
      builder: (context, _) {
        final s = widget.settings;
        final theme = readerThemes[s.themeIndex];
        return Scaffold(
          backgroundColor: theme.bg,
          body: _buildBody(context, s, theme),
        );
      },
    );
  }

  Widget _buildBody(BuildContext context, ReaderSettings s, ReaderThemeData theme) {
    if (_error != null) {
      return SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.error_outline, size: 48, color: theme.fg),
                const SizedBox(height: 12),
                Text(
                  'Не удалось открыть книгу\n$_error',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: theme.fg),
                ),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: () => Navigator.of(context).maybePop(),
                  child: const Text('Назад'),
                ),
              ],
            ),
          ),
        );
      }

    return LayoutBuilder(builder: (context, constraints) {
      final mq = MediaQuery.of(context);
      final size = constraints.biggest;
      final inset = EdgeInsets.fromLTRB(
        22 + mq.padding.left,
        mq.padding.top + 18,
        22 + mq.padding.right,
        mq.padding.bottom + 34,
      );
      _ensurePagination(size, inset, s);

      final pages = _pages;
      return Stack(
        fit: StackFit.expand,
        children: [
          if (pages == null)
            Center(child: CircularProgressIndicator(color: theme.fg))
          else
            PageTurnView(
              key: _turnKey,
              pageCount: pages.length,
              initialPage: _page,
              controller: _turn,
              background: theme.bg,
              onPageChanged: _onPageChanged,
              onCenterTap: () => setState(() => _bars = !_bars),
              itemBuilder: (ctx, i) => _buildPage(i, s, theme, size, inset, mq),
            ),
          if (pages != null && _paginating)
            Positioned(
              top: mq.padding.top,
              left: 0,
              right: 0,
              child: LinearProgressIndicator(
                minHeight: 2,
                color: theme.fg.withValues(alpha: 0.6),
                backgroundColor: Colors.transparent,
              ),
            ),
          if (pages != null) _buildTopBar(context, mq),
          if (pages != null) _buildBottomBar(context, mq, pages),
        ],
      );
    });
  }

  Widget _buildPage(
    int i,
    ReaderSettings s,
    ReaderThemeData theme,
    Size size,
    EdgeInsets inset,
    MediaQueryData mq,
  ) {
    final pages = _pages!;
    final p = pages[i];
    final footerStyle = TextStyle(
      fontSize: 11,
      color: theme.fg.withValues(alpha: 0.5),
    );
    return ColoredBox(
      color: theme.bg,
      child: Stack(
        children: [
          Positioned(
            left: inset.left,
            top: inset.top,
            width: size.width - inset.horizontal,
            height: size.height - inset.vertical,
            child: Text(
              p.text,
              textAlign: TextAlign.justify,
              textScaler: TextScaler.noScaling,
              style: readerTextStyle(s, theme.fg),
              strutStyle: readerStrut(s),
            ),
          ),
          Positioned(
            left: inset.left,
            right: inset.right,
            bottom: mq.padding.bottom + 8,
            height: 18,
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    widget.entry.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: footerStyle,
                  ),
                ),
                const SizedBox(width: 12),
                Text('${i + 1} / ${pages.length}', style: footerStyle),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopBar(BuildContext context, MediaQueryData mq) {
    final scheme = Theme.of(context).colorScheme;
    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      child: IgnorePointer(
        ignoring: !_bars,
        child: AnimatedSlide(
          offset: _bars ? Offset.zero : const Offset(0, -1),
          duration: const Duration(milliseconds: 200),
          child: AnimatedOpacity(
            opacity: _bars ? 1 : 0,
            duration: const Duration(milliseconds: 200),
            child: Material(
              color: scheme.surface,
              elevation: 3,
              child: Padding(
                padding: EdgeInsets.only(top: mq.padding.top),
                child: SizedBox(
                  height: kToolbarHeight,
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back),
                        onPressed: () => Navigator.of(context).maybePop(),
                      ),
                      Expanded(
                        child: Text(
                          widget.entry.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.list),
                        tooltip: 'Оглавление',
                        onPressed: _showToc,
                      ),
                      IconButton(
                        icon: const Icon(Icons.text_fields),
                        tooltip: 'Настройки текста',
                        onPressed: _showSettings,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBottomBar(BuildContext context, MediaQueryData mq, List<BookPage> pages) {
    final scheme = Theme.of(context).colorScheme;
    final maxPage = math.max(1, pages.length - 1).toDouble();
    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: IgnorePointer(
        ignoring: !_bars,
        child: AnimatedSlide(
          offset: _bars ? Offset.zero : const Offset(0, 1),
          duration: const Duration(milliseconds: 200),
          child: AnimatedOpacity(
            opacity: _bars ? 1 : 0,
            duration: const Duration(milliseconds: 200),
            child: Material(
              color: scheme.surface,
              elevation: 3,
              child: Padding(
                padding: EdgeInsets.fromLTRB(16, 8, 16, 8 + mq.padding.bottom),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Slider(
                      value: _page.clamp(0, pages.length - 1).toDouble(),
                      min: 0,
                      max: maxPage,
                      onChanged: pages.length < 2 ? null : (v) => _turn.jumpTo(v.round()),
                    ),
                    Text(
                      'Страница ${_page + 1} из ${pages.length}'
                      '  ·  ${((_page + 1) * 100 / pages.length).floor()}%',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ---------- оглавление ----------

  void _showToc() {
    final content = _content;
    final pages = _pages;
    if (content == null || pages == null) return;

    final items = <({String title, int page})>[];
    for (final ch in content.chapters) {
      if (ch.paragraphIndex >= _paraOffsets.length) continue;
      items.add((
        title: ch.title,
        page: pageForOffset(pages, _paraOffsets[ch.paragraphIndex]),
      ));
    }
    var currentIdx = -1;
    for (var i = 0; i < items.length; i++) {
      if (items[i].page <= _page) currentIdx = i;
    }

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) {
        if (items.isEmpty) {
          return const Padding(
            padding: EdgeInsets.fromLTRB(24, 8, 24, 40),
            child: Text('В этой книге нет оглавления'),
          );
        }
        return SizedBox(
          height: MediaQuery.of(ctx).size.height * 0.7,
          child: ListView.builder(
            itemCount: items.length,
            itemBuilder: (ctx, i) {
              final it = items[i];
              return ListTile(
                selected: i == currentIdx,
                title: Text(it.title, maxLines: 2, overflow: TextOverflow.ellipsis),
                trailing: Text('${it.page + 1}'),
                onTap: () {
                  Navigator.of(ctx).pop();
                  _turn.jumpTo(it.page);
                  setState(() => _bars = false);
                },
              );
            },
          ),
        );
      },
    );
  }

  // ---------- настройки текста ----------

  void _showSettings() {
    final settings = widget.settings;
    var font = settings.fontSize;
    var lh = settings.lineHeight;

    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setSheet) {
          return Padding(
            padding: EdgeInsets.fromLTRB(20, 0, 20, 24 + MediaQuery.of(ctx).padding.bottom),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Размер шрифта: ${font.round()}'),
                Slider(
                  value: font,
                  min: 14,
                  max: 30,
                  divisions: 16,
                  onChanged: (v) => setSheet(() => font = v),
                  onChangeEnd: (v) => settings.update(fontSize: v),
                ),
                Text('Межстрочный интервал: ${lh.toStringAsFixed(2)}'),
                Slider(
                  value: lh,
                  min: 1.2,
                  max: 1.9,
                  divisions: 14,
                  onChanged: (v) => setSheet(() => lh = v),
                  onChangeEnd: (v) => settings.update(lineHeight: v),
                ),
                const SizedBox(height: 8),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Шрифт с засечками'),
                  value: settings.serif,
                  onChanged: (v) {
                    settings.update(serif: v);
                    setSheet(() {});
                  },
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    for (var i = 0; i < readerThemes.length; i++)
                      ChoiceChip(
                        label: Text(readerThemes[i].name),
                        selected: settings.themeIndex == i,
                        onSelected: (_) {
                          settings.update(themeIndex: i);
                          setSheet(() {});
                        },
                      ),
                  ],
                ),
              ],
            ),
          );
        });
      },
    );
  }
}
